from typing import Dict, List

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.parser_utils import ufed_party_number


class Timeline(Parser):
    """
    This function parses a record from Timeline sheet.
    See base class for doc string.
    """
   
    index_name = "timeline"  # type: ignore
    parser_name = 'timeline'
    sheets = ["Timeline", 'timeline']  # type: ignore

    def _default_drop_cols(self) -> List[str]:
        self.drop_cols = [
            "#", 
            "Locations",
            "Address",
            "Tag Note",
            "Carved",
            "Date"]
        return self.drop_cols

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
                "Party": Transform(True, ufed_party_number, {}),
            }
        return self.transforms
