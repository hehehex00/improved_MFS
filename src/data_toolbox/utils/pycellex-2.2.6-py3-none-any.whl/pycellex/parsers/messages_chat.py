import re
from typing import List, Optional, Dict

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.parser_utils import extract_nested_identifier
from pycellex.utils.log_utils import warn_once
from pycellex.definitions import cache, logger


class MessagesChat(Parser):
    """
    This function parses a record from Messages Chat XRY sheet 
    see base class for doc string
    """
    index_name = "chat"  # type: ignore
    parser_name = "message_chat"
    sheets = [
        'messages_chat', 'Messages Chat'
    ]  # type: ignore
    # TODO: Find the other instant_messages pseudonyms

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "extract_to_from": Transform(True, self.extract_to_from, {})
        }
        return self.transforms
    
    def extract_to_from(
            self, record: Dict
    ) -> Optional[Dict[str, List[Dict[str, Optional[str]]]]]:
    
        out = {}
    
        # Simple to / from columns present
        # First, test if a colon is in the to & from key
        # If so, then we use a split pattern to extract the identifier type and
        # If not, then we test for app_key names in the keys
    
        to = record.get('to')
        from_ = record.get('from')
    
        if to and (':' in to or '\n' in to or ';' in to) or from_ and \
                (':' in from_ or '\n' in from_ or ';' in from_):
    
            if from_:
                new_from = extract_nested_identifier(from_)
                if new_from is not None:
                    out['wf_from'] = new_from
    
            if to:
                out['wf_to'] = []
                # Test if there are multiple "to" values
                i = 0
                to_key = 'to'
                while record.get(to_key):
                    another_to = record[to_key]
                    new_another_to = extract_nested_identifier(another_to)
                    if new_another_to:
                        out['wf_to'].extend(new_another_to)
                    i += 1
                    to_key = f'to_{i}'
    
            return out
        
        # Participant(s) section
        participant = record.get('participant')
        initiated_by = record.get('initiated_by')
        
        if participant:
            
            # If participant is present, then the direction is "to"
            # Unless initiated_by key is present, in which case it's from
            out['wf_to'] = []
            i = 0
            participant_key = 'participant'
            while record.get(participant_key):
                participant = record.get(participant_key)
                new_val = extract_nested_identifier(participant)
                if new_val:
                    out['wf_to'].extend(new_val)
                i += 1
                participant_key = 'participant_{i}'
                
            # The initiated_by key contains "from" information, which is only present when 
            # participant key is present
            
            if initiated_by:
                new_val = extract_nested_identifier(initiated_by)
                if new_val:
                    out['wf_from'] = new_val
                    
            return out
        
        # App based columns (most complex)
        
        # If you made it here, then then a colon isn't in the from or to keys and
        # participant isn't present.
        # These are the keys we're looking for the in the record.
        # In addition, sometimes the keys has _1, _2, ... appended on teh end to infer
        # multiple.
        app_keys = set(cache["all_keys"]["app_data"]).intersection(record)
        direction = record.get('direction')

        for app_key in app_keys:
            val = record.get(app_key)
            if not val:
                continue
                
            # First, determine the direction
            to_from = app_key.split('_')[0]
            if to_from not in ['to', 'from']:
                if app_key == 'tel_to':
                    to_from = 'to'
                elif app_key == 'tel_from':
                    to_from = 'from'
                elif not direction:
                    # WARNING: We're going to infer the direction if not known
                    to_from = 'from'
                elif 'Incoming' in direction:
                    to_from = 'to'
                elif 'Outgoing' in direction:
                    to_from = 'from'
                else:
                    logger.warning(
                        'MessagesChat.extract_to_from encountered \
                        an unexpected direction value: %s', direction)
                    to_from = 'from'
                    
            i = 0
            app_key_index = f'{app_key}'
            name_key = f'{to_from}_matched'
    
            while record.get(app_key_index):
                another_val = record[app_key_index]
                
                if 'facebook' in app_key or 'tel' in app_key:
                    another_val = val.split('.')[0]
                    
                app = re.sub('from_|_from|to_|_to', '', app_key)
                    
                entry = {app: another_val}
                
                name = record.get(name_key)
                if name:
                    entry['Name'] = name
                
                if f'wf_{to_from}' not in out:
                    out[f'wf_{to_from}'] = []
                    
                out[f'wf_{to_from}'].append(entry)
                
                i += 1
                app_key_index = f'{app_key}_{i}'
                name_key = f'{to_from}_matched_{i}'
            
        if 'wf_to' not in out and 'wf_from' not in out:
            # warn_once(f'MessagesChat.extract_to_from unable to extract identifiers
            # for record {record}').
            return None
    
        return out
