from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class UserFiles(Parser):
    """
    This function parses a record from applications, archives, audio, carved images, configurations, databases,
    document, images, shortcut, text, video, and uncategorized sheets see base class for doc string
    """
    index_name = "user_files"
    parser_name = "user_files"
    sheets = [
            "Applications",
            "Archives",
            "Audio",
            "Carved Images",
            "Configurations",
            "Databases",
            "Document",
            "Images",
            "Shortcut",
            "Text",
            "Videos",
            "Uncategorized",
            
            'applications',
            'archives',
            'audio',
            'carved_images',
            'configurations',
            'databases',
            'document',
            'images',
            'shortcut',
            'text',
            'videos',
            'uncategorized'
    ]

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
