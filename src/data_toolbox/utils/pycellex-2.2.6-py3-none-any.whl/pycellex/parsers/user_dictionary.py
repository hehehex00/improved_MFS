from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class UserDictionary(Parser):
    """
    This function parses a record from user dictionary sheet
    see base class for doc string
    """

    index_name = "user_dictionary"  # type: ignore
    parser_name = "user_dictionary"
    sheets = ["User Dictionary", "user_dictionary"]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:    
        self.transforms = {}
        return self.transforms
