from abc import (
    ABC,
    abstractmethod
)
from typing import (
    Any,
    Dict,
    List,
    Callable,
    Set,
    Optional,
    Union
)
from copy import copy

from skopeutils.logger import SkopeLogger

from pycellex.utils.str_utils import (
    sql_friendly,
    pick_and_join
)
from pycellex.utils.log_utils import warn_once
from pycellex.utils.extraction_utils import (
    coerce_val,
    coerce_bool
)
from pycellex.utils.parser_utils import (
    dateparser_func,
    normalize_coordinate,
    normalize_duration,
    get_direction,
    normalize_application,
    parse_attachment
)
from pycellex.definitions import cache


class Transform(SkopeLogger):
    def __init__(self,
                 transform_bool: bool,
                 transform_func: Callable,
                 transform_args: Dict[str, Any],
                 ):
        """
        Base class for transforms that modify original parser data.
        All parsers should inherit this class.

        Args:
            transform_bool (bool): True if modifications made to existing value
            transform_func (Callable): function to be used for transformation
            transform_args (Dict[str,Any]): any arguments for transform_func

        """
        super().__init__()
        self.transform_bool = transform_bool
        self.transform_func = transform_func
        self.transform_args = transform_args

    def get_transformer(self):
        """
        Getter to return transformer

        Returns:
            bool: True if modifications made to existing value
            Callable: function to be used for transformation
            Dict[str,Any]: any arguments for transform_func
        """
        return self.transform_bool, self.transform_func, self.transform_args


class Parser(ABC, SkopeLogger):
    """
    Abstract class for all parser. All parsers should
    inherit this class.

    Examples
    ========
    ```python
    >>> class MySheet(Parsers):
    ...     def __init__(self, return_type: str="json"):
    ...         self.return_type = return_type
    ```    
    """

    # Establish all keys from the parser constants
    null_values = set(cache["all_keys"]["null_values"])

    drop_keys = set(cache["all_keys"]["drop_keys"])

    bool_keys = set(cache["all_keys"]["bool_keys"])

    integer_keys = set(cache["all_keys"]["integer_keys"])

    float_keys = set(cache["all_keys"]["float_keys"])

    string_keys = set(cache["all_keys"]["string_keys"])

    upper_keys = set(cache["all_keys"]["upper_keys"])

    time_keys = set(cache["all_keys"]["time_keys"])

    date_keys = set(cache["all_keys"]["date_keys"])

    identifier_keys = set(cache["all_keys"]["identifier_keys"])

    application_source_keys = set(cache["all_keys"]["app_source_keys"])

    coordinate_keys = set(cache["all_keys"]["coordinate_keys"])

    url_keys = set(cache["all_keys"]["url_keys"])

    name_keys = set(cache["all_keys"]["name_keys"])

    name_translation_keys = set(cache["all_keys"]["name_translation_keys"])

    group_name_keys = set(cache["all_keys"]["group_name_keys"])

    direction_keys = set(cache["all_keys"]["direction_keys"])

    duration_keys = set(cache["all_keys"]["duration_keys"])

    # all_keys = set(cache["all_keys"].data.keys())
    all_keys_list = []
    for key_i in cache["all_keys"].data.keys():
        all_keys_list.extend(cache["all_keys"][key_i])
    all_keys = set(all_keys_list)

    mystery_keys: Set[str] = set()

    last_record: Dict[str, Any] = {}
    
    sheets: List[str] = []

    index_name:str = ""

    def __init__(
            self,
            transforms: Dict[str, Transform] = None,
            preprocess: List[Callable] = None,
            postprocess: List[Callable] = None,
            default_direction: Optional[str] = None
    ):
        """
        Abstract class for all parser. All parsers should
        inherit this class.

        Args:
            transforms: A dictionary of transfom objects to apply to this parsers
            preprocess: A list of preprocessing functions
            postprocess: A lsit of postprocessing functions
            default_direction: One of "outgoing" or "incoming". Used in instances where the 
            direction is implied by the sheet name. Examples of this include "dialed_calls" 
            (outgoing) and "sms_received" (incoming).

        TODOs:
            - add more warnings

        Examples
        ========
        ```python
        >>> class MySheet(Parsers):
        ...     def __init__(self, return_type: str="json"):
        ...         self.return_type = return_type
        ```
        """
        super().__init__()
        self.records: List = []

        if transforms is None:
            self._default_transforms()
        else:
            self.transforms = self._validate_t(transforms)

        if preprocess is None:
            self.preprocessors = self._default_preprocessors()
        else:
            self.preprocessors = preprocess

        if postprocess is None:
            self.postprocessors = self._default_postprocessors()
        else:
            self.postprocessors = postprocess

        self.default_direction = default_direction

    @abstractmethod
    def _default_transforms(self) -> Dict[str, Transform]:
        """
        Returns the dictionary of columns as key and the transforms 
        to be performed based on the base class Transform

        Returns:
            Dict[str, Transform]: dictionary of column to have transformation 
                    performed on and the transformation to be performed
        """

    def _validate_dc(self, drop_cols: List) -> List:
        """
        Validates that drop_cols variable is the right data type

        Args:
            drop_cols (List, Optional): list of proposed columns to drop

        Returns:
            List, None: if drop_cols is not valid format, returns None
        """
        if isinstance(drop_cols, list) \
                and all(isinstance(col, str) for col in drop_cols):
            return drop_cols
        else:
            self.logger.warning(f"Value'{drop_cols}\
            ' for columns to drop is not a List of strings. Using defaults")
            return drop_cols

    def _validate_t(self, transforms: Dict[str, Any]) -> Dict[str,Transform]:
        """
        Validates that transformer variable is the right data type

        Args:
            transforms (Dict[str, Any], Optional): transforms proposed

        Returns:
            Dict, None: if transformer is not valid format, returns None
        """
        if isinstance(transforms, Dict) \
                and all([isinstance(x, Transform) for x in transforms.values()]):
            return transforms
        else:
            self.logger.warning(f"Value'{transforms}' for transforms is not valid. Using defaults")
            return self._default_transforms()

    #@abstractmethod
    #def index_name(self) -> str:
    #    """
    #    Returns the ideal name of the index 
    #    or table to which records parsed by this 
    #    parser are written
    #
     #   Returns:
      #      str: Name of the index and or table
       # """

    #@abstractmethod
    #def sheets(self) -> List[str]:
    #    """
    #    Returns list of sheet names the child parser 
    #    applies to
    #
    #    Returns:
    #        List[str]: list of applicable sheet names
    #
     #   """

    def _default_preprocessors(self) -> List[Callable]:
        """
        returns the default preprocessor which is an empty list

        Returns:
            List[Callable]: default preprocessor is an empty list
        """
        return []

    def _default_postprocessors(self) -> List[Callable]:
        """
        returns the default postprocessors which is an empty list

        Returns:
            List[callable]: default postprocessors is an empty list
        """
        return []

    def _parse_record(self, in_record: Dict) -> Dict:
        """
        Uses the parent classes' transforms to modify specific keys
        found in a given record. If there is not a transform for
        a field or the field is not explicitly listed in the parent's
        drop_cols then the field will be returned as is.
        If the field is in the parent's drop_cols it will not be 
        returned. 
        
        Field names will be lower cased and special chars removed (some
        replaced with underscore)

        Args:
            record (Dict): dictionary representing a singles row from
                a cellex ufed report


        Returns:
            Dict: Dictionary of all fields not in drop_cols with
                names lower case and special chars replaced. If 
                the transform is an irreversible change or creates 
                all new values, the original value is returned 
                and new fields with "wf" prefix will hold 
                the modified value.  

        Notes:
            The input record is a dictionary representing a single
            record, where keys are column names and values are the
            entries in the record. Most elements of the input record
            are extracted via coerce_val, which performs get 
            operations on the dictionary to obtain the value 
            (of type string or int, etc) associated with a 
            specific key. Subsequent processing of the result is 
            then often done by methods like normalize_str and
            get_dict_from_str.

        Examples
        ========
        ```python
        >>> from pycellex.parsers.parser import Parser, Transform
        >>> class SheetName(Parsers):
        ...      def __init__(self, drop_cols, transforms):
        ...             self.drop_cols=drop_cols
        ...             self.transforms=transforms
        >>> example_parser = SheetName(
        ...                     [], 
        ...                     {"Example": Transform(
        ...                                     False,
        ...                                     str.lower,
        ...                                     {})
        >>> example_parser._parse_record({"Example": "TEST", "Hello": "WORLD"})
            {
                "example": "test", 
                "hello": "WORLD"
            }
        ```

        """

        record = copy(in_record)

        # Execute parser specific pre-processing functions
        for process in self.preprocessors:
            record = process(record)

        # Execute universal transform & preprocessing
        record = self.primary_transform(record)
        # TODO: I don't see any refs to this. Still needed?
        self.last_record = record

        # Execute parser specific transformations
        for key in dict(self.transforms).keys():
            if not any(record.values()):
                break
            t_flag, t_func, t_args = self.transforms[key].get_transformer()

            try:
                transformation = t_func(record, **t_args)
            except Exception as e:
                warn_once(f"Transformation for '{key}' failed with error: {e}")
                continue

            if not transformation:
                continue

            elif t_flag:
                # When the transformation outputs a new dictionary, assign the keys of the 
                # new dictionary to the current record
                if isinstance(transformation, dict):

                    for t_key in transformation.keys():

                        if not transformation[t_key]:
                            continue

                        if t_key in record:
                            warn_once(f'Transform for "{key} \
                            " returned a dict overwriting the original value.')

                        record[t_key] = transformation[t_key]
                else:
                    record[f"wf_{key}"] = transformation

            else:
                record[key] = transformation

        # Execute parser specific post-processing functions
        for process in self.postprocessors:
            record = process(record)

        return record

    def parse_document(self, records: List[Dict]) -> List[Dict]:
        """
        Returns list of parsed records using _parse_record

        Args:
            records (List[Dict]): list of dictionaries representing
                rows from a cellex ufed report
            
        Returns:
            List[Dict]: list of parsed dictionaries representing
                parsed rows from a cellex ufed report

        Examples
        ========
        ```python
        >>> from pycellex.parsers.parser import Parser, Transform
        >>> class SheetName(Parsers):
        ...      def __init__(self, drop_cols, transforms):
        ...             self.drop_cols=drop_cols
        ...             self.transforms=transforms
        >>> example_parser = SheetName(
        ...                     [], 
        ...                     {"Example": Transform(
        ...                                     False,
        ...                                     str.lower,
        ...                                     {})
        >>> example_parser.parse_document([
        ...                 {"Example": "TEST", "Hello": "WORLD"},
        ...                 {"Example": "TESTING", "Hi"; "GLOBE"}])
            [
                {
                    "example": "test", 
                    "hello": "WORLD"
                },
                {
                    "example": "testing",
                    "hi": "GLOBE"
                }
            ]
        ```
        """

        for record in records:
            parsed_record_i = self._parse_record(record)
            if parsed_record_i:
                self.records.append(parsed_record_i)
        return self.records

    def primary_transform(self, record: Dict) -> Dict:
        """
        Primary transform to be performed on every record.
        
        Args:
            record: Dict: The record to be transformed
            
        Returns:
            Dict: The transformed record
            
        Examples
        ========
        ```python
        >>> from pycellex.parsers.parser import Parser
        >>> class GeneralParser(Parser):
        ...    def _default_transforms(self):
        ...         return {}
        ...     index_name = 'all_purpose'
        ...     sheets = ['sheet1', 'sheet2']
                
        >>> records = {
        ...     'Related Application': 'WhatsApp',
        ...     'Index': '3075.0',
        ...     'Time': '4/19/2020 10:37:56 AM UTC (Network)',
        ...     'Type': None,
        ...     'Internal Thread Id': '{0D8D2B49-FE52-47DF-A8BC-E9028B715BFA}',
        ...     'Related URL':
        'https://mmg-fna.whatsapp.net/d/f/AvKyP2XjU0ho1AHMlf5gQQYIDGr5X0s9u1e-hcEqGPtc.enc',
        ...     'Status': 'Sent',
        ...     'Thread Id': None,
        ...     'Related Social Group ID': None,
        ...     'From': 'WhatsApp ID: 93787865223@s.whatsapp.net Name (Matched): Basir Qadeeri',
        ...     'To': 'WhatsApp ID: 93792972365@s.whatsapp.net Name (Matched): Sona',
        ...     'Attachment.1':
        'File Name: 92b4be50-8976-4866-938a-6cee86144e3d.thumb
        Path:
        /private/var/mobile/Containers/Shared/AppGroup/group.net.whatsapp.WhatsApp.shared/Message/Media/
        93792972365@s.whatsapp.net/9/2/ Type: Jpeg File Size: 2.68 KB MetaData (Full):
        Orientation: 1  ExifColorSpace: 1
        ExifPixXDim: 75  ExifPixYDim: 100
        Status Changed: 4/19/2020 10:37:57 AM UTC (Device) Created: 4/19/2020
        10:37:57 AM UTC (Device) Modified: 4/19/2020 10:37:57 AM UTC (Device) Hash (SHA1):
        21251c7dc517dc7d4c8539b4fcbb9bb5ac67a5fe dHash Value: 9f8336431cd5b653',
        ...     'Attachment.2':
        'File Name: 92b4be50-8976-4866-938a-6cee86144e3d.jpg
        Path:
        /private/var/mobile/Containers/Shared/AppGroup/group.net.whatsapp.WhatsApp.shared/Message/Media/
        93792972365@s.whatsapp.net/9/2/ Type: Jpeg File Size: 103.45 KB
        Status Changed: 4/19/2020 10:38:00 AM UTC
        (Device) Created: 4/19/2020 10:37:57 AM UTC (Device)
        Modified: 4/19/2020 10:37:57 AM UTC (Device) Hash (SHA1):
        e18696ee6347bfbdc8d3287e9775e9407a251123 dHash Value: 9f83364315c1b673',
        ...     'Participant': None,
        ...     'Deleted': 1.0,
        ...     'Duration': '0:12:05'
        ... }
        >>> p = GeneralParser()
        >>> p.primary_transform(records = records)
            {'wf_application': 'WhatsApp',
             'related_application': 'WhatsApp',
             'time': '2020-04-19T10:37:56+0000',
             'internal_thread_id': '{0D8D2B49-FE52-47DF-A8BC-E9028B715BFA}',
             'related_url':
             'https://mmg-fna.whatsapp.net/d/f/AvKyP2XjU0ho1AHMlf5gQQYIDGr5X0s9u1e-hcEqGPtc.enc',
             'status': 'Sent',
             'from': 'WhatsApp ID: 93787865223@s.whatsapp.net Name (Matched): Basir Qadeeri',
             'to': 'WhatsApp ID: 93792972365@s.whatsapp.net Name (Matched): Sona',
             'attachment_1':
             'File Name:
             92b4be50-8976-4866-938a-6cee86144e3d.thumb Path: /private/var/mobile/Containers/Shared/
             AppGroup/group.net.whatsapp.WhatsApp.shared/Message/
             Media/93792972365@s.whatsapp.net/9/2/ Type: Jpeg File
             Size: 2.68 KB MetaData (Full): Orientation: 1  ExifColorSpace: 1  ExifPixXDim: 75
             ExifPixYDim: 100
             Status Changed: 4/19/2020 10:37:57 AM UTC (Device)
             Created: 4/19/2020 10:37:57 AM UTC (Device) Modified: 4/19/2020 10:37:57 AM UTC
             (Device) Hash (SHA1): 21251c7dc517dc7d4c8539b4fcbb9bb5ac67a5fe dHash Value:
             9f8336431cd5b653',
             'attachment_2':
             'File Name: 92b4be50-8976-4866-938a-6cee86144e3d.jpg Path:
             /private/var/mobile/Containers/Shared/AppGroup/
             group.net.whatsapp.WhatsApp.shared/Message/Media/93792972365@s.whatsapp.net/9/2/
             Type: Jpeg File Size:
             103.45 KB Status Changed: 4/19/2020 10:38:00 AM UTC (Device)
             Created: 4/19/2020 10:37:57 AM UTC (Device)
             Modified: 4/19/2020 10:37:57 AM UTC
             (Device) Hash (SHA1): e18696ee6347bfbdc8d3287e9775e9407a251123 dHash
             Value: 9f83364315c1b673',
             'deleted': None,
             'duration': 725,
             'wf_direction': 'outgoing',
             'wf_timestamp_latest': '2020-04-19T10:37:56+0000',
             'wf_attachments': [
             {'File Name': '92b4be50-8976-4866-938a-6cee86144e3d.thumb',
               'Path':
               '/private/var/mobile/Containers/Shared/AppGroup/group.net.whatsapp.WhatsApp.shared/Message/
               Media/93792972365@s.whatsapp.net/9/2/',
               'Type': 'Jpeg',
               'File Size': '2.68 KB',
               'MetaData (Full)': 'Orientation: 1',
               'ExifColorSpace': 1,
               'ExifPixXDim': 75,
               'ExifPixYDim': 100,
               'Status Changed': '4/19/2020 10:37:57 AM UTC (Device)',
               'Created': '4/19/2020 10:37:57 AM UTC (Device)',
               'Modified': '4/19/2020 10:37:57 AM UTC (Device)',
               'Hash (SHA1)': '21251c7dc517dc7d4c8539b4fcbb9bb5ac67a5fe',
               'dHash Value': '9f8336431cd5b653'},
              {'File Name': '92b4be50-8976-4866-938a-6cee86144e3d.jpg',
               'Path':
               '/private/var/mobile/Containers/Shared/AppGroup/group.net.whatsapp.WhatsApp.shared/Message/Media/
               93792972365@s.whatsapp.net/9/2/',
               'Type': 'Jpeg',
               'File Size': '103.45 KB',
               'Status Changed': '4/19/2020 10:38:00 AM UTC (Device)',
               'Created': '4/19/2020 10:37:57 AM UTC (Device)',
               'Modified': '4/19/2020 10:37:57 AM UTC (Device)',
               'Hash (SHA1)': 'e18696ee6347bfbdc8d3287e9775e9407a251123',
               'dHash Value': '9f83364315c1b673'}
              ],
              'wf_urls':
              ['https://mmg-fna.whatsapp.net/d/f/AvKyP2XjU0ho1AHMlf5gQQYIDGr5X0s9u1e-hcEqGPtc.enc']
             }
             
        ```
        """

        out: Dict[str, Any] = {}

        # Use arrays to store multiple identifiers so we have a consistent place to look for them.
        # json/dict style records will overwrite the "cleaned" key.
        wf_attachments: List = []
        wf_hashes: List = []
        wf_urls: List = []

        for old_key in record:

            # Access the value once
            val = record[old_key]

            if isinstance(val, tuple):
                val = list(val)
            if not isinstance(val, list):
                val = [val]

            # Drop empty values

            val = [val_i for val_i in val if val_i not in self.null_values]
            if len(val) == 0:
                continue

            # if val in self.null_values:
            #     continue

            # Clean the key 
            key = sql_friendly(old_key)
            if not key:
                continue
            key_rsplit = key.rsplit('_', 1)[0]
            # Right split is conducted to take care of instances like tel_666

            # Drop keys
            if key in self.drop_keys:
                continue
            # Booleans
            elif key in self.bool_keys:
                val = [coerce_bool(key, val_i) for val_i in val]
            # Integers
            elif key in self.integer_keys:
                val = [coerce_val(val=val_i, out_type=int) for val_i in val]
            # Floats
            elif key in self.float_keys:
                val = [coerce_val(val=val_i, out_type=float) for val_i in val]
            # Strings
            elif key in self.string_keys:
                val = [coerce_val(val=val_i, out_type=str) for val_i in val]

            # Date times
            if key in self.time_keys:
                force_date = True if key in self.date_keys else False
                parsed_time = [dateparser_func(val_i, force_date=force_date) for val_i in val]
                new_time = [parsed_time_i.get('iso') for parsed_time_i in parsed_time]
                if len(new_time) == 1:
                    new_time = new_time[0]
                    out[f'wf_{key}'] = new_time

            # Coordinates
            elif key in self.coordinate_keys:
                # Expect val to be a single element list if coordinate_keys, just keep the first.
                coord = normalize_coordinate(val[0])
                if "lat" in key:
                    out[f"wf_lat"] = coord
                else:
                    out[f"wf_lon"] = coord

            # Applications
            elif key in self.application_source_keys:
                application = [normalize_application(val_i) for val_i in val]
                if application:
                    out['wf_application'] = application[0]

            # Note: Identifiers handled in each parser class

            # Attachments
            elif key_rsplit == 'attachment' and '_details' not in key:
                wf_attachments.extend([parse_attachment(val_i) for val_i in val])

            # URLS
            elif 'related_url' in key or 'attachment_' in key and '_details' in key:
                try:
                    wf_urls.extend([val_i.strip('\n').strip() for val_i in val])
                except AttributeError:
                    wf_urls.extend([str(val_i) for val_i in val])

                # Special case to not flag cases like "attachment_666_details"
                if key not in self.all_keys:
                    self.all_keys.add(key)

            # Hashes
            elif key_rsplit == 'hash':
                wf_hashes.extend(val)

            # Duration
            elif key in self.duration_keys:
                duration = [normalize_duration(val_i) for val_i in val]
                # duration = [i for i in duration if i]
                if len(duration) != 0:
                    duration = list(set(duration))
                    if len(duration) == 1:
                        duration = duration[0]
                    out[f"wf_{key}"] = duration

            if key in self.upper_keys:
                upper_vals = [val_i.upper() for val_i in val]
                if upper_vals != val:
                    if len(upper_vals) == 1:
                        upper_vals = upper_vals[0]
                    out[f'wf_{key}'] = upper_vals

            if key in ["bssid", "mac_address"]:
                val = [val_i.upper() for val_i in val]

            # Assign value to dict once
            val = list(set(val))
            if len(val) == 1:
                out[key] = val[0]
            else:
                val.sort()
                out[key] = val

            # Flag mystery columns
            if key not in self.all_keys and key_rsplit not in self.all_keys and \
                    key not in self.mystery_keys:
                warn_once(f'Unparsed mystery key: {key}')
                self.mystery_keys.add(key)



        # Direction 
        if any(set(self.direction_keys).intersection(out)):
            wf_direction = get_direction(out, self.default_direction)
            if wf_direction:
                out['wf_direction'] = wf_direction

        elif self.default_direction:
            out['wf_direction'] = self.default_direction

        # Extract latest time, if a timestamp is available
        if any(set(self.time_keys).intersection(out)):
            try:
                all_times = [dateparser_func(out[key]).get('iso', '-1') for key in
                             set(self.time_keys).intersection(out).difference(self.date_keys)]
                out['wf_timestamp_latest'] = dateparser_func(max(all_times))['iso']
            except:
                out['wf_timestamp_latest'] = ''
            
        # Names, Translations, & Groups
        pick_and_join(out, list(self.name_keys), 'wf_name')
        pick_and_join(out, list(self.name_translation_keys), 'wf_name_translate')
        pick_and_join(out, list(self.group_name_keys), 'wf_group')

        # Same for array types
        if wf_attachments:
            out['wf_attachments'] = wf_attachments

        if wf_hashes:
            out['wf_hashes'] = wf_hashes

        if wf_urls:
            out['wf_urls'] = wf_urls

        return out
