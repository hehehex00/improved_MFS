from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class Calendar(Parser):
    """
     This function parses a record from calendar sheet
     see base class for doc string
    """
    
    index_name = "calendar"  # type: ignore
    parser_name = "calendar"
    sheets = ["Calendar", 'calendar']  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
