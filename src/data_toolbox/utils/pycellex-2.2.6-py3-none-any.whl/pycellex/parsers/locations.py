from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class Locations(Parser):
    """
    This function parses a record from locations sheet
    see base class for doc string
    """
    index_name = "locations"  # type: ignore
    parser_name = "locations"
    sheets = ["Locations", 'locations']  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
