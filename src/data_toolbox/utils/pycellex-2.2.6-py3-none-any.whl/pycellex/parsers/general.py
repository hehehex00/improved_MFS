from typing import Dict

from pycellex.parsers import parser


class General(parser.Parser):
    """
    This function is to extend the base line parser functions
    """
    index_name = "general"  # type: ignore
    parser_name = "general"
    sheets = ["General", 'general']  # type: ignore
    pass
