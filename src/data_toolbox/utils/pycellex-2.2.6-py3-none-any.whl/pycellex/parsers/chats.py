import re
from typing import Optional, Dict, List

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.log_utils import warn_once


class Chats(Parser):
    """
    This function parses a record from chats XRY sheet.  
    See base class for doc string.
    """
    index_name = "chats"  # type: ignore
    parser_name = "chats"
    sheets = [
        'chats', 'Chats', 
    ]  # type: ignore
    # TODO: Find the other instant_messages pseudonyms

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "group_photos": Transform(True, self.group_photos, {}),
            "chats_identifiers": Transform(True, self.chats_identifiers, {})
        }
        return self.transforms

    def group_photos(self, record: Dict) -> Optional[List[Dict[str, str]]]:
        """
        Convert all group photo values in to a usable format.
        
        Group photos are found in the "chats" sheet
        
        Args:
            record: Dict[str, Optional[str]]: Input record
            
        Returns:
            Optional[List[Dict[str, str]]: List of group photos. Each list item
            is a dictionary with keys "state" and "path".
            
        Examples
        ========
        ```python
        >>> records = {
        ...     'group_photo_1': 'Group photo state : Deleted Path : 9647518302709-1579025974.jpg',
        ...     'group_photo_2': 'Group photo state : Intact Path : 9647518302709-1580224531.jpg',
        ...     'group_photo_3': 'Group photo state : Deleted Path : 9647518302709-1574962561.jpg',
        ...     'group_photo_4': 'Group photo state : Deleted Path : 9647518302709-1573925585.jpg',
        ...     'group_photo_5': 'Group photo state : Deleted Path : 9647518302709-1573924787.jpg',
        ...     'group_photo_6': 'Group photo state : Intact Path : 9647518302709-1580224531.thumb'}
        >>> self.group_photos(records)
            [
                 {'state': 'deleted', 'path': '9647518302709-1579025974.jpg'},
                 {'state': 'intact', 'path': '9647518302709-1580224531.jpg'},
                 {'state': 'deleted', 'path': '9647518302709-1574962561.jpg'},
                 {'state': 'deleted', 'path': '9647518302709-1573925585.jpg'},
                 {'state': 'deleted', 'path': '9647518302709-1573924787.jpg'},
                 {'state': 'intact', 'path': '9647518302709-1580224531.thumb'}
             ]
        ```
        """
        
        if 'group_photo_1' not in record:
            return None
        
        out = []
        
        for key in record:
            if 'group_photo' not in key:
                continue
            entry = {}
            # Example group photo: 'Group photo state : Intact\nPath : 9647518302709-1580224531.jpg'
            split = record[key].split('\n')
            for val in split:
                subkey, subval = val.split(' : ')
                # Example subkey: "Group photo state", # # Example subval: Intact
                entry[subkey.split(' ')[-1].lower()] = subval.lower()
            out.append(entry)
            
        return out
    
    def chats_identifiers(self, record: Dict) -> Optional[Dict[str, List[Dict[str, str]]]]:
        """
        Parses participants in the chat based on application

        Args:
            record: Dict: dictionary of record entry from ufed report

        Returns:
            Optional[Dict[str, List[Dict[str, str]]]]: dictionary of parsed chat identifiers
                for to and from

        Examples
        ========
        ```python
        >>> chats_parser = Chats()
        >>> records2 = {
        ...     "chat_": 1, 
        ...     "identifier": "777000", 
        ...     "start_time_date": "Timestamp('2019-09-16 16:29:46')", 
        ...     "start_time_time": "9/16/2019 4:29:46 PM(UTC+0)", 
        ...     "last_activity_date": "Timestamp('2019-09-16 16:29:46')", 
        ...     "last_activity_time": "9/16/2019 4:29:46 PM(UTC+0)", 
        ...     "participants": "777000 Telegram _x000D_", 
        ...     "wf_application": "Telegram", 
        ...     "source": "org.telegram.chooaunf (22391220367)", 
        ...     "instant_message_": 1.0, 
        ...     "from": "777000 Telegram", 
        ...     "body":
        '''Please update Telegram to the latest version. The version you are using is out of date
        and may stop working soon. Update the app on Google Play:
        https://play.google.com/store/apps/details?id=org.telegram.messenger''',

        ...     "timestamp_date": "Timestamp('2019-09-16 16:29:46')", 
        ...     "timestamp_time": "9/16/2019 4:29:46 PM(UTC+0)", 
        ...     "starred_message": "No"}
        >>> chats_parser.chats_identifiers(records2)
        {
            "wf_from": [{"Name": "Telegram", "Telegram": "777000"}],
            "wf_to": [{"Telegram": "_x000D_"}]
        } 
        ```
        """
        
        out: Dict[str, List[Dict[str, str]]] = {}
        wf_direction = None
        app = record.get('wf_application')
        if not app:
            warn_once(f'No application (wf_application) found in record {record}')
        
        _to = record.get('to')
        _from = record.get('from')
        _participants = record.get('participants')
        
        if not any([_to, _from, _participants]):
            return None
        
        if _to:
            _to = re.sub(r'\.\.+', '', _to).strip('\n').strip()
            
        if _from and app:
            _from = re.sub(r'\.\.+', '', _from).strip('\n').strip()
            
            entry = self.extract_chat_entry(_from, app)
            
            if entry:
                out['wf_from'] = [entry]

        # Collect participants and split
        if _participants and app:
            _participants = re.sub(r'\.\.+', '', _participants)

            participants_ = re.split(r'[,\n]', _participants)

            for participant_i in participants_:
                if len(participant_i) < 4:
                    continue

                if '(owner)' in participant_i:
                    participant = participant_i.replace('(owner)', '').replace('_x000D_', '').strip()
                    wf_owner = self.extract_chat_entry(participant, app)
                    wf_owner['App'] = app
                    out['wf_owner'] = wf_owner
                    if _from in participant_i:
                        wf_direction = 'outgoing'
                    else:
                        wf_direction = 'incoming'
                if _from in participant_i:
                    participant_i = ''

            # if _from and _from in _participants:
            #     _participants = _participants.replace(_from, '')
                
                if _to and _to in participant_i:
                    _to = None

                participant = participant_i.replace('(owner)', '').replace('_x000D_', '').strip()
                
                if not participant or len(participant) <= 6:
                    continue
                else:
                    entry = self.extract_chat_entry(participant, app)

                if 'wf_to' not in out:
                    out['wf_to'] = []
                    
                if entry:
                    out['wf_to'].append(entry)
                
        # If participants was 
        if _to:
            entry = self.extract_chat_entry(_to, app)

            if entry:
                out['wf_to'] = [entry]

        if wf_direction:
            out['wf_direction'] = wf_direction

        if 'wf_to' not in out and 'wf_from' not in out:
            warn_once(f'chat_identifiers() could not extract identifiers from record {record}')

        return out
    
    @staticmethod
    def extract_chat_entry(val: str, app: str) -> Optional[Dict[str, str]]:
        """
        Extracts chat entry.  Helper function for chats_identifier

        Args:
            val (str): participants of interest in parsing chat identifiers
            app (str): application of interest

        Returns:
            Optional[Dict[str,str]]: 

        Examples
        ========
        ```python
        >>> chats_parser = Chats()
        >>> app_id = "Telegram"
        >>> val_id = "777000 Telegram"
        >>> chats_parser.extract_chat_entry(val_id, app_id)
        {Name": "Telegram", "Telegram": "777000"}
        ```        
        """
        
        entry: Dict[str, str] = {}
        
        duds = {'(owner)'}
        
        identifier_name = val.split(' ', 1)
        identifier = identifier_name[0]
        if identifier and identifier not in duds:
            entry[app] = identifier_name[0]

        if app:
            entry['App'] = app
        
        if len(identifier_name) == 2 and identifier_name[1] != identifier:
            entry['Name'] = identifier_name[1]
                
        return entry
