import logging
import regex  # type: ignore
from typing import Any, Union, Dict, List

from pycellex.parsers.parser import Parser, Transform


class Emails(Parser):
    """
    This function parses a record from emails sheet
    see base class for doc string
    """
    index_name = "emails"  # type: ignore
    parser_name = "emails"
    sheets = ["Emails", 'emails']  # type: ignore
    
    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "From": Transform(True, self.emails_from, {}),
            "To": Transform(True, self.get_emails, {"key": "To"}),
            "CC": Transform(True, self.get_emails, {"key": "CC"}),
            "BCC": Transform(True, self.get_emails, {"key": "BCC"}),
            "Account": Transform(True, self.emails_account, {})
        }
        return self.transforms

    direction_values = {
        "incoming": ["blocked", "incoming", "rejected"],
        "outgoing": ["cancelled", "canceled", "outgoing"],
    }

    source_normalized = {
        "google": "Gmail"
    }

    def emails_from(self, record: Dict[str, str]) -> Union[Dict[str, Any], None]:
        """
        This function takes the email address the email is sent from and returns
        it in the format of email, name.

        Args:
                record: Dict{str, str}: records from email sheet 
                        of UFED file; each record is
                        Dict{column name: record content}

        Returns:
                Dict[str, Any]: Dict of parsed email sender

        Examples
        ========
        ```python
        >>> from pycellex.parsers import emails
        >>> emails_parser = emails.Emails()
        >>> emails_parser.emails_from{[
        ... {["from": "sa415052@gmail.com"]}
        {"email": "sa415052@gmail.com", "Name": ""},
        ```

        """
        email = None
        fromresults = {
            "from_email": None,
            "from_name": None
        }

        try:
            email = record.get('From')
        except Exception as e:
            logging.warning(f"Error parsing email 'From': {e}")
            return fromresults

        email = record.get('From')
        if email:
            emailmatch = regex.compile(r'\S+@\S+')
            matches = emailmatch.search(email)
            if matches is not None:
                # Get the email
                matches = regex.sub('[<>\"\']', '', matches.group(0))
                fromresults['from_email'] = matches
                # get the name
                name = regex.sub(r'\S+@\S+', '', email)
                name = regex.sub('[<>]', '', name)
                if name != '':
                    fromresults['from_name'] = name.strip()

        return fromresults

    def get_emails(
            self,
            record: Dict[str, Any],
            key: str
    ) -> Dict[str, Union[None, List[str], int]]:
        """
        This function takes multiple email addresses sent 
        to, cc, and bcc and separates into format email, 
        name, and count
        
        Args:
                record: Dict{str, str}: records from email sheet 
                        of UFED file; each record is
                        Dict{column name: record content}
                key: str: key to pull emails input from record
        Returns:
                Dict[str, Union[None, List[str], int]]]: Dict of parsed email recipients

        Examples
        ========
        ```python
        >>> from pycellex.parsers import emails
        >>> emails_parser = emails.Emails()
        >>> emails_parser.get_emails(
        ... {"To": "sa415052@gmail.com"}, "To")
        {"to_emails": "sa415052@gmail.com", "to_names": "", "to_count": 1}
        ```

        """
        input_emails = None
        email_results: Dict[str, Union[None, List[str], int]] = {
            f"{key.lower()}_emails": None,
            f"{key.lower()}_names": None,
            f"{key.lower()}_count":  None
        }

        try:
            input_emails = record.get(key)
        except Exception as e:
            logging.warning(f"Error parsing email '{key}': {e}")
            return email_results
        
        if input_emails:
            emails = []
            names = []
            count = 0
            emailmatch = regex.compile(r'\S+@\S+')
            groups = input_emails.split(',')            
            for groupe in groups:
                matches = emailmatch.search(groupe)
                if matches is not None:
                    count += 1
                    matches = regex.sub('[<>\"\']', '', matches.group(0))
                    groupe = regex.sub(r'\S+@\S+', '', groupe)
                    groupe = regex.sub('[{\"<>]', '', groupe).strip()
                    if matches:
                        emails.append(str(matches))
                    if groupe:
                        names.append(str(groupe))

            email_results[f"{key.lower()}_emails"] = emails
            email_results[f"{key.lower()}_names"] = names
            email_results[f"{key.lower()}_count"] = count

        return email_results

    def emails_account(self, record: Dict[str, str]) -> Dict[str, Any]:
        """
        This function takes the Account information 
        from the record and parses it into email and name
        
        Args:
                record: Dict[str, str]: records from email sheet 
                        of UFED file; each record is
                        Dict{column name: record content}

        Returns:
                Dict[str, Any]: Dict of sending email account inclduing email and name

        Examples
        ========
        ```python
        >>> from pycellex.parsers import emails
        >>> emails_parser = emails.Emails()
        >>> emails_parser.emails_account(
        ... {"account": "sa415052@gmail.com"})
        {"email": "sa415052@gmail.com"}
        ```

        """
        account = None
        email_account = {
            'account_email': None, 
            'account_name': None}

        account = record.get('Account')
        if account:
            emailmatch = regex.compile(r'\S+@\S+')
            matches = emailmatch.search(account)
            # clean them up
            if matches is not None:
                matches = regex.sub('[<>\"\']', '', matches.group(0))      
                email_account['account_email'] = matches
                # Get the name 
                name = regex.sub(r'\S+@\S+', '', account)
                name = regex.sub('[<>]', '', name)
                if name:
                    email_account['account_name'] = name
        return email_account
