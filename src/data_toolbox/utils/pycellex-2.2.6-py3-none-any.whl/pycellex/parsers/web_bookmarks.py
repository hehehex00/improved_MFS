from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class WebBookmarks(Parser):
    """
    This function parses a record from web bookmarks sheet
    see base class for doc string
    """
     
    index_name = "web_bookmarks"  # type: ignore
    parser_name = "web_bookmarks"
    sheets = ["Web Bookmarks", "web_bookmarks"]  # type: ignore
    # TODO: Find other bookmark pseudonyms

    def _default_transforms(self) -> Dict[str, Transform]:    
        self.transforms = {}
        return self.transforms
