from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class Notes(Parser):
    """
    This function parses a record from notes sheet.
    See base class for doc string.
    """
    index_name = "notes"  # type: ignore
    parser_name = "notes"
    sheets = ["Notes", 'notes']  # type: ignore
    
    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
