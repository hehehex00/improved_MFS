from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class WebHistory(Parser):
    """
    This function parses a record from web history sheet
    see base class for doc string
    """     
    index_name = "web_history"  # type: ignore
    parser_name = "web_history"
    sheets = ["Web History", "web_history"]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:    
        self.transforms = {}
        return self.transforms
