from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class InstalledApplications(Parser):
    """
    This function parses a record from installed applications sheet
    see base class for doc string
    """
  
    index_name = "installed_applications"  # type: ignore
    parser_name = "installed applications"
    sheets = ["Installed Applications", 'installed_applications']  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
