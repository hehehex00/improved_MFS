from typing import (Any, Dict, List, Tuple, Callable, Optional)

from pycellex.parsers.parser import (Parser, Transform)
from pycellex.utils.parser_utils import (extract_entries, normalize_application, location_func)
from pycellex.utils.str_utils import is_numeric
from pycellex.utils.log_utils import warn_once
from pycellex.utils.extraction_utils import coerce_val
from pycellex.definitions import cache


class DeviceConnections(Parser):
    """
    This function parses a record from wireless networks sheet
    see base class for doc string
    """
    index_name = "device_connections"
    parser_name = "device_connections"
    sheets = ["Device Connectivity", "device connectivity",
              "Bluetooth Devices", "bluetooth devices"]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
