from typing import Dict, List, Callable

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.parser_utils import get_mac_from_record, get_datetime_from_record
from pycellex.utils.extraction_utils import coerce_val
from pycellex.utils.parser_utils import remap_dict


class DeviceInfo(Parser):
    """
    This function parses a record from device information sheet
    see base class for doc string
    """

    index_name = "device_information"
    parser_name = "device_information"
    sheets = ["Device Information", 'device_information', 'Summary', 'summary',
    'Device General Information']

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "bluetooth_device_name": Transform(
                False,
                coerce_val,
                {"key": "bluetooth_device_name", "out_type": str}
            ),
            "android_id": Transform(
                False,
                coerce_val,
                {"key": "android_id", "out_type": str}
            ),
            "bluetooth_mac_address": Transform(
                True,
                get_mac_from_record,
                {"key": "bluetooth_mac_address"}
            ),
            "detected_phone_model": Transform(
                False,
                coerce_val,
                {"key": "detected_phone_model",
                "out_type": str,
                "fallback_keys": ["model"]}
            ),
            "os_version": Transform(
                False,
                coerce_val,
                {"key": "os_version", "out_type": str}
            ),
            "detected_phone_vendor": Transform(
                False,
                coerce_val,
                {"key": "detected_phone_vendor",
                "out_type": str,
                "fallback_keys": ["manufacturer"]}
            ),
            "android_fingerprint": Transform(
                False,
                coerce_val,
                {"key": "android_fingerprint", "out_type": str}
            ),
            "mac_address": Transform(
                True,
                get_mac_from_record,
                # :TODO: Some XRY files contain a "wifi_address" field.
                # confirm whether this should be treated as the "mac_address" here.
                {"key": "mac_address"}
            ),
            "imsi": Transform(
                False,
                coerce_val,
                {"key": "imsi", "out_type": str, "fallback_keys": ["subscriber_id_imsi"]}
            ),
            "iccid": Transform(
                False,
                coerce_val,
                {"key": "iccid", "out_type": str, "fallback_keys": ["sim_identification_iccid"]}
            ),
            "phone_activation_time": Transform(
                False,
                get_datetime_from_record,
                {"key": "phone_activation_time"}
            ),
            "last_activation_time": Transform(
                False,
                get_datetime_from_record,
                {"key": "last_activation_time"}
            ),
            "factory_number": Transform(
                False,
                coerce_val,
                {"key": "factory_number", "out_type": str}
            ),
            "locale_language": Transform(
                False,
                coerce_val,
                {"key": "locale_language", "out_type": str}
            ),
            "country_name": Transform(
                False,
                coerce_val,
                {"key": "country_name", "out_type": str}
            ),
            "imei": Transform(
                False,
                coerce_val,
                {"key": "imei",
                "out_type": str,
                "fallback_keys": ["imei_meid", "mobile_id_imei"]}
            ),
            "advertising_id": Transform(
                False,
                coerce_val,
                {"key": "advertising_id", "out_type": str}
            ),
            "sim_change_time": Transform(
                False,
                get_datetime_from_record,
                {"key": "sim_change_time"}
            ),
            "hotspot_ap_name": Transform(
                False,
                coerce_val,
                {"key": "hotspot_ap_name", "out_type": str}
            )
        }
        return self.transforms

