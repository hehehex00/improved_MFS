from typing import (
    Any,
    Dict,
    List,
    Optional
)

from pycellex.parsers.parser import (
    Parser,
    Transform
)
from pycellex.utils.parser_utils import (
    extract_entries,
    normalize_application
)
from pycellex.utils.str_utils import is_numeric
from pycellex.utils.log_utils import warn_once
from pycellex.definitions import cache


class Contacts(Parser):
    """
    This function parses a record from contacts sheet
    see base class for doc string
    """
    index_name = "contacts"
    parser_name = "contacts"
    sheets = [
        "Contacts", 
        'contacts', 
        "Contacts Contacts",
        "contacts_contacts"
    ]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {"contacts": Transform(True, self.contacts_entries, {})}

        return self.transforms
    
    def contacts_entries(self, record: Dict) -> Optional[List[Dict[str, str]]]:
        """
        UFED
        Extract entries to a list of contacts

        Args:
            record (Dict): dictionary record of ufed report

        Returns:
            Optional[List[Dict[str,str]]]: list of dictionaries containing 
                information on entries, participants and other values

         Examples
        ========
        ```python
        >>> contacts_parser = Contacts()
        >>> records = {
        ... 'name': 'John Doe', 
        ... 'contact_type': 'Chat Participant', 
        ... 'entries': 'Phone-Mobile: 123456789 Phone-General: 987654321', 
        ... 'notes': 'John is a good friend', 
        ... 'last_time_contacted_time': '2017-5-1 08:24:45', 
        ... 'times_contacted': 5, 
        ... 'wf_application': 'venmo', 
        ... 'source': 'VenMo', 
        ... 'deleted': True, 
        ... 'wf_name': 'John Doe'}
        >>> contacts_parser.contacts_entries(records)
        [{"Phone": "123456789 Phone-General: 987654321"}]
        ```
        """

        contacts: List[Dict[str, str]] = []
        
        # entries, participant, and value are mutually exclusive.
        # If one exists, then the others don't exist
        # If none exist, then the contacts are likely in app-specific columns
        entries = record.get('entries')
        value = record.get('value')
        notes = record.get('notes')
        participant = record.get('participant')
        original_name = record.get('original_name')
        number = record.get('number')
        app_keys = set(cache["all_keys"]["app_keys"]).intersection(record)
        
        # Notes sometimes contains useful things like mac addresses and imeis
        if notes:
            contacts.extend(extract_entries(notes, strict=True))

        # UFED METHOD
        if any([entries, value, participant]):
            
            # Entries is a nested format. Examples:
            # 'Email-Email: \nPhone-Phone Number: 0134003210\nPhone-Phone Number:
            # 0134003210\nPhone-Phone Number:
            # +64 7-498 5225\nPhone-Phone Number: +60 11-3374 5038'
            # 'Email-: 100004761573583@facebook.com\nEmail-: shawkataziz24@yahoo.com'
            # 'Phone-: 00 961 71 856 416'
            if entries:
                contacts.extend(extract_entries(entries))
                
            # Participant is a nested format. Examples:
            # 'Name: میروص ناب \nTel: +93790282028	'
            # 'Tel: 0703542018'
            
            elif participant:
                contacts.extend(extract_entries(participant))
            
            # Value is a single value only, usually a phone number
            elif value:
                if is_numeric(value):
                    value = int(value)
                contacts.extend([{'Phone': value}])
                
        # Phonebook Method
        elif original_name and number:
            if ': ' in number:
                entry = extract_entries(number)
                
            else:
                entry = [{'Phone': number}]
            
            entry[0]['Name'] = original_name
            contacts.extend(entry)
            
        elif original_name and not number:
            return None

        # XRY METHOD
        elif len(app_keys) > 0:

            for app_key in app_keys:
                
                i = 0
                app_index = app_key
                while record.get(app_index):

                    val: Any = record.get(app_index)
                    
                    # Special situation for handling the entry key
                    if app_key == 'entry':
                        contacts.extend(extract_entries(val))
                        
                    else:
                    
                        if is_numeric(val):
                            value = int(float(val))
                            
                        app = normalize_application(app_key)
                        
                        contacts.append({app: val})
                        
                    i += 1
                    app_index = f'{app_key}_{i}'

        # Edge cases here
        else:
            account_name = record.get('account_name')
            if account_name and account_name.lower() not in \
                    cache["all_keys"]["app_normalize_lookup"]:
                
                sync_source = record.get('sync_source')
                if not sync_source:
                    sync_source = record.get('related_application')
                if sync_source:
                    app = normalize_application(sync_source)
                    
                    contacts.append({app: account_name})

        if len(contacts) == 0:
            warn_once(f'Unable to extract contacts from record {record}')
            return None

        wf_contacts = record.get('wf_contacts')
        if not wf_contacts:
            wf_contacts = []
        wf_contacts.extend(contacts)
        
        return wf_contacts
