from typing import (Any, Dict, List, Tuple, Callable, Optional)

from pycellex.parsers.parser import (Parser, Transform)


class WirelessNetworks(Parser):
    """
    This function parses a record from wireless networks sheet
    see base class for doc string
    """
    index_name = "wireless_networks"
    parser_name = "wireless_networks"
    sheets = ["Wireless Networks", "wireless networks"]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
