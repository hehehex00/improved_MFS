from typing import Dict

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.parser_utils import xry_extract_to_from, ufed_party_number


class SMSMessages(Parser):
    """
    This function parses a record from SMS messages sheet
    see base class for doc string
    
    TODOs:
        * Determine what the `smsc` column is for. When the `party` column is null, the `smsc` 
        column can contain a phone number. Not sure if it's an alternate identifier or not.
    """
    index_name = "sms"  # type: ignore
    parser_name = "sms"
    sheets = [
        "SMS Messages", 'sms_messages',
        "Messages SMS", "message_sms"
    ]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "sms_party_number": Transform(True, ufed_party_number, {}),
            "sms_xry": Transform(True, xry_extract_to_from, {})
        }
        return self.transforms
