from typing import Optional, Dict, List

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.parser_utils import ufed_party_number, xry_extract_to_from


class CallLog(Parser):
    """
    This function parses a record from call log sheet
    see base class for doc string
    """
    index_name = "call_log"  # type: ignore
    parser_name = "call_log"
    sheets = [
        "Call Log", 
        'call_log', 
        'calls', 
        'dialed_calls', 
        'missed_calls', 
        'received_calls', 
        'outgoing_calls',
        'incoming_calls'
    ]  # type: ignore

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "calls_ufed": Transform(True, ufed_party_number, {}),
            'calls_xry': Transform(True, self.calls_xry, {})
        }
        return self.transforms

    def calls_xry(self, record: Dict) -> Optional[Dict[str, List[Dict[str, str]]]]:
        """
        Extract to/from and source information from a fully parsed xry calls sheet record

        Args:
            record (Dict): A call log record that has already been transformed

        Returns:
            Dict: Record with appropriate to/from/source information extracted from the
            XRY record
            
        Examples
        ========
        ```python
        >>> p = CallLog()
    
        >>> records = {
        ... 'from': 'Facebook ID: 100003137762211 Name (Matched): Naqib Tahsin',
        ... 'to': 'Facebook ID: 100001412650567 Name (Matched): Ahmad Bakhshi'}
        >>> p.calls_xry(records)
            {'wf_to': [
                {'Name': 'Ahmad Bakhshi',
                 'Phone': '100001412650567 Name (Matched): Ahmad Bakhshi'}],
            'wf_from': [
                {'Name': 'Naqib Tahsin',
                 'Phone': '100003137762211 Name (Matched): Naqib Tahsin'}]}
        
        >>> records2 = {
                'call_type': 'Auto Rejected',
                'connection_type': 'Video',
                'direction': 'Outgoing',
                'from': 'WhatsApp ID: 252615406686@s.whatsapp.net;Name: Abuukar Axmed Amiin',
                'related_application': 'WhatsApp',
                'thread_id': '494CD269517848C8043C1D41B810728A',
                'time': '8/25/2018 2:00:35 PM UTC-04:00 (Network)',
<<<<<<< HEAD
                'to':
                'Name (Matched): Abdulmalik Sh;WhatsApp ID: 447956849337@s.whatsapp.net;Name:
                Abdulmalik Sh;SIM: 00447956849337'
                }
=======
                'to': 'Name (Matched): Abdulmalik Sh;WhatsApp ID: 447956849337@s.whatsapp.net;Name: Abdulmalik Sh;SIM:
                00447956849337'}
>>>>>>> 214138b74c7949de669267e3b90e556032717614
        >>> p.calls_xry(records2)
            {'wf_to': [
                {'WhatsApp': '447956849337@s.whatsapp.net',
                 'Name (Matched)': 'Abdulmalik Sh',
                 'SIM': '00447956849337',
                 'Name': 'Abdulmalik Sh'}],
            'wf_from': [
                {'WhatsApp': '252615406686@s.whatsapp.net',
                 'Name': 'Abuukar Axmed Amiin'}]}
        ```
        """
        
        # Skip if this is a UFED sheet. UFED always has "parties" as a key.
        invalid_keys = {'wf_to', 'wf_from', 'parties', 'party', 'party_arabic', 'number'}
        if any(invalid_keys.intersection(record)):
            return None
        
        if 'to_1' in record and 'to' not in record:
            record['to'] = record['to_1']
            
        if 'from_1' in record and 'from' not in record:
            record['from'] = record['from_1']
        
        out = xry_extract_to_from(record)
        
        if not out:
            return out
        
        # Call records are usually between single parties, yet the function above is designed
        # for multiple parties. We need to compact the multiple entries in to a single entry per
        # to/from key
        for tofrom in ['wf_to', 'wf_from']:
            if tofrom in out:
                new_entry = {}
                for entry in out[tofrom]:
                    for key in entry:
                        # print(entry[key])
                        if key not in new_entry:
                            new_entry[key] = entry[key]
                        else:
                            new_entry[key] += f', {entry[key]}'
                out[tofrom] = [new_entry]
            
        return out
