from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class SearchedItems(Parser):
    """
    This function parses a record from searched items sheet
    see base class for doc string
    """
    
    index_name = "searched_items"  # type: ignore
    parser_name = 'searched_items'
    sheets = ["Searched Items", 'searched_items']  # type: ignore
    
    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
