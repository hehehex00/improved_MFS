from typing import Dict

from pycellex.parsers.parser import Parser, Transform


class CellTowers(Parser):
    """
    This function parses a record from cell towers sheet
    see base class for doc string
    """

    index_name = "cell_towers"  # type: ignore
    parser_name = "cell_towers"
    sheets = ["Cell Towers", 'cell_towers']  # type: ignore
        
    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {}
        return self.transforms
