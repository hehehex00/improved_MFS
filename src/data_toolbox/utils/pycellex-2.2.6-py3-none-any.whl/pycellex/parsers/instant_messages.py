import regex  # type: ignore
import logging
from typing import Optional, Union, Dict, List, Tuple

from pycellex.parsers.parser import Parser, Transform
from pycellex.utils.parser_utils import location_func, parse_coordinate
from pycellex.utils.log_utils import warn_once


class InstantMessages(Parser):
    """
    This function parses a record from instant messages sheet
    see base class for doc string
    """
    index_name = "chat"  # type: ignore
    parser_name = 'instant_messages'
    sheets = [
        "Instant Messages", 'instant_messages', 
    ]  # type: ignore
    # TODO: Find the other instant_messages pseudonyms

    def _default_transforms(self) -> Dict[str, Transform]:
        self.transforms = {
            "location": Transform(True, self.instant_messages_location, {}),
            "message_type": Transform(True, self.instant_messages_type, {}),
            "from": Transform(True, self.instant_messages_to_from, {}),
        }
        return self.transforms

    source_type = {
        'telegram': 'social_media',
        'imo': 'social_media',
        'twitter': 'social_media',
        'conversations': 'social_media',
        "shareit": "point_to_point",
        "bluetooth transfers": "point_to_point",
        "bluetooth": "point_to_point",
        "zapy": "point_to_point",
        "threema": "point_to_point",
        "xender": "point_to_point",
        "cshare": "point_to_point",
        "viber": "point_to_point",
    }

    # TODO: Roll in to coordinate preparation method in primary_transform
    def instant_messages_location(self, record: Dict) -> Dict:      
        """
        Gets the location for the entry in the in the instant message
        record

        Args:
                record: Dict[str, Optional[str]]: record from instant message sheet of
                        UFED file as Dict{column name: record content}

        Returns:
                Tuple[Optional[List[float]], Optional[float], Optional[float]]: 
                A tuple containing...
                    Optional[List[float]]: location latitude, longitude
                    Optional[float]: location latitude
                    Optional[float]: location longitude

        TODOs:
                - Implement this in parsers.py and refactor
                - Consider changing output to dictionary w/ keys "latitude"
                and "longitude" to avoid confusion related to ordering

        Notes:
            - Input location tuple is assumed to be (lng, lat)
            - If lat/long is outside of valid range (i.e., lng < -180,
            lng > 180, lat < -90, lat > 90), returns None

        Examples
        ========
        ```python
        >>> from pycellex.parsers import instant_messages
        >>> instant_messages_parser = instant_messages.InstantMessages()
        >>> instant_messages_parser.instant_messages_location({
        ... "Location": "(-12.34, 56.78)"
        ... })
        ([-12.34, 56.78], -12.34, 56.78)
        >>> 
        >>> instant_messages_parser.instant_messages_location({
        ... "Location": "(-190.34, 56.78)"
        ... })
        (None, None, None)
        ```

        """
        location = record.get("Location")
        location_parsed, lat, lng = None, None, None
        out: Dict[str, Union[float, List, None]] = {
            "wf_location": location_parsed, 
            "wf_longitude": lat, 
            "wf_latitude": lng}

        if location and isinstance(location, str):
            clean_loc = regex.sub(r"\(|\,|\)", "", location)
            split_loc = clean_loc.split()

            if len(split_loc) == 2 and split_loc[0] != "" and split_loc[1] != "":
                # ensure latitude, longitude are floats
                try:
                    lng = float(split_loc[0])
                    lat = float(split_loc[1])
                except ValueError as e:
                    logging.warning(f"Failed to convert location {location}: {e}")
                    return out
            
                # ensure values are within latitude and longitude ranges
                _lng = parse_coordinate({"lng": lng}, "lng")
                if _lng:
                    lng = _lng['wf_lon'] 
                else:
                    lng = None
                _lat = parse_coordinate({"lat": lat}, "lat")
                if _lat:
                    lat = _lat['wf_lat']
                else:
                    lat = None
                location_parsed = location_func(lat, lng)

                out["wf_location"] = location_parsed
                out["wf_longitude"] = lng
                out["wf_latitude"] = lat
        
        return out
    
    def instant_messages_type(self, record: Dict) -> Optional[str]:
        """
        Gets the source application type for the entry in the in the instant
        message record

        Args:
                record: Dict[str, Optional[str]]: record from instant message sheet of
                        UFED file as Dict{column name: record content}

        Returns:
                Optional[str]: source application type (social media or point-to-point)

        Examples
        ========
        ```python
        >>> from pycellex.parsers import instant_messages
        >>> instant_messages_parser = instant_messages.InstantMessages()
        >>> instant_messages_parser.instant_messages_type({
        ... "Source Application": "SHAREit",
        ... "Source": "Bluetooth Transfers"
        ... })
        'point_to_point'
        ```

        """
        message_type: Optional[str] = None
        app = record.get('wf_application')
        if not app:
            record.get('source_application')
            
        if not app:
            return None
        
        message_type = self.source_type.get(str(app).lower())
        
        if not message_type:
            warn_once(f'Message type not found for application {app}')
            return None

        return message_type

    # TODO: Ensure this method is outputting consistent identifier values & arrays
    def instant_messages_to_from(
            self, record: Dict[str, Optional[str]]
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """
        Gets the direction and to/from content for the entry in the instant
        message record

        Args:
                record: Dict[str, Optional[str]]: record from instant message sheet of
                        UFED file as Dict{column name: record content}

        Returns:
                Dict[str, Union[str, Dict[str, Optional[str]]]]: parsed direction, to/from content

        Notes:
            - Preliminary element of parser; definitely requires enrichment

        TODOs:
            - Improve none-handling for all inputs
            - Increase parsing method consistency across applications
            - Better handle cases where To and From are both present
            - Real-world example for IMO
            - IMO incoming/outgoing appears to be backwards
            - More robust example for Twitter
            - Real-world example of Threema
            - (aj) What are these identifiers? 'S.94441b48af6e9d8e Abu Musa',
            'u.z9vubQmyLF1q6naJbWwktv iPhone mahmoud
            alahmad _x000D_', 'C73E5ADE8A8C4AFC81EF4B07E5A566DA PC-1961699615'
        
        Examples
        ========
        ```python
        >>> from pycellex.parsers import instant_messages
        >>> instant_messages_parser = instant_messages.InstantMessages()
        >>> records = {"source_application": "",
        ...     "from": "John Doe",
        ...     "to": "Jane Smith",
        ...     "Direction": "outgoing"}
        >>> instant_messages_parser.instant_messages_to_from(records)
            {"wf_from": {"UNK": "john doe"},
            "wf_to": {"UNK": "jane smith"}}
        ```
        """
        source_application = record.get('wf_application')
        # print(source_application)
        if not source_application:
            source_application = record.get('source_application')
        if not source_application:
            source_application = record.get('source')
        if not source_application:
            source_application = ''
            
        out: Dict[str, Dict[str, Optional[str]]] = {}
            
        for tofrom in ['to', 'from']:
            
            entry:  Dict[str, Optional[str]] = {}
            
            val = record.get(tofrom)

            if not val:
                continue
            
            # Parse android ID
            if val[0:2] == 'a.':
                entry['Android ID'] = val.split('a.')[1].split(' ')[0]
                
            elif val[0:2] == 'i.':
                entry['IMEI'] = val.split('i.')[1].split(' ')[0]
                
            elif val[0:2] == 'm.':
                entry['macAddr'] = val.split('m.')[1].split(' ')[0].lower()
                
            if ' +' in val:
                entry['Phone'] = val.split(' ')[1][0]
                
            if "Telegram" == source_application:  # Telegram-specific parsing
                # ID/Name/UserName
                user_id, name, user_name = self.parse_telegram(val.lower())
                entry['Telegram'] = user_id
                entry['Name'] = name
                entry['User Name'] = user_name
    
            elif 'SHAREit' == source_application:  # SHAREit-specific parsing
                user_id, name = self.parse_share(val.lower())
                entry['SHAREit'] = user_id
                entry['Name'] = name
    
            elif "Bluetooth" in source_application:  # Bluetooth-specific parsing
                # MAC addresses
                entry['macAddr'] = val.strip('\n').strip().lower()

            elif "Zapy" == source_application:  # Zapy-specific parsing
                # User names
                user_name = self.parse_zapy(val.lower())
                entry['User Name'] = user_name

            elif "Twitter" in source_application:  # Twitter-specific parsing
                user_id, name = self.parse_twitter(val.lower())
                entry['Twitter'] = user_id
                entry['Name'] = name

            elif source_application in ['Threema', "Conversations", "IMO"]:
                # Threema-specific parsing
                entry[source_application] = val.lower()
                    
            else:  # Non-specified application parsing
                warn_once(f'No rule set up for Instant Message record {record}')
                entry['UNK'] = val.lower()    
                
            out[f'wf_{tofrom}'] = entry

        return out

    def parse_telegram(
            self, source_info: str
    ) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """
        Parses Telegram To/From information into UserID/Name/UserName

        Args:
                source_info: str: Telegram "To" or "From" content

        Returns:
                Tuple: A tuple containing...
                    Optional[str]: UserID
                    Optional[str]: Name
                    Optional[str]: User Name
        """
        userid, name, username = None, None, None

        if "original account" in source_info:
            source_info_clean = regex.sub("original account ", "", source_info)
            source_info_clean_split = source_info_clean.split("(")
            name = source_info_clean_split[0].strip()

            if len(source_info_clean_split) > 1:
                username = regex.sub(r"\)", "", source_info_clean_split[1]).strip()

        elif source_info != 0:
            userid = source_info.strip()
            name = " ".join(source_info.split()[1:]).strip()

        if name is not None and "telegram" in name:
            name = regex.sub("telegram user|telegram", "", name.lower()).strip()
            if name == "":
                name = None
                
        return userid, name, username

    def parse_share(self, source_info: str) -> Tuple[Optional[str], Optional[str]]:
        """Parses SHAREit To/From information into UserID/Name

        Args:
                source_info: str: SHAREit "To" or "From" content

        Returns:
                Tuple: A tuple containing...
                    Optional[str]: UserID
                    Optional[str]: Name
        """
        source_info_clean = source_info.split(' ', 1)
        userid = source_info_clean[0]
        name = source_info_clean[1]
        return userid.strip(), name.strip()

    def parse_zapy(self, source_info: str) -> Optional[str]:
        """Parses Zapy To/From information into UserName

        Args:
                source_info: str: Zapy "To" or "From" content

        Returns:
                Optional[str]: UserName
        """
        if "self" in source_info:
            return regex.sub("self ", "", source_info).strip()
        elif source_info == "unknown":
            return None
        else:
            return source_info[0: len(source_info) // 2].strip()

    def parse_twitter(self, source_info: str) -> Tuple[Optional[str], Optional[str]]:
        """Parses Twitter To/From information into UserID/Name

        Args:
                source_info: str: Twitter "To" or "From" content

        Returns:
                Tuple: A tuple containing...
                    Optional[str]: UserID
                    Optional[str]: Name
        """
        USERID_RE = regex.compile("(\d|-\d)")
        if USERID_RE.match(source_info):
            userid = source_info.strip()
            name = None
        else:
            source_info_split = source_info.split()
            userid = source_info_split[0].strip()
            name = " ".join(source_info_split[1:]).strip()
        return userid, name

    def parse_convo(self, source_info: str) -> str:
        """Parses Conversations To/From information into UserName

        Args:
                source_info: str: Conversations "To" or "From" content

        Returns:
                str: UserName
        """
        username = regex.sub("/.+", "", source_info)
        return username.strip()
