class ParserException(Exception):
    pass


class ConfigError(Exception):
    pass
