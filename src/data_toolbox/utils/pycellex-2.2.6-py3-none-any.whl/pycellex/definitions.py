import os
from pathlib import Path

from skopeutils.cache_manager import CacheManager
from skopeutils.logger import SkopeLogger

logger = SkopeLogger().logger

PROJECT_ROOT = Path(os.path.dirname(os.path.abspath(__file__))).parent
cache = CacheManager(Path(PROJECT_ROOT, "pycellex/data"))
