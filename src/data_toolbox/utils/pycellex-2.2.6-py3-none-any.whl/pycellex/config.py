import logging
import sys
import os
from pathlib import Path
from typing import NamedTuple, Dict

from .exceptions import ConfigError


class Config(NamedTuple):
    this: str
    debug: bool
    logging: Dict[str, str]


def load_logger(enabled=True,
                level="warning",
                location=os.path.join(str(Path.home()),
                                      f"pycellex_logs.txt"),
                output="stdout",
                **kwargs):
    """
    Resets the current logging configuration then 
    sets the logging configuration settings to the input args

    Args:
        enabled (bool, optional): False will only return critical errors 
            to stdout. Defaults to True.
        level (str, optional): sets the level for messages. Defaults to "warning".
        location ([type], optional): sets output type file's output location. 
            Defaults to pycellex_logs.txt in the users home dir.
        output (str, optional): sets the output type. Defaults to "stdout".

    Raises:
        ConfigError: If the log level is not recognized
        NotImplementedError: if we need to handle logs differently in 
            the cloud we will need to go and update this
        ConfigError: If the log ouput is not recognized
    """
    # remove all current handlers
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    if not enabled:
        handlers = [logging.StreamHandler(sys.stdout)]
        logging.basicConfig(
            level=logging.CRITICAL,
            handlers=handlers)
        return

    # convert string level to logging level
    try:
        level = {"debug": logging.DEBUG, "info": logging.INFO,
                 "error": logging.ERROR, "warning": logging.WARNING,
                 "critical": logging.CRITICAL}[level]
    except KeyError:
        raise ConfigError("Log level not recognized.")

    handlers = []

    if output == "stdout":
        handlers.append(logging.StreamHandler(sys.stdout))  # alias for print()
    elif output == "file":
        handlers.append(logging.FileHandler(location, encoding='utf-8'))
    elif output == "cloud":
        raise NotImplementedError("not set yet")
    else:
        raise ConfigError("Log output not reconized")

    format = kwargs.get("format", '%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    logging.basicConfig(
        level=level,
        handlers=handlers,
        format=format,
        **kwargs
    )
