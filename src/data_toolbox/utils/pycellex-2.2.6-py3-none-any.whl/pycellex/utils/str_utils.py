import re
import logging
from typing import Dict, List, Optional

from pycellex.utils.extraction_utils import coerce_val


def normalize_str(
        record: Dict = None,
        norm_dict: Dict[str, str] = None,
        string: Optional[str] = None,
        key: str = None
) -> Optional[str]:
    """
    Normalizes a string based on a normalization dictionary; if the
    lower-case version of the string contains any of the dictionary's
    keys, then the value for that key is returned as the normalized string

    Args:
            s: Optional[str]: string to normalize
            norm_dict: Dict[str, str]: normalization dictionary

    Returns:
            Optional[str]: normalized string

    TODOs:
        - Decide what to do if the string is in 2+ of the normalization
        dictionary's keys

    Examples
    ========
    ```python
    >>> from pycellex.parsers import contacts
    >>> contacts_parser = contacts.Contacts()
    >>> contacts_parser.normalize_str(
    ... "FaceBook App",
    ... { "facebook": "Facebook Messenger",
    ...   "whatsapp": "WhatsApp",
    ...   "venmo": "Venmo" } )
    'Facebook Messenger'
    ```

    """
    in_string = None
    if string:
        in_string = string
    elif record and key:
        in_string = coerce_val(record, key=key, out_type=str)
    if not in_string:
        logging.info("parsers.normalize_str received empty str/None input")
        return None
    s_norm = None
    if isinstance(in_string, str):
        # Check if any keys in the normalization dictionary are in the
        # string to be normalized
        s_norm = in_string
        if norm_dict:
            for tag in norm_dict.keys():
                if tag in in_string.lower():
                    s_norm = norm_dict.get(tag)

    return s_norm


def sql_friendly(word: str) -> Optional[str]:
    """
    Cleans a given word to a simplified, sql friendly format

    Args:
            word: str: Word to make sql friendly

    Returns:
            str: Cleaned word

    Examples
    ========
    ```python
    >>> dirty = ' 1 L0v3 $Ql '
    >>> clean = sql_friendly(dirty)
    >>> print(clean)
    _1_l0v3_ql
    ```

    """
    original = str(word)

    # Make lowercase, strip leading/trailing whitespace
    word = original.lower().strip()

    # Replace spaces, dashes, and periods with underscores
    word = re.sub(r"\s+|-|\.+", "_", word)

    # Drop all special characters
    word = re.sub(r"[^a-z0-9_]", "", word)
    
    if not word or len(word) == 0:
        if original != '#':
            logging.warning(f"Cannot make {original} sql-friendly")
        return None

    # If first letter is a digit, make underscore
    # Note: SQL objects can't start with number
    if word[0].isdigit():
        word = '_' + word

    # Replace double underscores with single underscore
    word = re.sub('__+', '_', word)

    # Truncate the length if it's too long
    if len(word) > 31:
        word = word[:31]

    return word


def clean_sheet_name(self, sheet: str) -> Optional[str]:
    """
    Cleans a given sheet name to a predictable value

    Args:
            sheet: str: Sheet name to make not insane

    Returns:
            str: Cleaned sheet name

    TODOs:
        - tests

    Examples
    ========
    ```python
    >>> clean_sheet_name('CID1318407 CELLEX_OBJ_BASSET_7')
    'cellex'
    >>> clean_sheet_name('& Media Application Binaries')
    'media_application_binaries'
    >>> clean_sheet_name('1_XRY System Log')
    'xry_system_log'
    >>> clean_sheet_name('4_Calls')
    'calls'
    >>> clean_sheet_name('PHONE 3')
    'phone'
    >>> clean_sheet_name('Device Network Information2')
    'device_network_information'
    ```

    """

    sheet_clean = self.sql_friendly(sheet)

    if not isinstance(sheet_clean, str):
        return None

    # Many sheet names will start with a _<int>_ or end with _<int>. Remove these
    sheet_clean = re.sub(r"(^[_\d_]+)|([_\d]+$)", "", sheet_clean)
    
    # Some error sheets start with cid<7 integers>_cellex_*. Replace these with a constant string
    if 'cellex' in sheet_clean:
        sheet_clean = 'cellex'

    return sheet_clean


def is_numeric(val: str) -> bool:
    """
    Determine if the string is numeric
    
    the .isdigit() and .isnumeric() method on a string does not work with floats. 
    The purpose of this function is to provide a consolidated function to check whether a string 
    can be numerical or not.
    
    Args:
        val: str: The string to check
        
    Returns:
        bool: Whether or not the string is numeric
        
    Examples
    ========
    ```python
    >>> is_numeric('1.0')
    True
    >>> is_numeric('1')
    True
    >>> is_numeric('1.0a')
    False
    ```
    """
    try:
        float(val)
        return True
    except:
        return False


def pick_and_join(record: Dict, keys: List, out_key: str):
    """
    Use to combine multiple values in to one string. Most of the time will pick one out of
    a set of possible locations. Useful for names or translations where the name or translation
    can occur in multiple keys.

    Args:
        record (Dict): dictionary representing
                rows from a cellex ufed report
        keys (List): List of keys of interest
        out_key (str): desired key name of new combined value

    """
    
    picks = []
    for key in keys:
        if key in record:
            picks.append(str(record[key]))

    if picks:
        record[out_key] = ','.join(picks)
