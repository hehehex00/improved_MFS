from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from skopeutils.drivers.local import LocalFileDriver

from pycellex.definitions import cache


def _json_sanitize(obj: Any) -> Any:
    """
    Sanitizes complex structures for json serialization. Does not mutate the original object.

    Will convert the following types:
        set -> list
        datetime -> string ("%Y-%m-%d %H:%M:%S")
        complex -> string

    Args:
        obj (Any): A data structure

    Returns:
        A copy of data structure passed as obj, except leaf values have been sanitized
    """

    def round_nearest_second(dt_obj: datetime):
        if dt_obj.microsecond >= 500_000:
            dt_obj += timedelta(seconds=1)
            dt_obj = dt_obj.replace(microsecond=0)
        return dt_obj

    if isinstance(obj, dict):
        return {
            key: _json_sanitize(value)
            for key, value in obj.items()
        }

    if isinstance(obj, (list, tuple)):
        return type(obj)(_json_sanitize(item) for item in obj)

    if isinstance(obj, set):
        return list(_json_sanitize(item) for item in obj)

    if isinstance(obj, datetime):
        obj = round_nearest_second(obj)
        return datetime.strftime(obj, "%Y-%m-%d %H:%M:%S")
    
    if isinstance(obj, date):
        return date.strftime(obj, "%Y-%m-%d")

    if isinstance(obj, complex):
        return str(obj)

    return obj


def _invert_sheet_contents(
    sheet_contents: List[Dict[str, Any]],
    invert_by_col: str,
    data_col: str,
    file_type: str,
    fallback_invert_col: str = "") -> \
        List[Dict[str, Any]]:
    """
    Inverts a sheet to the opposing axis around the specified column.

    Help I'm inefficient! Ask Selena to fix me

    Args:
        sheet_contents: The contents of the sheet, in json
        invert_by_col: The column by which the contents should be flipped around
        data_col: The column which holds the values.

    Returns:
        The sheet contents, inverted
    """
    inverted_sheet: List[Dict] = []
    # ignore empty rows
    filtered_contents = [item for item in sheet_contents if item]
    
    all_unique_keys = set(key for item in sheet_contents for key in item.keys())
    
    # Some older XRY files have Subject as the column header.
    # Default to what the new files have, Attribute, but fall back
    # to 'Subject' if need be.
    if 'xry' in file_type and invert_by_col not in all_unique_keys:
        if fallback_invert_col in all_unique_keys:
            invert_by_col = fallback_invert_col

    constructed = defaultdict(list)
    for row in filtered_contents:
        if invert_by_col in row and data_col in row:
            key = row[invert_by_col] or ""
            # if key only contains numerics, it will be cast as an int
            key = str(key)
            if key.strip() == '':
                continue
            constructed[key.strip()].append(row[data_col])

    inverted_sheet.append(dict(constructed))

    return inverted_sheet


def excel_dict_json(file: Path, sheets: Optional[List[str]] = None) -> Dict:
    """
    Converts the elements of an excel spreadsheet ufed report to dict and json string format.

    Args:
            file: str: UFED or XRY File inculsive of the 
                       path. Must be excel file with sheets.
            file_type: str: The type of the file. Must be one of:
                            ( "ufed", "xry" )
            sheet: List[str]: The names of the sheet(s) to be read

    Returns:
            A json structure consisting of:
            {
                <sheet_name> : [
                    { <column_name>: <column_value> },
                    ...for all rows...
                ]
            }

    Notes:
            This utility converts the contents of an excel file to a dict and
            json string so that it can be used as input data for the applicable parser. 

    Examples
    ========
    ```python
    >>> from pycellex.utils import convert_utils
    >>> sheet_data = excel_dict_json(file, "Hash sets")
    >>> print(sheet_data[0])
        {"Hash sets": [{"Name": "20170815_Analyze_CVIP_HEX_MD5_CP_Hashes",
        "File info": "20170815_Analyze_CVIP_HEX_MD5_CP_Hashes.txt (3.2 MB)",
        "No. of records": 98981,
        "Modified": "5/22/2018 3:23:00 PM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "20170815_Analyze_MD5_HEX_MD5_CP_Hashes",
        "File info": "20170815_Analyze_MD5_HEX_MD5_CP_Hashes.txt (34.4 MB)",
        "No. of records": 1059808,
        "Modified": "5/22/2018 3:24:25 PM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "Analyze.Text.Hex.SHA1.Child Abuse Material (CAM) - Illegal.20180314.071749",
        "File info": "Analyze.Text.Hex.SHA1.Child Abuse Material (CAM) - Illegal.20180314.071749.txt (5.2 MB)",
        "No. of records": 129230,
        "Modified": "7/25/2018 3:29:56 PM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "Analyze.Text.Hex.SHA1.Child Abuse Material (CAM) - Illegal.20180314.072115",
        "File info": "Analyze.Text.Hex.SHA1.Child Abuse Material (CAM) - Illegal.20180314.072115.txt (33.8 MB)",
        "No. of records": 525384,
        "Modified": "7/25/2018 3:30:22 PM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "Analyze.Text.Hex.SHA1.Child Exploitive (non-CAM) _ Age Difficult.20180314.071749",
        "File info": "Analyze.Text.Hex.SHA1.Child Exploitive (non-CAM) _ Age Difficult.20180314.071749.txt (7.6 MB)",
        "No. of records": 189204,
        "Modified": "7/25/2018 3:32:35 PM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "Irrellevant-20190527",
        "File info": "md5hashes.csv (1.8 MB)",
        "No. of records": 90041,
        "Modified": "6/22/2019 7:13:51 AM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "Android NSRLFile v2.64.1",
        "File info": "Android NSRLFile.txt (2.0 GB)",
        "No. of records": 15727439,
        "Modified": "5/27/2019 2:40:20 AM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}, {"Name": "IOS_NSRLFile",
        "File info": "IOS_NSRLFile.txt (1.8 GB)",
        "No. of records": 14389991,
        "Modified": "5/27/2019 10:44:45 AM",
        "Run time": "7/9/2019 6:36:28 PM",
        "No. of detected files": 0,
        "Categories": "",
        "Comment": ""}]}
    ```
    """

    header_landmark = '#'
    if Path(file.name).suffix.upper() == '.XLSX':
        file_contents = LocalFileDriver().read_excel(file, skip_rows=True, headers=True,
                                                     header_landmark=header_landmark, sheets_to_parse=sheets or [])
    elif Path(file.name).suffix.upper() == '.XLS':
        file_contents = LocalFileDriver().read_xls(file, skip_rows=True, headers=True,
                                                   header_landmark=header_landmark, sheets_to_parse=sheets or [])
    else:
        raise ValueError("Unrecognized file type {file_type}, must be one of ('.xlsx', '.xls')")

    if set(['Device Information', 'Summary']).intersection(file_contents.keys()).__len__() == 2:
        file_type = "ufed"
    elif set(['Device General Information', 'Summary']).intersection(file_contents.keys()).__len__() == 2:
        file_type = "xry"
    else:
        raise ValueError("Unrecognized file type, must be an 'xry' or 'ufed'.")

    for sheet_name, sheet_contents in file_contents.copy().items():
        if sheet_name in cache["inverted_sheets"][file_type].keys():
            inversion_mapping = cache["inverted_sheets"][file_type][sheet_name]
            file_contents[sheet_name] = _invert_sheet_contents(
                sheet_contents,
                inversion_mapping["header_col"],
                inversion_mapping["data_col"],
                file_type,
                inversion_mapping.get("fallback_header_col", ""),
            )

    return _json_sanitize(file_contents)
