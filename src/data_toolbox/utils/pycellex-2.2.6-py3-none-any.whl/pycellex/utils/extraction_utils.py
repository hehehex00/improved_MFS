import re
from typing import Any, Dict, List, Optional, Type, Union
from pycellex.utils.log_utils import warn_once
from pycellex.definitions import cache

def get_value_from_dictlist(
        doc_list: List[Dict[str, Any]],
        key1_value: str,
        key1="Name",
        key2="Value"
) -> Any:
    """
    Gets value from one dictionary in a list of dictionaries based on
    another value in the same dictionary

    Args:
            doc_list: List[Dict[str, Any]]: list of dictionaries to be
                searched
            key1_value: str: value that must be found in the
                dictionary
            key1: str: key that must have value key1_value
            key2: str: key whose value should be returned, if key1 has
                value key1_value

    Returns:
            Any: key2 value in dictionary where key1 value equals key1_value

    TODOs:
        - TEST
        - Consider reorganizing data to avoid this method

    Examples
    ========
    ```python
    >>> from pycellex.parsers import device_info
    >>> device_info_parser = device_info.DeviceInfo()
    >>>
    >>> # Get Key2 value, when Key1 value is "Value3"
    >>> device_info_parser.([
    ... { "Key1": "Value1", "Key2": "Value2" },
    ... { "Key1": "Value3", "Key2": "Value4" },
    ... { "Key1": "Value5", "Key2": "Value5" }],
    """
    for row in doc_list:
        if row[key1] == key1_value:
            return row[key2]
    return None


def coerce_val(
        record: Dict = {},
        val: Any = None,
        key: str = None,
        out_type: Type = None,
        fallback_keys: List[str] = []
) -> Optional[Any]:
    """
    Gets a value from a dictionary based on the given key; then,
    performs checks to determine if the value or None should be returned

    Args:
            record: Dict[str, Any]: dictionary from which to get the
                value, based on the key
            key: str: key for which to extract the associated value
            out_type: Desired output type

    Returns:
            Any: value extracted if it either is of the output type or if it can be converted to that type.

    Examples
    ========
    ```python
    >>> from pycellex.utils.extraction_utils import coerce_val
    >>> rec = {"Key1": "abcd",
    ...         "Key2": 2,
    ...         "Key3": "3", 
    ...         "Key4": "5.268", 
    ...         "Key5": ""}
    >>> print(coerce_val(rec, "Key2", None, int))
    2
    >>> print(coerce_val(rec, "Key1", None, int))
    WARNING:root:Could not coerce 'abcd' to <class 'int'>
    None
    >>> print(coerce_val(rec, "Key1", None, str))
    abcd
    >>> print(coerce_val(rec, "Key4", None, float))
    5.268
    >>> print(coerce_val(rec, "Key5", None, int))
    WARNING:root:Unable to coerce because 'Key5' returned ''
    None
    >>> print(coerce_val(rec, "Key6", None, int))
    WARNING:root:Unable to coerce because 'Key6' returned 'None'
    None
    ```

    """
    value = None
    
    # xry files may have different keys for this field than UFED reports.
    if key not in record:
        for fb_key in fallback_keys:
            if fb_key in fallback_keys:
                key = fb_key
                continue

    if record and key:
        value = record[key]
    elif val is not None:
        value = val
    if value is not None and out_type is not None:
        if not isinstance(value, out_type):
            try:
                if isinstance(value, list):
                    return [out_type(val_i) for val_i in value]
                else:
                    return out_type(value)
            except Exception:
                warn_once(f"Could not coerce '{value}' to {out_type}")
                return None
        else:
            return value

    # If value is None, return as-is without warning
    else:
        return None


def coerce_bool(key: str, val: Optional[Union[str, int, bool]]) -> Optional[bool]:
    """
    Attempt to coerve the value to a boolean
    
    Args:
        key: The key used in coercing. Only used for warnings.
        val: The value to be coerced to bool.
    
    Returns:
        bool: A true or false value. Will return None if couldnt be coerced.
        
    Examples
    ========
    ```python
    >>> from pycellex.utils.extraction_utils import coerce_bool
    >>> coerce_bool(1)
    True
    >>> coerce_bool(0)
    False
    >>> coerce_bool(2)
    None
    >>> coerce_bool('yes')
    True
    >>> coerce_bool('no')
    False
    >>> coerce_bool('qwerty')
    None
    ```
    """

    if isinstance(val, bool):
        return val
    elif isinstance(val, str) and val.lower() in ('yes', '1', 'true', 'deleted'):
        return True
    elif isinstance(val, int) and val == 1:
        return True
    elif isinstance(val, str) and val.lower() in ('no', '0', 'intact', 'false'):
        return False
    elif isinstance(val, int) and val == 0:
        return False
    elif val is None:
        return False
    else:
        warn_once(f"Unable to coerce val {val} in key {key} to boolean")
    return None


def get_dict_from_str(
        record: Dict = None,
        string: Optional[str] = None,
        split_regex: str = None,
        lower_keys=False,
        key: str = ""
) -> Optional[Dict[str, str]]:
    """
    Uses a regular expression to split up a string into key/value
    pairs that are output as a dictionary

    Args:
            s: Optional[str]: string to split up
            split_regex: str: regex to use
            lower_keys: bool (optional): whether keys of the resulting
                dictionary should be lower-cased

    Returns:
            Optional[Dict[str, str]]: mapping of key/value from string based on regex

    TODOs:
        - Solve edge case where the same key appears multiple times,
        e.g., "Phone-Mobile: 123456789 Phone-Mobile: 987654321". 
        Currently, only one of the mobile phone entries will appear
        in the output

    Examples
    ========
    ```python
    >>> from pycellex.parsers import device_info
    >>> device_info_parser = device_info.DeviceInfo()
    >>>
    >>> device_info_parser(
    ... "Phone-Mobile: 123456789 Facebook-: Joe Schmo Phone-General: 987654321",
    ... "(Phone-Mobile:|Phone-General:|Facebook-:)"
    ... )
    {'Phone-Mobile': '123456789', 'Facebook-': 'Joe Schmo', 'Phone-General': '987654321'}
    ```

    """
    entries = {}
    in_string = None
    if string:
        in_string = string
    elif record and key:
        in_string = coerce_val(record, key=key, out_type=str)
    if not in_string or not split_regex:
        warn_once("parsers.get_dict_from_str received empty str/None input")
        return None

    string_split = re.split(split_regex, in_string)
    string_split = [x.strip() for x in string_split
                    if x is not None and x != ""]
    if len(string_split) % 2 != 0:
        return None

    for i in range(0, len(string_split), 2):
        entries[string_split[i][:-1]] = string_split[i + 1]

    if lower_keys is True:
        entries = {k.lower(): v for k, v in entries.items()}

    return entries
