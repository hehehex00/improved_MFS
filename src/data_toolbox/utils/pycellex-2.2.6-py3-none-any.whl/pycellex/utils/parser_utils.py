from copy import copy
import datetime
from dateparser import parse
import numpy
import pytz
import logging
import re
import regex
from typing import Any, Dict, List, Optional, Union
import pandas as pd
import datetime
from datetime import timedelta, timezone
from numpy import isnan

from pycellex.utils.str_utils import sql_friendly, is_numeric
from pycellex.utils.extraction_utils import coerce_val, get_value_from_dictlist
from pycellex.utils.log_utils import warn_once
from pycellex.definitions import cache

mac_pattern_1 = re.compile(r'[0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-]'
                           r'[0-9A-Fa-f]{2}')
mac_pattern_2 = re.compile(r'[0-9A-Fa-f]{3}[.][0-9A-Fa-f]{3}[.][0-9A-Fa-f]{3}[.][0-9A-Fa-f]{3}')


def remap_dict(record: List[Dict[str, Any]]) -> Dict:
    # Identify available info -- values of "Name" key in each dict
    key_list = []
    for item in record:
        try:
            key_list.append(item.get("Name"))
        except:
            pass

    # Reorient list of dicts to dict
    remapped_dict = {}
    for key in key_list:
        if isinstance(key, str):
            remapped_dict[key] = get_value_from_dictlist(record, key)

    return remapped_dict


def get_mac_from_record(record: Dict, key: str) -> Optional[Any]:
    return get_mac_address_from_str(coerce_val(record, key=key, out_type=str))


def get_mac_address_from_str(mac_str: Optional[str]) -> Optional[List[Any]]:
    """Gets MAC address from a string

    Args:
            mac_str: str: string in which to search for MAC address

    Returns:
            str: extracted MAC address

    Notes/TODOs:
        - This could be improved to handle a wider range of inputs
        - (aj) Most MACs in the DoD are lower case, no colons. Change to match?
        - (aj) Should validate instances with no dashes/colons

    Examples
    ========
    ```python
    >>> from pycellex.parsers import device_info
    >>> device_info_parser = device_info.DeviceInfo()
    >>> device_info_parser.get_new_mac_address_from_str("00:87:01:4C:24:3A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("MAC Address: 00:87:01:4C:24:3A Training string")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithUPPERCASE00:87:01:4C:24:3ATrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("Withlowercase00:87:01:4C:24:3ATrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithColon:00:87:01:4C:24:3ATTrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithOutColon00:87:01:4C:24:3A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("MultiMACSFirstMAC00:87:01:4C:24:3ASecondMAC00:87:01:4C:24:3A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("008.701.4C2.43A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithUPPERCASE008.701.4C2.43ATrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithPeriod.008.701.4C2.43ATTrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithOutPeriod008.701.4C2.43A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("00-87-01-4C-24-3A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithUPPERCASE00-87-01-4C-24-3ATrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithHyphen-00-87-01-4C-24-3ATTrailing text")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("WithOutHyphen00-87-01-4C-24-3A")
    "00:87:01:4C:24:3A"
    >>> device_info_parser.get_new_mac_address_from_str("MultiMACSFirstMAC00-87-01-4C-24-3ASecondMAC00-87-01-4C-24-3A")
    "00:87:01:4C:24:3A"
    ```
    
    """
    if not mac_str:
        return None

    try:
        mac_search = mac_pattern_1.findall(mac_str)
        if not mac_search:
            mac_search = mac_pattern_2.findall(mac_str)
        if not mac_search:
            return None
        return mac_search

    except:
        logging.warning(f"No valid mac detected in: {mac_str}")
        return None


def dateparser_func(dt_input: Any, force_date=False) -> Union[Dict[str, Union[str, float, None]], None]:
    """
    Runs in front of '_dtg_known_formats_parser' to split the '(UTC-3)' 
    
    from rawtime and convert it '+0300' UTC/ISO format
    
    Args:
        dt_input: str: string in which to convert to UTC/ISO format
    
    Returns:
        Union[Dict[str,Union[str, float, None]],None : UTC/ISO formated values extracted from Date/Time strings
        
    TODOs:
        * This is the slowest function in the entire package. 
          The culprit is the dateparser function.
          One idea would be to cache well known time formats, and when those fail fall back
          on the parse silver bullet.

    Examples
    ========
    ```python
    >>> dateparser_func("1:5:8")                            
    {'iso': None, 'epoch': None}
    >>> dateparser_func('10:56:58')
    {'iso': None, 'epoch': None}
    >>> dateparser_func('2019-09-03 15:06:13')
    {'iso': '2019-09-03T15:06:13', 'epoch': 1567548373}
    
    >>> dateparser_func("2018/12/19")
    {'iso': '2018-12-19', 'epoch': 1545206400}
    >>> dateparser_func("2018-12-19")
    {'iso': '2018-12-19', 'epoch': 1545206400}
    >>> dateparser_func("2018.12.19")
    {'iso': '2018-12-19', 'epoch': 1545206400}

    >>> dateparser_func("2/22/2018 10:56")
     {'iso': '2018-02-22T10:56:00', 'epoch': 1519325760}
    >>> dateparser_func("2017/5/1 8:4:5")
    {'iso': '2017-05-01T08:04:05', 'epoch': 1493651045}
    >>> dateparser_func("2019/09/03 15:06:13")
    {'iso': '2019-09-03T15:06:13', 'epoch': 1567548373}

    >>> dateparser_func("1/1/2014 12:00:15 AM")
    {'iso': '2014-01-01T00:00:15', 'epoch': 1388563215}

    >>> dateparser_func("10/19/2019 20:28 UTC")
    {'iso': '2019-10-19T20:28:00+0000', 'epoch': 1571516880}
    >>> dateparser_func("10/19/2019 20:28(UTC+3)")
    {'iso': '2019-10-19T20:28:00+0300', 'epoch': 1571506080}

    >>> dateparser_func("11/20/2019 5:41:05 PM(UTC+4:30)")
    {'iso': '2019-11-20T17:41:05+0430', 'epoch': 1574255465}
    >>> dateparser_func("2019-09-11T21:24:46+00:00")
    {'iso': '2019-09-11T21:24:46+0000', 'epoch': 1568237086}

    >>> dateparser_func("7/19/2019 UTC-04:00 6:37:45 PM")
    {'iso': '2019-07-19T00:00:00-0400', 'epoch': 1563508800}
    
    >>> dateparser_func("10:56:58 PM UTC+2:00 2/22/2018")
    {'iso': '2018-02-22T22:56:58+0200', 'epoch': 1519333018}

    >>> dateparser_func(1538382034)
    {'iso': '2018-10-01T08:20:34+0000', 'epoch': 1538382034}
    >>> dateparser_func("1538382034")
    {'iso': '2018-10-01T08:20:34+0000', 'epoch': 1538382034}
    >>> dateparser_func(43374)
    {'iso': '1970-01-01T12:02:54+0000', 'epoch': 43374}
    >>> dateparser_func("43374")
    {'iso': '1970-01-01T12:02:54+0000', 'epoch': 43374}
    >>> dateparser_func(44230.3957986111)
    {'iso': '1970-01-01T12:17:10+0000', 'epoch': 44230}
    >>> dateparser_func("40909.823287037034")
    {'iso': '1970-01-01T11:21:49+0000', 'epoch': 40909}

    >>> dateparser_func("Timestamp('2019-10-19 20:28:35.973000')")
    {'iso': '2019-10-19T20:28:35', 'epoch': 1571542115}

    ```   
    """
    utc_zone = pytz.timezone('UTC')
    dt_clean = None
    original = copy(dt_input)
    iso = None
    epoch = None

    # If not value presented, return none
    if not dt_input:
        return {'iso': None, 'epoch': None}

    # If pandas value, convert to epoch float
    if isinstance(dt_input, pd.Timestamp):
        dt_input = dt_input.timestamp()

    # If the value is a string but can be converted to numeric, treat as epoch int
    elif isinstance(dt_input, str) and is_numeric(dt_input):
        dt_input = int(float(dt_input))

    # Process as an epoch
    if isinstance(dt_input, (float, int)):
        if not isnan(dt_input):
            epoch = int(round(dt_input))
            if epoch < 73051:
                # Note: 73051 represents the difference (ordinal(1 January 2100) - ordinal(excel base date)).
                # We use this value as a cut-off in deciding whether a value is a timestamp or a excel date float.
                # We don't expect to see a date after 2100 so this is a safe threshold.
                frac_day_timedelta = datetime.timedelta(days=(dt_input - epoch))
                excel_base_date = 693594   # This value is 30 December 1899 expressed as an ordinal date.
                dt_clean = datetime.datetime.combine(datetime.date.fromordinal(epoch + excel_base_date),
                                                     datetime.time.min) + frac_day_timedelta
                dt_clean = utc_zone.localize(dt_clean)
                try:
                    epoch = int(round(datetime.datetime.timestamp(dt_clean)))
                except OSError:
                    epoch = epoch
            else:
                dt_clean = utc_zone.localize(datetime.datetime.utcfromtimestamp(epoch))
            if force_date:
                iso = dt_clean.strftime("%Y-%m-%d")
                try:
                    epoch = int(datetime.datetime.strptime(iso, "%Y-%m-%d").timestamp())
                except OSError:
                    epoch = None
            else:
                iso = dt_clean.strftime("%Y-%m-%dT%H:%M:%S%z")

    # Process as a string
    elif isinstance(dt_input, str):

        # Strip out XRY things, make lower, & strip whitespace
        dt_input = re.sub(r'\(device\)|\(network\)', '', dt_input.lower()).strip()

        # Deal with a pandas timestamp that's been converted to string
        if 'timestamp' in dt_input:
            dt_input = dt_input.split('(')[1][:-1]

        # Move Date to front. Example: "10:56:58 PM UTC+2:00 2/22/2018"
        date = re.search(r'(\d+(/|-|\.){1}\d+(/|-|\.){1}\d{1,4})', dt_input)
        if date is not None:
            dt_input = re.sub(date[1], '', dt_input).rstrip()
            dt_input = str(date[1] + ' ' + dt_input)

        # Parse date input using magic dateparser function
        # Note: We ignore any instances where the date isn't complete. An example of an incomplete
        #       date is a time-only stamp, such as "12:45:33" or month-year like "December 2015".
        #       This is to avoid creating information where information previously didn't exist
        # TODO: This is the slow part of the library
        dt_clean = parse(dt_input, settings={'STRICT_PARSING': True})

        if not dt_clean:
            warn_once(f'Could not run dateparser_func() on value {original}')
            return {'iso': None, 'epoch': None}

        t_dt_clean = copy(dt_clean)
        if not dt_clean.tzinfo:
            try:
                epoch = int(t_dt_clean.replace(tzinfo=pytz.timezone("UTC")).timestamp())
            except OSError:
                epoch = None
        else:
            try:
                epoch = int(t_dt_clean.timestamp())
            except OSError:
                epoch = None

        # If the input is too short, then we don't have the time. Output as a date only
        if (len(dt_input) < 11) or force_date:
            iso = dt_clean.strftime("%Y-%m-%d")
            try:
                epoch = int(datetime.datetime.strptime(iso, "%Y-%m-%d").timestamp())
            except OSError:
                epoch = None
        else:
            if dt_clean.tzinfo:
                iso = dt_clean.strftime("%Y-%m-%dT%H:%M:%S%z")
            else:
                iso = dt_clean.strftime("%Y-%m-%dT%H:%M:%S")

    # Otherwise we have an unknown data type
    else:
        warn_once(f'Could not run dateparser_func() on value {original} with type {type(original)}')
        iso = None
        epoch = None

    return {'iso': iso, 'epoch': epoch}


def get_datetime_from_record(record: Dict, key: str) -> Union[str, float, None]:
    iso = None
    out = dateparser_func(record.get(key))
    if out is not None:
        iso = out["iso"]
    return iso


def get_epoch_from_record(record: Dict, key: str) -> Union[str, float, None]:
    epoch = None
    out = dateparser_func(record.get(key))
    if out is not None:
        epoch = out['epoch']
    return epoch


def get_datetime_epoch(record: Dict, key: str) -> Optional[Dict[str, Union[str, float, None]]]:
    iso = None
    epoch = None

    out = dateparser_func(record.get(key))

    if out is not None:
        iso = out["iso"]
        epoch = out["epoch"]

    return {f"wf_{sql_friendly(key)}_datetime": iso, f"wf_{sql_friendly(key)}_epoch": epoch}


def parse_coordinate(record: Dict, key: str) -> Optional[Dict[str, Optional[float]]]:
    """
    Parses coordinates

    Args:
            record (Dict): record of interest
            key (str): key of interest from dictionary

    Returns:
            Optional[Dict[str,Optional[float]]]: dictionary of parsed location coordinates

    Examples
    ========
    ```python
    >>> from pycellex.parsers import device_info
    >>> device_info_parser = device_info.DeviceInfo()
    >>> device_info_parser.parse_coordinate({'Latitude': '38.8951'}, 'Latitude')
    {'wf_lat': 38.8951000}
    ```
    """

    lat = [
        "latitude",
        "lat",
        'y',
        'Y'
    ]

    long = [
        "longitude"
        "long",
        "lng",
        "lon",
        'x',
        'X'
    ]

    coord = record.get(key)
    coord = normalize_coordinate(coord)
    if isinstance(coord, float):
        if any(coord_name in key.lower() for coord_name in lat):
            if -90 <= coord <= 90:
                return {"wf_lat": coord}
            else:
                warn_once(f"Latitude fell outside of expected ranges: {coord}")
                return {"wf_lat": None}
        elif any(coord_name in key.lower() for coord_name in long):
            if -180 <= coord <= 180:
                return {"wf_lon": coord}
            else:
                warn_once(f"Longitude fell outside of expected ranges: {coord}")
                return {"wf_lon": None}
        else:
            warn_once(f"Unknown coord type for {key}. No checks for valid range.")
            return {"wf_{key}": coord}

    return None


def normalize_coordinate(coord: Union[str, float, None]) -> Union[str, float, None]:
    """
    Normalizes location coordinates

    Args:
            coord (Union[str, float, None]): coordinates in dictionary value

    Returns:
            Union[str, float, None]: normalized coordinate value

    Examples
    ========
    ```python
    >>> from pycellex.parsers import device_info
    >>> device_info_parser = device_info.DeviceInfo()
    >>> device_info_parser.normalize_coordinate("38.8951")
    38.8951000
    ```
    """

    normal_coord = coord
    if coord:
        try:
            normal_coord = float(coord)
            normal_coord = round(normal_coord, 7)
        except Exception as e:
            warn_once(f"Failed to normailze coordinate {coord}: {e}")
            return coord

    return normal_coord


def location_func(in_lat: Union[str, float, None], in_long: Union[str, float, None]) -> Optional[List[float]]:
    """ Extracts Lat/Long information, checks to see if they are within 
    the correct coordinate bounds, and converts strings to floats

    Args:
            in_lat: Union[str,None]
            in_long: Union[str,None]

    Returns:
            Dict[str, Union[float, None]]: dictionary of lat and long values

    Examples
    ========
    ```python
    >>> lati = "38.8951"
    >>> long = "-77.0364"
    >>> location_func(in_lat, in_long)
    {'lat': 38.8951, 'lng': -77.0364}
    ```

    """
    lat = normalize_coordinate(in_lat)
    lng = normalize_coordinate(in_long)

    if isinstance(lat, float) and isinstance(lng, float):
        if -180 <= lng <= 180 and -90 <= lat <= 90:
            return [lng, lat]
        else:
            warn_once(f"Location fell outside of expected ranges: lng: {lng}, lat: {lat}")
    return None


def normalize_duration(duration: Optional[Union[str, int]]) -> Optional[int]:
    """
    Calculate the duration (in seconds) from a string or int format

    Args:
            records: Optional[Dict]: single record's content of "Party" column
                    from sheet of UFED file

    Returns:
            Optional[Dict[str, Dict[str, Union[str, int]]]]: Resulting parsing
                    of "Party" column

    TODOs:
        - Further ensure robustness to edge cases (e.g., no spaces)
        - Consider whether 'count' is necessary in output

    Examples
    ========
    ```python
    >>> from pycellex.utils import get_party
    >>> sms_messages_parser.get_party({"Party":"To: 123456789 TO: 987654321 "})
    {'to': {'count': 2, 'Phone': '123456789', 'Phone1': '987654321'}}
    ```

    """
    if isinstance(duration, str):

        if 'AM' in duration or 'PM' in duration:
            return None

        elif is_numeric(duration):
            return int(float(duration))

        elif "." in duration:
            d, h, m, s = re.split(r"[(\.):]", duration)
            duration = int(
                datetime.timedelta(
                    days=int(d), hours=int(h), minutes=int(m), seconds=int(s)
                ).total_seconds()
            )

            return duration

        elif ":" in duration:
            h, m, s = duration.split(":")
            duration = int(
                datetime.timedelta(
                    hours=int(h), minutes=int(m), seconds=int(s)
                ).total_seconds()
            )

            return duration

        else:
            warn_once(f'normalize_duration() unsure how to handle value {duration}')

    elif isinstance(duration, int):
        return duration

    elif duration is None:
        return None

    warn_once(f"Unable to parse duration {duration}")
    return None


def get_direction(record: Dict, default: Optional[str] = None) -> Optional[str]:
    """
    Gets the direction of the call from the call log record

    Args:
        record (Dict): record of interest

    Returns:
        Optional[str]: Direction of the call ("incoming" or "outgoing")

    Examples
    ========
    ```python
    >>> get_direction({"Direction":"Outgoing", "Call Type": "cancelled", "Status": None})
    'outgoing'
    >>> get_direction({"Status": "sent;pending"})
    'outgoing'
    ```
    """

    direction_values = {
        'answered on external device': 'incoming',
        'blocked': 'incoming',
        'busy': 'outgoing',
        'cancelled': 'outgoing',
        'canceled': 'outgoing',
        'deleted': 'incoming',
        'deliver': 'incoming',
        'dialed': 'outgoing',
        'incoming': 'incoming',
        'incoming\xa0': 'incoming',
        'incoming;deliver': 'incoming',
        'incoming;status report': 'incoming',
        'last dialed': 'outgoing',
        'missed': 'incoming',
        'missed\xa0': 'incoming',
        'not applicable': 'general',
        'outbox': 'outgoing',
        'outgoing': 'outgoing',
        'outgoing\xa0': 'outgoing',
        'outgoing;submit': 'outgoing',
        'read': 'incoming',
        'received': 'incoming',
        'recipients': 'outgoing',
        'rejected': 'incoming',
        'sent': 'outgoing',
        'sent;completed': 'outgoing',
        'sent;pending': 'outgoing',
        'sending failed': 'outgoing',
        'submit': 'outgoing',
        'spam': 'incoming',
        'unread': 'incoming',
        'unsent': 'outgoing',
    }

    wf_direction = record.get('wf_direction')
    if wf_direction:
        return wf_direction

    direction = record.get("direction")
    call_type = record.get("call_type")
    status = record.get("status")
    type_ = record.get('type')
    folder = record.get('folder')
    to = record.get('to')
    from_ = record.get('from')
    cc = record.get('cc')
    bcc = record.get('bcc')
    deleted = record.get('deleted')
    if deleted:
        deleted = 'deleted'

    if to and not from_:
        wf_direction = 'outgoing'

    elif from_ and not to:
        wf_direction = 'incoming'

    # Instant Message method
    elif to and ('original account' in to or 'self' in to or 'Device owner' in to):
        wf_direction = 'incoming'

    elif from_ and ('original account' in from_ or 'self' in from_ or 'Device owner' in from_):
        wf_direction = 'outgoing'

    # Deal with the standard lookup table method
    elif any([direction, call_type, status, type_, folder, deleted]):
        for val in [direction, call_type, status, type_, deleted]:
            if not val:
                continue
            val = val.lower()
            if val.lower() in direction_values:
                wf_direction = direction_values[val.lower()]
                break
        if not wf_direction and type_ and type_.lower() == 'number':
            wf_direction = 'outgoing'

    # If value not in the lookup table, it may be in the parties/party key
    if 'parties' in record or 'party' in record:
        parties = record.get("parties")
        if not parties:
            parties = record.get('party')
        logging.warning("Parties = %s (type %s)", parties, type(parties))
        if parties and isinstance(parties, str) and ':' in parties:
            if 'To:' in parties and 'From:' not in parties:
                wf_direction = 'outgoing'
            elif 'To:' not in parties and 'From:' in parties:
                wf_direction = 'incoming'

    # Email method
    elif 'account_email' in record:
        account_email = record.get('account_email')
        if account_email:

            if to and account_email in str(to):
                wf_direction = 'incoming'
            elif from_ and account_email in str(from_):
                wf_direction = 'outgoing'
            elif cc and account_email in str(cc):
                wf_direction = 'incoming'
            elif bcc and account_email in str(bcc):
                wf_direction = 'outgoing'

    elif to and from_:
        # Direction is implied by columns, don't warn
        return wf_direction

    elif default and not wf_direction:
        wf_direction = default

    # At this point we failed. GAME OVER MAN!
    if not wf_direction:
        warn_once(f'get_direction() Unable to determine direction from record {record}')

    return wf_direction


def normalize_application(val: str) -> str:
    """
    Normalize common applications.

    For use with chats, call logs, contacts, and other commonly used sheets.

    NOT for use with the applications sheet. Will need some additional consideration to use
    on a wider variety of application names. In addition, sometimes the app name is empty,
    while the full app identifier (com.google.android.syncadapters.calendar) is available.
    Need to extract app name from the long version.

    Args:
        val: str: The input application name to be looked up

    Returns:
        str: The normalized application name

    Examples
    ========
    ```python
    >>> from pycellex.utils.parser_utils import normalize_application

    >>> normalize_application('Skype (iPhone)')
        'Skype'

    >>> normalize_application("org.telegram.messenger")
        'Telegram'

    >>> normalize_application("gbwhatsapp")
        'WhatsApp'
    ```
    """

    cleaned = val.lower().split(' (')[0].split(':')[0]

    if cleaned in cache["all_keys"]["app_normalize_lookup"]:
        return cache["all_keys"]["app_normalize_lookup"][cleaned]

    if '.' in cleaned:
        cleaned = cleaned.split('.', 1)[1]
        if cleaned in cache["all_keys"]["app_normalize_lookup"]:
            return cache["all_keys"]["app_normalize_lookup"][cleaned]

    warn_once(f'No application_normalize_lookup entry for value {cleaned}')

    return cleaned


def parse_attachment(val: Optional[str]) -> Optional[Dict[str, Any]]:
    """
    Convert an attachment to a dictionary
    
    Args:
        val: str: The input attachment file, typically newline delimited
    Returns
        Dict[str,Any]: The formatted dictionary
        
    Examples
    ========
    ```python
    >>> from pycellex.utils.parser_utils import parse_attachment
    >>> value = 'File Name: 92b4be50-8976-4866-938a-6cee86144e3d.thumb Path: /private/var/'
               'mobile/Containers/Shared/AppGroup/group.net.whatsapp.WhatsApp.shared/Message'
               '/Media/93792972365@s.whatsapp.net/9/2/ Type: Jpeg File Size: 2.68 KB MetaD'
               'ata (Full): Orientation: 1  ExifColorSpace: 1  ExifPixXDim: 75  ExifPixYDi'
               'm: 100 Status Changed: 4/19/2020 10:37:57 AM UTC (Device)Created: 4/19/'
               '2020 10:37:57 AM UTC (Device)Modified: 4/19/2020 10:37:57 AM UTC (Device)'
               'Hash (SHA1): 21251c7dc517dc7d4c8539b4fcbb9bb5ac67a5fedHash Value: 9f8336431'
               'cd5b653'
    >>> parse_attachment(val)
        {'File Name': '92b4be50-8976-4866-938a-6cee86144e3d.thumb',
         'Path':
         '/private/var/mobile/Containers/Shared/AppGroup/group.net.whatsapp.WhatsApp.shared/Message/Media/
         93792972365@s.whatsapp.net/9/2/',
         'Type': 'Jpeg',
         'File Size': '2.68 KB',
         'MetaData (Full)': 'Orientation: 1',
         'ExifColorSpace': 1,
         'ExifPixXDim': 75,
         'ExifPixYDim': 100,
         'Status Changed': '4/19/2020 10:37:57 AM UTC (Device)',
         'Created': '4/19/2020 10:37:57 AM UTC (Device)',
         'Modified': '4/19/2020 10:37:57 AM UTC (Device)',
         'Hash (SHA1)': '21251c7dc517dc7d4c8539b4fcbb9bb5ac67a5fe',
         'dHash Value': '9f8336431cd5b653'}
    >>> val = "/storage/emulated/0/zapya/video/MUSAFAR KALI TA RAWALE (1).mp4"
    >>> parse_attachment(val)
        {'File Name': 'MUSAFAR KALI TA RAWALE (1).mp4',
         'Path': '/storage/emulated/0/zapya/video/',
         'Type': 'mp4'}
    ```
    """

    if not val:
        return None
    
    if not isinstance(val, str):
        return None

    out: Dict[str, Union[str, int, float, None]] = {}
    key: str = ""
    result: Union[str, int, float, None] = None

    _val = re.sub('\n\n+', '\n', val)

    for line in _val.split('\n'):
        try:
            key, result = line.strip().split(': ', 1)

        except:
            try:
                file_path, file_name = line.strip().rsplit('/', 1)
                file, file_type = file_name.strip().split(".", 1)

                out['File Name'] = file_name
                out['Path'] = file_path
                out['Type'] = file_type
            except:
                try:
                    file_name, file_type = line.strip().split(".", 1)

                    out['File Name'] = line
                    out['Type'] = file_type
                except:
                    continue

        if not result:
            continue

        if is_numeric(str(result)):
            if '.' in str(result):
                result = float(result)
            else:
                try:
                    result = int(float(result))
                except:
                    pass

        out[key] = result

    return out


# Identifier Extraction Functions

def get_number(number: Optional[str], direction: Optional[str], default_app: Optional[str]) -> \
        Optional[Dict[str, List[Dict[str, str]]]]:
    """
    UFED, primarily for dialed_calls & received_calls `number` column
    Can also be used for number column in XRY sheets
    
    Args:
        number: str: The value from the `number` key
        direction: str: Either 'incoming' or 'outgoing'
        app: Optional[str]: The app to use when no app is found
        
    Returns:
        Dict[str,List[Dict[str,str]]]: wf_to/from identifier key format
        
    
    Examples
    ========
    ```python
    >>> from pycellex.utils.parser_utils import get_number
    
    >>> get_number('Name: Babamaureen Tel: +254721229446 Name (Matched): Babamaureen', 'outgoing')
        {'wf_to': [{'Name': 'Babamaureen',
                    'Phone': '+254721229446',
                    'Name (Matched)': 'Babamaureen'}]}
    
    >>> get_number('Tel: +93 78 000 2233 Viber ID: +93 78 000 2233', 'incoming')
        {'wf_from': [{'Phone': '+93 78 000 2233', 'Viber': '+93 78 000 2233'}]}
    
    >>> get_number('Number: 93786919009', 'outgoing')
        {'wf_to': [{'Phone': '93786919009'}]}
    
    >>> get_number('Name: رسولی Tel: +93791273375', 'incoming')
        {'wf_from': [{'Name': 'رسولی', 'Phone': '+93791273375'}]}
    
    >>> get_number('Tel: 0781668675;Name: یونس', 'outgoing')
        {'wf_to': [{'Phone': '0781668675', 'Name': 'یونس'}]}
    ```
    """

    entry: Dict[str, str] = {}

    if not direction:
        warn_once(
            f'get_number() direction value must be either incoming or outgoing. Value attempted: {number}, {direction}')
        return None

    if not number:
        warn_once(f'get_number() number value must be a string. Value attempted: {number}')
        return None

    if ':' not in number:
        app = 'Phone'
        if default_app:
            app = default_app
        entry = {'Phone': number}

    else:

        _number = regex.sub(" +", " ", number)  # <- Replace multiple spaces with one
        _number = _number.replace(' To:', '\nTo:').replace(' From:', '\nFrom:')
        _number = _number.replace("\r", "\n")  # <- Replace carraige return with newline
        _number = regex.sub("\n+", "\n", _number)  # <- Replace multiple new lines with one
        _number = _number.strip('\n')  # <- Remove any trailing newlines

        lines = re.split('\n|;', _number)

        for line in lines:

            try:
                app, value = line.split(': ', 1)

            except:
                warn_once(f'get_number() not sure how to parse line {line}')
                continue

            if 'Name' not in app:
                app = normalize_application(app)

            entry[app] = value

    if direction == 'incoming':
        return {'wf_from': [entry]}

    else:
        return {'wf_to': [entry]}


def get_parties(party: str, direction: Optional[str] = None, app: Optional[str] = None) -> \
        Dict[str, List[Dict[str, str]]]:
    """
    UFED
    Extracts to and from information from party (sms_messages) or parties (call_log)

    Args:
        party: str: The `party` (or `parties`) value. Must have to/from/general or a single number inside
        direction: Optional[str]: The direction of the interaction. Useful in instances where the
            to/from cannot be derived from the 
        app: The app type being used. If no app type provided, will default to Phone

    Returns:
        Dict[List[Dict[str,str]]]: to and/or from identifiers as dictionary of dictionaries. 
            Each sub dictionary per to/from will contain the identifier and name.
            
    Notes:
        * Discussion on defaulting to "to" when the direction is unknown
        * Extend functionality to the party key in the Timeline sheet? This is a slightly 
          different format, with a "from:" key and either a "to" or "participants" key.
        

    Examples
    ========
    ```python
    
    >>> from pycellex.utils.parser_utils import get_parties
    
    >>> get_parties('098766543221','Incoming')
    {'wf_from': [{'Phone': '098766543221'}]}
    
    >>> get_parties('From:  279278930 party alias To:  818602653 to alias')
    {'wf_from': [{'Phone': '279278930', 'Name': 'party alias'}],
     'wf_to': [{'Phone': '818602653', 'Name': 'to alias'}]}
    
    >>> get_parties('From: +9647739669814 ﻧـــٰཻــﯛ୭ﯛنــةهَ • ֆ🌸🐇, N_x000D_ To: +9647805542995 مصطفى منتهى')
    {'wf_from': [{'Phone': '+9647739669814','Name': 'ﻧـــٰཻــﯛ୭ﯛنــةهَ • ֆ🌸🐇, N_x000D_'}],
     'wf_to': [{'Phone': '+9647805542995', 'Name': 'مصطفى منتهى'}]}
    
    >>> get_parties('To: 07826710020 سرمد حنفيه_x000D_ To: 07506513085 ابو خالد_x000D_ To: +9647808731407 مادري')
    {'wf_to': [
            {'Phone': '07826710020', 'Name': 'سرمد حنفيه_x000D_'},
            {'Phone': '07506513085', 'Name': 'ابو خالد_x000D_'},
            {'Phone': '+9647808731407', 'Name': 'مادري'}
    ]}
    
    >>> get_parties('General:  9647711488284 party alias General:  9647714258007 ')
    {'wf_to': [
            {'Phone': '9647711488284', 'Name': 'party alias'},
            {'Phone': '9647714258007'}
    ]}
    
    >>> get_parties('From:  Naseer_x000D_ To:  ')
    {'wf_from': [{'Name': 'Naseer_x000D_'}]}
    
    >>> get_parties('To:12345678')
    {'wf_to': [{'Phone': 'To:12345678'}]}
    
    >>> get_parties('22796458505','Outgoing')
    {'wf_to': [{'Phone': '22796458505'}]}
    
    >>> get_parties('To:  22792358618                ')
    {'wf_to': [{'Phone': '22792358618'}]}
    
    >>> get_parties('UNCLASSIFIED')
    {}
    
    >>> get_parties('To: +6857330528;+67574995720;+6858301020;+6858301021;+6858301022;+6858301023;+6858301024;+6858301025;+6858301026;+6858301027;+6858301028;+6858301029;+6785202020;+6785202021;+6785202022;+6785202023;+6785202024;+6785202025')
    {'wf_to': [
      {'Phone': '+6857330528'},
      {'Phone': '+67574995720'},
      {'Phone': '+6858301020'},
      {'Phone': '+6858301021'},
      {'Phone': '+6858301022'},
      {'Phone': '+6858301023'},
      {'Phone': '+6858301024'},
      {'Phone': '+6858301025'},
      {'Phone': '+6858301026'},
      {'Phone': '+6858301027'},
      {'Phone': '+6858301028'},
      {'Phone': '+6858301029'},
      {'Phone': '+6785202020'},
      {'Phone': '+6785202021'},
      {'Phone': '+6785202022'},
      {'Phone': '+6785202023'},
      {'Phone': '+6785202024'},
      {'Phone': '+6785202025'}]}
    
    >>> get_parties('From:  asiacell _x000D_ To:  +9647733675611 رافد عمو')
    {'wf_from': [{'Phone': 'asiacell', 'Name': '_x000D_'}],
     'wf_to': [{'Phone': '+9647733675611', 'Name': 'رافد عمو'}]}
    
    >>> get_parties('General:  1249924595 Fouad Saeed_x000D_ General:  1727362401 عثمان عادل_x000D_ General:  100006490420860 عمار العاني_x000D_ General:  100023603341134 ابو رودينا الملك_x000D_ General:  100024094252702 ابو علي الكبيسي الكبيسي_x000D_ From:  100044274455551 مصعب المحمدي')
    {'wf_to': [
        {'Phone': '1249924595', 'Name': 'Fouad Saeed_x000D_'},
        {'Phone': '1727362401', 'Name': 'عثمان عادل_x000D_'},
        {'Phone': '100006490420860', 'Name': 'عمار العاني_x000D_'},
        {'Phone': '100023603341134', 'Name': 'ابو رودينا الملك_x000D_'},
        {'Phone': '100024094252702', 'Name': 'ابو علي الكبيسي الكبيسي_x000D_'}],
     'wf_from': [{'Phone': '100044274455551', 'Name': 'مصعب المحمدي'}]}
    
    >>> get_parties('From:  muvahhid1996 Roma  Ramazan To:  mamed0511 мамед 176.115.120.138 ', app='Skype')
    {'wf_from': [{'Skype': 'muvahhid1996', 'Name': 'Roma Ramazan'}],
     'wf_to': [{'Skype': 'mamed0511', 'Name': 'мамед'}]}

    ```
    """
    out: Dict[str, List[Dict[str, str]]] = {}

    if not direction:
        # When no direction can be determined, then it is most likely outgoing
        direction = 'outgoing'
    else:
        direction = direction.lower()

    if not app:
        app = 'Phone'

    # This list contains parties that are duds
    duds = ['UNCLASSIFIED']

    if not isinstance(party, str) or len(party) == 0 or party in duds:
        return out

    # Handle simple instance first. These are cases with no newlines or ':' values
    # Example: party='22796458505'
    if ': ' not in party:
        numbers = re.findall(r'\d+', party)

        if numbers and len(numbers[0]) < 6 or not numbers:
            out['wf_to'] = [{'Name': party}]

        elif 'outgoing' in direction:
            out['wf_to'] = [{'Phone': party}]

        elif 'incoming' in direction:
            out['wf_from'] = [{'Phone': party}]

        else:
            warn_once(f'Not sure how to handle party {party}')

        return out

    _party = regex.sub(" +", " ", party)  # <- Replace multiple spaces with one
    _party = _party.replace("TO:", "To:").replace("to:", "To:").replace("FROM:", "From:").replace("from:",
                                                                                                  "From:").replace(
        ' To:', '\nTo:').replace(' From:', '\nFrom:')
    _party = _party.replace("\r", "\n")  # <- Replace carriage return with newline
    _party = regex.sub("\n+", "\n", _party)  # <- Replace multiple new lines with one
    _party = _party.strip('\n')  # <- Remove any trailing newlines

    lines = _party.split("\n")
    for line in lines:

        if 'To:' not in line and 'From:' not in line and 'General:' not in line:
            warn_once(f'get_parties found an unexpected line without to/from/general: {line}')
            continue

        entries: List[Dict[str, str]] = []

        line = line.strip()

        if not line:
            continue

        tofrom_telname = line.split(':', 1)

        tofrom = tofrom_telname[0]

        telnames = tofrom_telname[1].split(
            ';')  # <- Purpose here is to split in instances where multiple numbers are ; deimited

        for telname in telnames:

            telname = telname.strip()

            if not telname:
                continue

            _tel_name = telname.strip().split(' ', 1)

            tel = _tel_name[0]

            name = None
            if len(_tel_name) == 2:
                name = _tel_name[1]

            numbers = re.findall('\d+', tel)

            if not app and (numbers and len(
                    numbers[0]) < 6 or not numbers):  # <- When too few numbers present, then the tel is actually a name
                entry = {'Name': telname}

            elif name and tel:
                entry = {app: tel, 'Name': name}

            elif tel and not name:
                entry = {app: tel}

            else:
                warn_once(f'Not sure how to handle party {party}')
                continue

            entries.append(entry)

        if not entries:
            continue

        if tofrom not in ['To', 'From', 'General']:
            warn_once(f'Unexpected tofrom value in party {party}')
            continue

        if tofrom == 'To' or tofrom == 'General' and 'outgoing' in direction:
            out_key = 'wf_to'

        elif tofrom == 'From' or tofrom == 'General' and 'incoming' in direction:
            out_key = 'wf_from'

        else:
            warn_once(f'Not sure how to handle party {party}')
            continue

        if out_key not in out:
            out[out_key] = []

        out[out_key].extend(entries)

    if not out:
        warn_once(f'Not sure how to parse party {party}')

    return out


def extract_entries(val, strict=False) -> List[Dict[str, str]]:
    """
    XRY
    Extracts identifiers from `entries` and `participant` keys

    Args:
        val (str): The value to extract nested identifiers from
        strict (bool): If one of the extracted apps is not within the list of known apps, do not add

    Returns:
        List[Dict[str,str]]: A list of dictionaries containing app:identifier lookups

    Examples
    =======
    ```python
    >>> val = 'Email-Email: Phone-Phone Number: 0134003210 Phone-Phone Number: 0134003210 Phone-Phone Number: +64 7-498 5225 Phone-Phone Number: +60 11-3374 5038'
    >>> extract_entries(val)
        [{'Phone': '0134003210'},
         {'Phone': '0134003210'},
         {'Phone': '+64 7-498 5225'},
         {'Phone': '+60 11-3374 5038'}]

    >>> val = 'Phone-: 00 961 71 856 416'
    >>> extract_entries(val)
        [{'Phone': '00 961 71 856 416'}]

    >>> val = 'Phone-_$!<Mobile>!$_: 9647706360201'
    >>> extract_entries(val)
        [{'Phone': '9647706360201'}]

    >>> val = 'Email-: 100004761573583@facebook.com Email-: shawkataziz24@yahoo.com'
    >>> extract_entries(val)
        [{'Email': '100004761573583@facebook.com'},
         {'Email': 'shawkataziz24@yahoo.com'}]

    >>> val = 'Phone-+97143677487 - Osn: +97143677487'
    >>> extract_entries(val)
        [{'Phone': '+97143677487'}]

    >>> val = 'User ID-Telegram nickname: SAQRE_1'
    >>> extract_entries(val)
        [{'Telegram': 'SAQRE_1'}]
    ```
    """
    ignore_apps = set([
        'profile',
        'profile picture',
        'signature'
    ])

    out:List[Dict[str, Any]] = []

    if not val:
        return out

    pairs = [entry.split(': ', 1) for entry in val.split('\n')]

    for pair in pairs:
        if len(pair) != 2:
            #            warn_once(f'Unexpected pair configuration in entry {val}')
            continue

        app_parts = pair[0].split('-')
        first = app_parts[0].lower()
        if first in ignore_apps:
            continue

        elif first == 'phone':
            app = 'Phone'

        elif first == 'email':
            app = 'Email'

        elif 'web address' in first:
            app = 'URL'

        elif '-' in pair[0] and 'telegram' in app_parts[1]:  # <- Bypassing the normalize_application function since
            # there are numerous telegram variants
            app = 'Telegram'

        elif '-' in pair[0] and 'User ID' in app_parts[0]:
            app = normalize_application(app_parts[1].lower().strip('-').strip())

        elif strict and pair[0].lower().strip() not in cache["app_normalize_lookup"].data:
            warn_once('Strict setting enabled, key {pair[0].lower().strip()} not in application_normalize_lookup')

        else:
            app = normalize_application(pair[0].lower().strip())

        identifier = pair[1]

        if not identifier:
            continue
        out.append({app: identifier})

    return out


def extract_nested_identifier(val: str) -> List[Dict[str, Optional[str]]]:
    """
    Extract the source type, identifier, and name from a XRY nested format

    Args:
        val (str): The input string 

    Returns:
        Dict[str, str]: A dictionary an entries key as a list with values like {'name':'john', 'identifier_type':'1234'} 
        
    Examples
    ========
    ```python
    >>> val = 'Facebook ID: 100003137762211 Name (Matched): Naqib Tahsin'
    >>> extract_nested_identifier(val)
    [{'Name': ' Naqib Tahsin', 'Facebook ID': '100003137762211'}]
    
    >>> val = 'Name: Hamid p SIM: 0787163163 WhatsApp ID: 93787163163@s.whatsapp.net Name (Matched): Hamid p'
    >>> extract_nested_identifier(val)
    [{'Name': 'Hamid p','SIM': '0787163163','WhatsApp ID': '93787163163@s.whatsapp.net','Name (Matched)': 'Hamid p'}]
    
    >>> val = 'Name (Matched): Ahmed Wali Isak;WhatsApp ID: 252615633439@s.whatsapp.net;WhatsApp ID: 252615406686@s.whatsapp.net;Name: Abuukar Axmed Amiin;WhatsApp ID: 252618791572@s.whatsapp.net'
    >>> extract_nested_identifier(val)
    [{'WhatsApp ID': '252615633439@s.whatsapp.net','Name (Matched)': 'Ahmed Wali Isak'},
     {'WhatsApp ID': '252615406686@s.whatsapp.net'},
     {'WhatsApp ID': '252618791572@s.whatsapp.net', 'Name': 'Abuukar Axmed Amiin'}]
    
    >>> val = '[Home] +919560322500'
    extract_nested_identifier(val)
    [{'Phone': '+919560322500'}]
    
    >>> val = '[Mobile] +227 91 06 60 60;[Mobile] +227 89 81 48 16'
    extract_nested_identifier(val)
    

    ```
    """

    out: List = []
    entry: Dict[str, str] = {}

    if not val:
        return out

    if not isinstance(val, str):
        val = str(val)

    val = re.sub(' +', ' ', val).strip()

    if len(val) <= 6:
        return out

    if 'Incoming' in val or 'Outgoing' in val:
        return out

    elif '\n' in val:

        try:
            # This will split the value on new lines, then load each split part as a dictionary entry
            for newline in val.strip('\n').split('\n'):
                split_vals = newline.split(': ', 1)
                if len(split_vals) <= 1:
                    continue
                app, identifier = split_vals[0], split_vals[1]
                if not identifier:
                    warn_once(f'extract_nested_identifier() Could not extract identifier from {newline}')
                    continue
                app = normalize_application(app.lower())
                out.append({app: identifier})

        except Exception:
            warn_once(f"extract_nested_identifier() Failed to extract to/from  {val}")
            return out

        return out

    # When a semicolon is in the value, the identifiers are split semicolon, with sometimes a name being present
    # Example: 'Name (Matched): Ahmed Wali Isak;WhatsApp ID: 252615633439@s.whatsapp.net;Name (Matched): Abuukar Axmed Amiin;WhatsApp ID: 252615406686@s.whatsapp.net;Name: Abuukar Axmed Amiin;WhatsApp ID: 252618791572@s.whatsapp.net'
    elif ';' in val and ';&' not in val:
        parts = val.strip(';').replace(';;', ';').split(';')
        for i, part in enumerate(parts):
            if not part or 'Name' in part:
                continue

            if ': ' in part:
                app, identifier = part.split(': ')

            elif '[ ' == part[0]:
                app, identifier = part.split('] ')
                app = app[1:]
            else:
                #                warn_once(f'extract_nested_identifier() cannot determine app type in value {val}')
                app, identifier = 'Unknown', part
            #                continue

            app = normalize_application(app)

            entry[app] = identifier

            # "Look Back" one part to determine if a named value comes before the current part
            if 'Name' in parts[i - 1]:
                name_type, name = parts[i - 1].split(': ')
                entry[name_type] = name

            out.append(entry)

    else:

        # Name (Matched): فوید Tel: 0798853242
        if 'ID: ' in val or 'Tel: ' in val or 'Name' in val:
            if 'Name' in val:
                label_name = val.replace(' (Matched)', '').split('Name:')
                if len(label_name) == 2 and label_name[1]:
                    name = re.split(r'\w+ ID: | Tel: ', label_name[1])[0].strip()
                    entry['Name'] = name

            if 'ID: ' in val or 'Tel: ' in val:
                identifier_split = re.split('ID: |Tel: ', val)
                identifier = identifier_split[1].strip()
                app = re.split('ID: |Tel: ', identifier_split[0])[0] + 'ID' if 'ID: ' in identifier_split[0] else 'Tel'
                app = normalize_application(app.lower())
                entry[app] = identifier

        elif '[' == val[0]:
            app, identifier = val.split('] ')
            app = normalize_application(app[1:].lower())
            entry[app] = identifier

        elif is_numeric(val):
            if isinstance(val, str):
                entry['Phone'] = str(int(float(val)))

        else:
            #            warn_once(f"extract_nested_identifier() Not sure how to handle this value:  {val}")
            entry['Unknown'] = val

        out.append(entry)

    return out


def xry_extract_to_from(record: Dict) -> Optional[Dict[str, List]]:
    """
    Exracts to/from identifiers from a XRY entry
    
    Args:
        record: Dict: The input record
        
    Returns:
        Optional[Dict]: A dictionary with 'wf_to' and/or 'wf_from' keys. Each key contains a list 
        of nested identifier as dictionaries.
        
    Examples
    ========
    ```python
    >>> from pycellex.utils.parser_utils import xry_extract_to_from
    
    >>> record = {'to': '799284977.0'}
    >>> xry_extract_to_from(record)
        {'wf_to': [{'Phone': '799284977'}]}
        
    >>> record = {
            'to': '781618788.0',
            'to_1': '784072462.0',
            'to_2': '93787122132.0',
            'to_4': '781371492.0',
            'to_3': '785484503.0',
        }
    >>> xry_extract_to_from(record)
        {'wf_to': [
            {'Phone': '781618788'},
            {'Phone': '784072462'},
            {'Phone': '93787122132'},
            {'Phone': '785484503'},
            {'Phone': '781371492'}
            ]
        }
        
    >>> record = {
             'from_matched': 'Hameed Noorani',
             'to_matched': 'Darvish Trn',
             'tel_to': '+93792771519',
             'tel_from': '+93795768074',
             'related_application': 'Apple SMS & MMS',
             'to_matched_1': 'Arian Safi',
             'to_matched_2': 'Hariman Herat1',
             'to_matched_3': 'MUJ1',
             'to_matched_4': 'Hakim h trn r',
             'tel_to_2': '794323216.0',
             'tel_to_3': '93793042544.0',
             'tel_to_1': '791978691.0',
             'tel_to_4': '93797798079.0'
        }
    >>> xry_extract_to_from(record)
        {'wf_to': [
            {'Phone': '+93792771519', 'Name': 'Darvish Trn'},
            {'Phone': '791978691.0', 'Name': 'Arian Safi'},
            {'Phone': '794323216.0', 'Name': 'Hariman Herat1'},
            {'Phone': '93793042544.0', 'Name': 'MUJ1'},
            {'Phone': '93797798079.0', 'Name': 'Hakim h trn r'}],
         'wf_from': [{'Phone': '+93795768074', 'Name': 'Hameed Noorani'}]}
    
    >>> record = {
         'related_application': 'Instagram',
         'from': 'Hameed',
         'from_matched': 'Hameed',
         'to_matched': 'Hameed',
         'to_instagram_id': 'hameed_noorani',
         'to_instagram_id_9': 'shoaibpopal5',
         'to_instagram_id_8': 'noorispear',
         'to_instagram_id_7': 'tonyregansystech',
         'to_instagram_id_6': 'sean_rohid',
         'to_instagram_id_3': 'nurahmadubaid',
         'to_instagram_id_4': 'naqibullahmohammadzai',
         'to_instagram_id_2': 'shohrehfaghihi',
         'from_instagram_id': 'hameed_noorani',
         'to_instagram_id_1': 'farzana.popal',
         'to_instagram_id_5': 'pilankatta'
        }
    >>> xry_extract_to_from(record)
        {'wf_from': [{'Instagram': 'hameed_noorani', 'Name': 'Hameed'}],
         'wf_to': [
                 {'Instagram': 'hameed_noorani', 'Name': 'Hameed'},
                 {'Instagram': 'farzana.popal'},
                 {'Instagram': 'shohrehfaghihi'},
                 {'Instagram': 'nurahmadubaid'},
                 {'Instagram': 'naqibullahmohammadzai'},
                 {'Instagram': 'pilankatta'},
                 {'Instagram': 'sean_rohid'},
                 {'Instagram': 'tonyregansystech'},
                 {'Instagram': 'noorispear'},
                 {'Instagram': 'shoaibpopal5'}
        ]}
    ```
    """

    out: Dict[str, List] = {}

    # Exit if the following conditions are met. These are usually status messges or internal metadata
    folder = record.get('folder')
    if folder and folder == 'Templates':
        return None
    direction = record.get('direction')
    if direction and direction == 'Not Applicable':
        return None

    # App based columns (most complex)
    # These are the keys we're looking for the in the record
    # In addition, sometimes the keys has _1, _2, ... appended on teh end to infer multiple
    app_keys = set(cache["all_keys"]["app_keys"]).intersection(record)

    # Pull the deleted key and status key. 
    # If the deleted key is True, then no identifiers will be available and we should not flag a warning
    # If the status key is "Unsent", then no identifiers will be available
    deleted = record.get('deleted')
    status = record.get('status')

    if not app_keys:
        if (
                deleted and isinstance(deleted, bool) and deleted == True
                or status and isinstance(status, str) and status in ('Unsent', 'Deleted', 'Sending Failed')
        ):
            return None

        warn_once(f'xry_extract_to_from(): Unable to find app_keys in record with keys {sorted(record.keys())}')
        return None

    direction = record.get('wf_direction')

    for app_key in app_keys:
        val = record.get(app_key)
        if not val:
            continue

        # First, determine the direction
        to_from = app_key.split('_')[0]
        if to_from not in ['to', 'from']:
            if app_key == 'tel_to':
                to_from = 'to'
            elif app_key == 'tel_from':
                to_from = 'from'
            elif app_key == 'participant':
                to_from = 'to'
            elif 'incoming' == direction:
                to_from = 'to'
            elif 'outgoing' == direction:
                to_from = 'from'
            else:
                #                warn_once(f'Encountered an unexpected direction value in record: {record}')
                to_from = 'to'

        i = 0
        app_key_index = f'{app_key}'
        name_key = f'{to_from}_matched'

        while record.get(app_key_index):
            another_val = record[app_key_index]

            if isinstance(another_val, str) and is_numeric(another_val) and '.' in val:
                another_val = another_val.split('.')[0]
            if isinstance(val, (float, int)):
                another_val = str(int(another_val))

            app = re.sub('from_|_from|to_|_to', '', app_key)

            if app_key in ['to', 'from', 'participant']:
                entry = extract_nested_identifier(another_val)

            else:
                app = normalize_application(app)
                _entry = {app: another_val}

                name = record.get(name_key)
                if name:
                    _entry['Name'] = name

                entry = [_entry]

            if f'wf_{to_from}' not in out:
                out[f'wf_{to_from}'] = []

            out[f'wf_{to_from}'].extend(entry)

            i += 1
            app_key_index = f'{app_key}_{i}'
            name_key = f'{to_from}_matched_{i}'

    if 'wf_to' not in out and 'wf_from' not in out:
        warn_once(f'xry_extract_to_from(): Unable to extract identifiers for record {record}')
        return None

    return out


def ufed_party_number(record: Dict) -> Optional[Dict[str, List[Dict[str, str]]]]:
    """
    Applies get_party or get_number specifically for UFED format

    Applies to call_log, dialed_calls, received_calls, missed_calls, sms, sms_received,
    sms_sent, deleted_sms, and deleted_sms_messages.

    See `get_number()` or `get_parties()` for examples

    Args:
        record: Dict: The input record. Record should already be transformed with wf_application
        and wf_direction keys already present

    Returns:
        Optional[Dict[str,List[Dict[str,str]]]]: a pycellex wf to/from dictionary


    """
    if not record:
        return {}
    invalid_keys = {'wf_to', 'wf_from'}
    valid_keys = {'parties', 'party', 'party_arabic', 'number'}
    matching_key = valid_keys.intersection(record)
    if any(invalid_keys.intersection(record)) or not any(matching_key):
        return {}

    key = matching_key.pop()
    value = record.get(key)

    if isinstance(value, (float, int)):
        value = str(int(float(value)))
    else:
        value = str(value)

    direction = record.get('wf_direction')
    app = record.get('wf_application')

    # Number method
    if key == 'number' and 'To:' not in value and 'From:' not in value:
        out = get_number(value, direction, app)

    # Party method
    else:
        out = get_parties(value, direction, app)

    return out
