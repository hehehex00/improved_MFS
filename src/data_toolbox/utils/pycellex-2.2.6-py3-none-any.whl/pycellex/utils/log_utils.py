# -*- coding: utf-8 -*-

import logging

warnings = set()  # type: ignore


def warn_once(warning: str):
    if warning not in warnings:
        logging.warning(warning)
        warnings.add(warning)
