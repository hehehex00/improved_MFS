def remove_fields(pycellex_res: list):
    keep_keys = ['iccid', 'imsi', 'imei', 'msisdn', 'report_type']

    for i, d_i in enumerate(pycellex_res):
        if list(d_i.keys())[0] in ['Device Information', 'Summary']:
            d_i = pycellex_res.pop(i)
            key = list(d_i.keys())[0]
            vals = list(d_i.values())[0]
            new_vals = []
            for val_i in vals:
                new_val_i = {keep_k_i: val_i.get(keep_k_i) for keep_k_i in keep_keys if val_i.get(keep_k_i)}
                if len(new_val_i) > 0:
                    new_vals.append(new_val_i)
            d_i = {key: new_vals}
            pycellex_res.insert(i, d_i)
    return pycellex_res
