from pathlib import Path
import requests
from typing import List
import sys
import json
root_dir = sys.argv[0]
# root_dir = r'C:\Users\d01-2\Desktop\Delete\ufed_test_other'


def example_parse_cellex(files: List[Path], parsers=[], source=None):
    """

    Args:
        files:

    Returns: List[dicts]

    """
    params = {}
    params['parsers'] = ','.join(parsers)
    if source is not None:
        if isinstance(source, dict):
            params['source'] = json.dumps(source)
    response = requests.post(
        # "http://localhost:7070/api/parse_cellex",
        "http://localhost:5000/api/parse_cellex",
        # "http://dev-nifi.funnel.local:7000/api/parse_cellex",
        files={Path(file).name: open(file, 'rb') for file in files},
        params=params)

    return response

# test_file = r"W:\PyCELLEX_Perf_Tests\GREEN\34\34-2.xlsx"
# test_file = r"C:\Users\d01-2\Desktop\Delete\ufed_test\2-27_banner.xlsx"
test_file = r"F:/S3_downloads/harmony_ingest/CELLEX_Transfer/20210211_1-1000/NMEC-2015-108699-ELC(2).XLSX"

# test_file = glob(r'C:\Users\d01-2\Desktop\Delete\problems\splits\split_2\col_mask\*.xlsx')
# test_file = r"C:\Users\d01-2\Desktop\Delete\problems\190405_05SYR GOALIE 32 - Phone (eefd).xlsx"
out_dir = r'C:\Users\d01-2\Desktop\Delete\ufed_out'

if not isinstance(test_file, list):
    test_file = [test_file]
if test_file.__len__() > 1:
    for file_i in test_file:
        print(Path(file_i).stem)
        try:
            outfile = Path(out_dir) / (Path(file_i).stem + ".json")
            if outfile.is_file():
                print('   Skip')
                continue
            result = example_parse_cellex([file_i])
            print(result.text, file=open(outfile, 'w'))
        except:
            continue
else:
    result = example_parse_cellex(test_file, parsers=['summary', 'device_information', 'user_accounts',
                                                       'call_log', 'chats', 'contacts', 'emails', 'instant_messages',
                                                       'messages_chat', 'sms_messages'],
                                  source={'location': 'S3', 'bucket': 'harmony-ingest',
                                          'key': 'CELLEX_Transfer/20210211_1-1000/NMEC-2015-108699-ELC(2).XLSX'})
    outfile = Path(out_dir) / (Path(test_file[0]).stem + ".json")
    print(result.text, file=open(outfile, 'w'))

## Example call
# for f in Path(root_dir).glob('**/*.xlsx'):
#     if f.is_file():
#         print(f)
#         result = example_parse_cellex([f])
#         print(result.text, file=open(Path( root_dir + "/Parsed/" + f.stem + ".txt"), "a"))
