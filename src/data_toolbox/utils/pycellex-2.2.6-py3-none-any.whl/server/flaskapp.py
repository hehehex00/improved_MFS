"""
Flask server to support deploying the Phone Normalizer as a standalone web application
"""

import json
import logging
from pathlib import Path

from pycellex.parsers import autofill, calendar, call_log, cell_towers, chats, contacts, cookies, device_info, emails, \
    installed_applications, instant_messages, locations, messages_chat, notes, passwords, searched_items, \
    sms_messages, timeline, user_accounts, user_dictionary, user_files, web_bookmarks, web_history, wireless_networks, \
    device_connections
from pycellex.utils.convert_utils import excel_dict_json
import flask
from flask_cors import CORS

from server.definitions import SERVER_ROOT
_API_VERSION = 1
_DEFAULT_MIN_VERSION = 1
_DEFAULT_MAX_VERSION = 1 << 31

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.DEBUG)

APP = flask.Flask(__name__)
_CORS = CORS(APP)

PARSER_DICT = {'autofill': autofill.Autofill, 'calendar': calendar.Calendar, 'call_log': call_log.CallLog,
               'cell_towers': cell_towers.CellTowers, 'chats': chats.Chats, 'contacts': contacts.Contacts,
               'cookies': cookies.Cookies, 'device_info': device_info.DeviceInfo, 'emails': emails.Emails,
               'installed_applications': installed_applications.InstalledApplications,
               'device_information': device_info.DeviceInfo, 'instant_messages': instant_messages.InstantMessages,
               'locations': locations.Locations, 'messages_chat': messages_chat.MessagesChat,
               'notes': notes.Notes, 'passwords': passwords.Passwords, 'user_files': user_files.UserFiles,
               'searched_items': searched_items.SearchedItems, 'sms_messages': sms_messages.SMSMessages,
               'timeline': timeline.Timeline, 'user_accounts': user_accounts.UserAccounts,
               'user_dictionary': user_dictionary.UserDictionary, 'web_bookmarks': web_bookmarks.WebBookmarks,
               'web_history': web_history.WebHistory, 'wireless_networks': wireless_networks.WirelessNetworks,
               'device_connections': device_connections.DeviceConnections, 'summary': device_info.DeviceInfo}


@APP.route('/api/')
def check_functioning() -> None:
    """
    Root path for testing that the API is working.

    Returns:
        None
    """
    return flask.send_file(str(Path(SERVER_ROOT, "static", "techno_viking.gif")))


@APP.route('/api/parse_cellex', methods=['POST'])
def parse_cellex() -> flask.Response:
    """
    POST one or more parsed records from CELLEX
    
    Returns:
        flask.Response (List[Dict[str, str]])
    """
    logging.warning("starting")

    @flask.after_this_request
    def add_header(response: flask.Response):
        if APP.debug:
            response.headers['Access-Control-Allow-Origin'] = '*'

        return response

    files = flask.request.files
    logging.warning("files")

    if 'parsers' in flask.request.args:
        parsers = flask.request.args.get('parsers').split(',')
        seen = set()
        parsers_init = []
        for parser_i in parsers:
            if PARSER_DICT.get('_'.join(parser_i.split(' ')).lower()) is None:
                continue
            init_parser_i = PARSER_DICT.get('_'.join(parser_i.split(' ')).lower())
            if init_parser_i.parser_name not in seen:
                parsers_init.append(init_parser_i)
                seen.add(init_parser_i.parser_name)
    else:
        parsers_init = []
    if len(parsers_init) == 0:
        parsers_init = [autofill.Autofill, calendar.Calendar, call_log.CallLog, cell_towers.CellTowers,
                        chats.Chats, contacts.Contacts, cookies.Cookies, device_info.DeviceInfo,
                        emails.Emails, installed_applications.InstalledApplications,
                        instant_messages.InstantMessages, locations.Locations, messages_chat.MessagesChat,
                        notes.Notes, passwords.Passwords, searched_items.SearchedItems,
                        sms_messages.SMSMessages, timeline.Timeline, user_accounts.UserAccounts,
                        user_dictionary.UserDictionary, user_files.UserFiles, web_bookmarks.WebBookmarks,
                        web_history.WebHistory, wireless_networks.WirelessNetworks,
                        device_connections.DeviceConnections]

    pycellex_results = []

    for filename, file in files.items():
        parsed_dict = excel_dict_json(file)
        logging.warning("to dict")
        for key in parsed_dict.keys():
            logging.warning(key)
            for parser in parsers_init:
                if key in parser.sheets:
                    parseclass = parser()
                    parsed_data = parseclass.parse_document(records=parsed_dict[key])
                    pycellex_results.append({key: parsed_data})

    json_results = json.dumps(pycellex_results, default=str, indent=2)

    return flask.Response(
        json_results,
        status=200,
    )


if __name__ == "__main__":
    APP.run(host="0.0.0.0", debug=True, use_reloader=False)
