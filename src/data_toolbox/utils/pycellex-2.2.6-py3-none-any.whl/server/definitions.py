"""Global declarations"""
from pathlib import Path

__all__ = ['SERVER_ROOT']

# Project root is two levels up
SERVER_ROOT = Path(__file__).absolute().parent
