from setuptools import setup, find_packages


setup(
    name="skopeutils",
    version="0.1.5",
    author="EOP",
    description="General utilities across EOP projects",
    url="https://gitlab.wildfireworkspace.com/eop/skopeutils",
    install_requires=[
        "openpyxl>=3.0.7,<4.0",
        "psycopg2_binary",
        "PyYAML>=6.0,<7.0",
        "tqdm>=4.62.3,<5.0",
        "xlrd>=2.0.1,<3.0",
    ],
    python_requires=">=3.8",
    packages=find_packages(exclude=["*tests*", "*docs*", "*notebooks*"]),
    include_package_data=True,
)
