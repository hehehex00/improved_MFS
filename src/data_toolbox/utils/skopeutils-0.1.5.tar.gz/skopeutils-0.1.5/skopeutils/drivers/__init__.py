"""Driver init, defines ABC"""
from abc import ABC, abstractmethod
from typing import Dict, List, Union


class Driver(ABC):  # pylint: disable=too-few-public-methods
    """
    Abstract base method for a serialization driver
    """
    @abstractmethod
    def append_to_table(self, destination_table: str, data: List[Union[List, Dict]]):
        """
        Abstract method for appending data to a "table".

        Returns:
            None
        """
