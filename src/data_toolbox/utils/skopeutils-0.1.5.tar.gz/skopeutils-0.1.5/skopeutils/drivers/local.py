"""Driver for handling common workflows against simple data files.
Supports:
    - Excel
    - CSV/TSV
"""
from collections import defaultdict
from copy import deepcopy
import csv
import datetime
from pathlib import Path
import re
from typing import Any, Dict, Generator, List, Optional, Union

import openpyxl.cell.read_only
from openpyxl.reader.excel import load_workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl import Workbook
import xlrd

from skopeutils.logger import SkopeLogger
from skopeutils.deep_nesting_helpers import merge_overwrite


class _FileStreamWriter(SkopeLogger):  # pylint: disable=too-many-instance-attributes
    """
    Abstraction of a file that's being written. Holds the file open until the
    """

    def __init__(self, path: Path, _is_stream: bool, **kwargs):
        super().__init__()

        self.path: Path = path
        self.is_stream: bool = _is_stream

        self.needs_header: bool = False
        if not self.path.exists():
            self.needs_header = True

        self.file_stream = open(  # pylint: disable=consider-using-with
            str(path),
            kwargs.get("mode", "a+"),
            encoding="utf-8"
        )
        self.writer = None

        self.all_keys: set = set()
        self.write_kwargs: dict = kwargs

        self.header_order = []

    def __del__(self):
        """Garbage collection - need to make sure system buffer gets cleared"""
        self.file_stream.close()

    def __repr__(self):
        """Printed representation"""
        return f"<FileStreamWriter {self.path}>"

    def close(self):
        """Closes the file and makes sure the buffer is cleared"""
        self.file_stream.close()

    def write(self, data: List[Union[dict, list]], **kwargs) -> None:
        """
        Simple wrapper around the private write methods. Once this method is called with valid data,
        it will be overwritten with the appropriate writing method such that calling .write() again
        will instead call that method.

        Args:
            data (List[Union[dict, list]]): The data to be written to file

        Keyword Args:
            See _write_dicts_to_csv and _write_lists_to_csv for their corresponding keyword args.

        Returns:
            True
        """
        if not data:
            return

        if not isinstance(data[0], (list, dict)):
            raise ValueError(f"Unsupported data type in first index: {type(data[0])}")

        # Depending on whether lists or dicts get passed, this method will be overwritten with the
        # corresponding method
        if isinstance(data[0], dict):
            setattr(self, "write", self._write_dicts_to_csv)
            self.write(data, **kwargs)

        elif isinstance(data[0], list):
            setattr(self, "write", self._write_lists_to_csv)
            self.write(data, **kwargs)

        else:
            raise ValueError(f"Unsupported data type {type(data)}")

    def _write_dicts_to_csv(self, data: List[dict], **kwargs) -> None:
        """
        Writes a list with nested dictionaries to csv. Uses flatten_obj to handle deep nesting.

        Args:
            data: the data structure to write out
            path: the path to write to (includes file name). Will write to "write_out.csv" in your
                  home directory if no path is specified

        Keyword Args:
            ordering: pass a list of headers (in order) to specify column ordering. Any unspecified
                      headers will be appended to the end of the column list in alphabetical order
            delete_blank: (Default False) If True, will remove columns that are always
            mode (str): (Default 'w+') the writing mode

        Returns:
            True
        """

        ordering = self.write_kwargs.get("ordering", kwargs.get("ordering", []))
        all_keys = set(key for dct in data for key in dct.keys())
        ordering += sorted(list(set(all_keys) - set(ordering)))

        if not self.all_keys:
            self.all_keys = ordering

        # New keys are a problem because we can't edit only the first line without rewriting the
        # entire file
        elif not all_keys.issubset(self.all_keys):
            raise KeyError(f"New column(s) found: {', '.join(self.all_keys - all_keys)}. "
                           "All columns must be declared in the first .write() call.")

        delete_cols = []
        if self.write_kwargs.get("delete_blank", kwargs.get("delete_blank", False)):
            if self.is_stream:
                raise ValueError("The delete_blank keyword argument is not supported for streams.")

            # Remove from the deletion list if any record contains something
            delete_cols = all_keys.copy()
            for column in all_keys:
                if any(bool(item[column]) for item in data):
                    delete_cols.remove(column)

                # All fields have been found to contain data
                if not delete_cols:
                    break

        if not self.writer:
            self.writer = csv.DictWriter(self.file_stream, fieldnames=ordering)

        if self.needs_header:
            self.writer.writeheader()
            self.needs_header = False

        for row in data:
            for column in delete_cols:
                row.pop(column)

            self.writer.writerow(
                {key: self.json_sanitize(value) for key, value in row.items()}
            )

        self.file_stream.flush()
        self.logger.info("Wrote to %s", self.path)

    def _write_lists_to_csv(self, data: List[list], **kwargs) -> None:
        """
        Writes a list of lists to csv.

        Args:
            data: the data structure to write out

        Kwargs:
            headers:
        Returns:

        """
        headers = kwargs.get("headers", None)

        if not self.writer:
            self.writer = csv.writer(self.file_stream)

        if self.needs_header:
            self.writer.writerow(headers)
            self.needs_header = False

        for row in data:
            self.writer.writerow(self.json_sanitize(row))

        self.file_stream.flush()
        self.logger.info("Wrote to %s", self.path)

    @staticmethod
    def stringify_number(value: Union[int, float]) -> Union[str, int, float]:
        """
        Safely converts a numeric value to a string

        Args:
            value (str): the string to test

        Returns:
            (str)
        """
        if isinstance(value, float):
            return str(int(value))

        if isinstance(value, int):
            return str(value)

        return value

    def json_sanitize(self, obj: Any):
        """
        Sanitizes complex structures for json serialization. Does not mutate the original object.

        Will convert the following types:
            set -> list
            datetime -> string ("%Y-%m-%d %H:%M:%S")
            complex -> string

        Args:
            obj (Any): A data structure

        Returns:
            A copy of data structure passed as obj, except leaf values have been sanitized
        """

        if isinstance(obj, dict):
            yield {
                key: self.json_sanitize(value)
                for key, value in obj.items()
            }

        if isinstance(obj, (list, tuple)):
            yield type(obj)(self.json_sanitize(item) for item in obj)

        if isinstance(obj, set):
            yield list(self.json_sanitize(item) for item in obj)

        if isinstance(obj, (datetime.date, datetime.datetime)):
            yield datetime.datetime.strftime(obj, "%Y-%m-%d %H:%M:%S")

        if isinstance(obj, complex):
            yield str(obj)

        yield obj


class _ExcelStreamWriter(SkopeLogger):  # pylint: disable=too-many-instance-attributes
    """
    Abstraction of an Excel file that's being written.
    """

    def __init__(self, path: Path, _is_stream: bool, **kwargs):
        super().__init__()
        self.path: Path = path
        self.is_stream: bool = _is_stream

        self.file_stream = Workbook(write_only=True, )
        self.sheets = {}
        self.save_loc = path
        self.write_method_by_sheet = {}

        self.all_keys: Dict[str, set] = {}
        self.header_order: Dict[str, list] = {}
        self.needs_header: Dict[str, bool] = {}

        self.write_kwargs: Dict[str, dict] = kwargs

        # { sheet_name : [ { ..format rule.. } ] }
        self.row_format_rules: Dict[str, List[Dict[str, Any]]] = {}
        self.cell_format_rules: Dict[str, List[Dict[str, Any]]] = {}

    def __del__(self):
        """Garbage collection - need to make sure system buffer gets cleared"""
        self.file_stream.close()

    def __repr__(self):
        """Printed representation"""
        return f"<FileStreamWriter {self.path}>"

    def close(self):
        """Close the stream"""
        self.file_stream.save(self.path)
        self.file_stream.close()

    def apply_row_formatting(
            self,
            row: Union[List[Any], Dict[str, Any]],
            sheet_name: str,
            sheet_formatting_rules: List[Dict[str, Any]]
    ):
        """
        Applies formatting to a given row.

        {
            <sheet name>: {
                "_func": A callable that should accept a single argument (the value of the cell)
                         and return a Boolean. If not supplied, formatting will be applied to all
                         cells in the column
                "alignment": An instance of openpyxl.styles.Alignment
                "border": An instance of openpyxl.styles.Border
                "fill": An instance of openpyxl.styles.PatternFill
                "font": An instance of openpyxl.styles.Font
            }
        }

        Args:
            row (the :
            sheet_name:
            sheet_formatting_rules:

        Returns:

        """
        # can have multiple format rules
        for format_method in sheet_formatting_rules:
            method = deepcopy(format_method)
            if not method.pop("_func", lambda x: True)(row):
                continue

            if isinstance(row, dict):
                out = {}
                for key, value in row.items():
                    cell = WriteOnlyCell(self.sheets[sheet_name], value=value)
                    cell.alignment = method.get("alignment")  # pylint: disable=assigning-non-slot
                    cell.border = method.get("border")  # pylint: disable=assigning-non-slot
                    cell.font = method.get("font")  # pylint: disable=assigning-non-slot
                    cell.fill = method.get("fill")  # pylint: disable=assigning-non-slot
                    out[key] = cell
                return out

            if isinstance(row, list):
                out = []
                for value in row:
                    cell = WriteOnlyCell(self.sheets[sheet_name], value=value)
                    cell.alignment = method.get("alignment")  # pylint: disable=assigning-non-slot
                    cell.border = method.get("border")  # pylint: disable=assigning-non-slot
                    cell.font = method.get("font")  # pylint: disable=assigning-non-slot
                    cell.fill = method.get("fill")  # pylint: disable=assigning-non-slot
                    out.append(cell)

                return out

            raise TypeError(f"Row formatting expected a list or dict, got {type(row)}")

        return row

    def apply_cell_formatting(
            self, data: Any, sheet_name: str, formatting_rules: List[Dict[str, Any]]
    ) -> Any:
        """
        Applies formatting to a given cell, identified by the column (column name if the row is a
        dictionary, or index number if its a list) it belongs to.

        All keys (other than <column_name_or_index>) in the below example format are optional.

        Expected format:
        {
            <column_name_or_index>: {
                "_func": A callable that should accept a single argument (the value of the cell)
                         and return a Boolean. If not supplied, formatting will be applied to all
                         cells in the column
                "alignment": An instance of openpyxl.styles.Alignment
                "border": An instance of openpyxl.styles.Border
                "fill": An instance of openpyxl.styles.PatternFill
                "font": An instance of openpyxl.styles.Font
            }
        }

        Preset colors are available from openpyxl.styles.Color
        Preset fonts are available from from openpyxl.styles.Font
        For additional information, reference https://openpyxl.readthedocs.io/en/stable/styles.html.

        Args:
            data (Any): The value of the cell
            sheet_name (str): The name of the sheet that the cell belongs to
            formatting_rules (dict): The format rules for this particular
                                     sheet. See the above format example.

        Returns:
            (Any) Either the original cell value (data) or a openpyxl.cell.Cell
        """
        # No format rules apply to this cell
        if not formatting_rules:
            return data

        cell = WriteOnlyCell(self.sheets[sheet_name], value=data)

        # can have multiple format rules
        for format_method in formatting_rules:
            method = deepcopy(format_method)
            if not method.pop("_func", lambda x: True)(data):
                continue

            cell.alignment = method.get("alignment")  # pylint: disable=assigning-non-slot
            cell.border = method.get("border")  # pylint: disable=assigning-non-slot
            cell.font = method.get("font")  # pylint: disable=assigning-non-slot
            cell.fill = method.get("fill")  # pylint: disable=assigning-non-slot

        return cell

    def create_sheet(self, sheet_name: str, headers: Optional[List[str]] = None) -> None:
        """
        Creates a new sheet in the workbook.
        Args:
            sheet_name (str): The name of the sheet to create
            headers (list): The list of column headers for the sheet

        Returns:
            None
        """
        headers = headers or []
        self.sheets[sheet_name] = self.file_stream.create_sheet(sheet_name)
        self.needs_header[sheet_name] = True
        self.all_keys[sheet_name] = set(headers)
        self.header_order[sheet_name] = headers

    def write(self, data: List[Union[dict, list]], sheet_name: str, **kwargs) -> None:
        """
        Simple wrapper around the private write methods. Once this method is called with valid data,
        it will be overwritten with the appropriate writing method such that calling .write() again
        will instead call that method.

        Args:
            data (List[Union[dict, list]]): The data to be written to file
            sheet_name (str): The name of the sheet to write to

        Keyword Args:
            See _write_dicts_to_csv and _write_lists_to_csv for their corresponding keyword args.

        Returns:
            True
        """
        if sheet_name in self.write_method_by_sheet:
            return self.write_method_by_sheet[sheet_name](data, sheet_name, **kwargs)

        if not data:
            return

        if not isinstance(data[0], (list, dict)):
            raise ValueError(f"Unsupported data type in first index: {type(data[0])}")

        # Depending on whether lists or dicts get passed, this method will be overwritten with the
        # corresponding method
        if isinstance(data[0], dict):
            self.write_method_by_sheet[sheet_name] = self._write_dicts_to_excel

        elif isinstance(data[0], list):
            self.write_method_by_sheet[sheet_name] = self._write_lists_to_excel

        else:
            raise ValueError(f"Unsupported data type {type(data)}")

        return self.write_method_by_sheet[sheet_name](data, sheet_name, **kwargs)

    def _write_dicts_to_excel(self, data: List[dict], sheet_name: str, **kwargs) -> None:
        """
        Writes a list with nested dictionaries to Excel. Uses flatten_obj to handle deep nesting.

        Args:
            data: the data structure to write out
            path: the path to write to (includes file name). Will write to "write_out.csv" in your
                  home directory if no path is specified

        Keyword Args:
            ordering: pass a list of headers (in order) to specify column ordering. Any unspecified
                      heads will be appended to the end of the column list
            delete_blank: (Default False) If True, will remove columns that are always
            mode (str): (Default 'w+') the writing mode

        Returns:
            True
        """
        if sheet_name not in self.sheets:
            self.create_sheet(sheet_name)
            self.write_kwargs[sheet_name] = kwargs

        ordering = self.write_kwargs.get("ordering", kwargs.get("ordering", []))
        all_keys = set(key for dct in data for key in dct.keys())
        ordering += sorted(list(set(all_keys) - set(ordering)))

        if not self.all_keys:
            self.all_keys = ordering

        # elif not all_keys.issubset(self.all_keys[sheet_name]):
        #     raise KeyError(f"New column(s) found: {', '.join(self.all_keys[sheet_name] - all_keys)}"
        #                    ". All columns must be declared in the first .write() call.")

        delete_cols = []
        if self.write_kwargs.get("delete_blank", kwargs.get("delete_blank", False)):
            if self.is_stream:
                raise ValueError("The delete_blank keyword argument is not supported for streams.")

            # Remove from the deletion list if any record contains something
            delete_cols = all_keys.copy()
            for column in all_keys:
                if any(bool(item[column]) for item in data):
                    delete_cols.remove(column)

                # All fields have been found to contain data
                if not delete_cols:
                    break

        if self.needs_header[sheet_name]:
            self.sheets[sheet_name].append(ordering)
            self.needs_header[sheet_name] = False

        cell_formatting = merge_overwrite(
            self.cell_format_rules.get(sheet_name, {}),
            kwargs.get("cell_formatting", {})
        )
        row_formatting = self.row_format_rules.get(sheet_name, []) + \
                         kwargs.get("row_formatting", [])

        for row in data:
            for column in delete_cols:
                row.pop(column)

            if row_formatting:
                row = self.apply_row_formatting(row, sheet_name, row_formatting)

            if cell_formatting:
                row = {
                    key: self.apply_cell_formatting(data, sheet_name, cell_formatting.get(key))
                    for key, data in row.items()
                }

            self.sheets[sheet_name].append(
                [row.get(column, "") for column in ordering]
            )

        self.logger.info("Wrote to %s", self.path)

    def _write_lists_to_excel(self, data: List[list], sheet_name: str, **kwargs) -> None:
        """
        Writes a list of lists to csv.

        Args:
            data: the data structure to write out

        Kwargs:
            headers:
        Returns:

        """
        if sheet_name not in self.sheets:
            self.create_sheet(sheet_name)
            self.write_kwargs[sheet_name] = kwargs

        headers = kwargs.get("headers", None)

        if self.needs_header and headers:
            self.sheets[sheet_name].append(headers)
            self.needs_header = False

        cell_formatting = merge_overwrite(
            self.cell_format_rules.get(sheet_name, {}),
            kwargs.get("cell_formatting", {})
        )
        row_formatting = self.row_format_rules.get(sheet_name, []) + \
                         kwargs.get("row_formatting", [])

        for row in data:
            if row_formatting:
                row = self.apply_row_formatting(row, sheet_name, row_formatting)
            if cell_formatting:
                row = [
                    self.apply_cell_formatting(value, sheet_name, cell_formatting.get(idx))
                    for idx, value in enumerate(row)
                ]

            self.sheets[sheet_name].append(row)

        self.logger.info("Wrote to %s", self.path)

    @staticmethod
    def stringify_number(value: Union[int, float]) -> Union[str, int, float]:
        """
        Safely converts a numeric value to a string

        Args:
            value (str): the string to test

        Returns:
            (str)
        """
        if isinstance(value, float):
            return str(int(value))

        if isinstance(value, int):
            return str(value)

        return value

    def json_sanitize(self, obj: Any):
        """
        Sanitizes complex structures for json serialization. Does not mutate the original object.

        Will convert the following types:
            set -> list
            datetime -> string ("%Y-%m-%d %H:%M:%S")
            complex -> string

        Args:
            obj (Any): A data structure

        Returns:
            A copy of data structure passed as obj, except leaf values have been sanitized
        """

        if isinstance(obj, dict):
            yield {
                key: self.json_sanitize(value)
                for key, value in obj.items()
            }

        if isinstance(obj, (list, tuple)):
            yield type(obj)(self.json_sanitize(item) for item in obj)

        if isinstance(obj, set):
            yield list(self.json_sanitize(item) for item in obj)

        if isinstance(obj, (datetime.date, datetime.datetime)):
            yield datetime.datetime.strftime(obj, "%Y-%m-%d %H:%M:%S")

        if isinstance(obj, complex):
            yield str(obj)

        yield obj


class LocalFileDriver(SkopeLogger):
    """
    Helper for reading and writing files locally.

    # TODO - figure out ABC

    Supports:
        1-dimensional: .txt
        2-dimensional: .csv, .tsv, all Excel types

    """

    def __init__(self):  # pragma: no cover
        super().__init__()

        self.staged_data = defaultdict(list)
        self.staged_metadata = defaultdict(dict)

    def read_file(self, path: Path, **kwargs):
        """
        Generic wrapper for just reading a 2-d file, in case you're too lazy to call .read_excel()
        or .read_2d() specifically.

        Args:
            path (Path): the path to the file

        Keyword Args:
            All kwargs are passed to the corresponding function. See that function for a list of
            relevant kwargs and their descriptions.

        Returns:

        """
        if not path.exists():
            raise FileNotFoundError(f"File {path} not found.")

        file_type = path.suffix

        types = {
            ".csv": self.read_csv,
            ".tsv": self.read_tsv,
            ".xlsx": self.read_excel,
            ".xls": self.read_xls,
            ".xlt": self.read_excel,
            ".xlsm": self.read_excel,
            ".xlsb": self.read_excel,
            ".xltx": self.read_excel
        }

        if file_type not in types:
            raise TypeError(f"Unrecognized file type {file_type}. Call a method manually or "
                            f"create a custom one.")

        return types[file_type](path, **kwargs)

    def read_xls(self, path: Path, **kwargs) -> Dict[str, List]:
        """
        Reads an .xls file into memory. Makes the assumption that the data is formatted in a
        friendly way (basically like a csv).

        xlrd dropped support for everything but .xls file, which openpyxl doesn't support. Have to
        use a combination of the libraries to read all excel files.

        TODO: Figure out how to handle merged cells

        Args:
            path (Path):

        Keyword Args:
            headers (bool or List[str]): Default None. A custom list of column headers, in order.
                                         Alternatively, if headers is True, the first row in the
                                         sheet will be treated as headers.
            sheets_to_parse (List[str]): Default None. The list of sheets you would like to parse.
                                         If None, all sheets will be parsed.
            skip_rows (bool):            Default False. Skips rows at the top of the sheet where
                                         the count of values in the next row is greater than the
                                         current one. Added specifically for UFEDs, which often have
                                         an obnoxious row stating the name of the sheet.
            header_row (int):            Default 0. The row index to be used as the header. If 0,
                                         the first row in the sheet will be treated as the header.
            header_landmark (str):       Default None. A string used to indicate the header row if
                                         found in the first column. Properly formed ufeds have '#'
                                         in the first column of each header row. The 'header_landmark'
                                         kwarg supersedes the 'header_row' kwarg if both are provided.
                                         If 'header_landmark' is not found, reading is attempted with
                                         header_row=0 (This is default behavior if 'header_landmark'
                                         kwarg is not used).

        Returns:
            list(dict)
        """

        def _count_non_empty_cells(row):
            """Counts the number of non-empty cells in a given row"""
            return len(list(filter(lambda x: not any((x == '',
                                                      x is None,
                                                      )), row)))

        out = {}
        try:
            excel_workbook = xlrd.open_workbook(path)
        except TypeError:
            excel_workbook = xlrd.open_workbook(file_contents=path.read())

        sheets_to_parse = kwargs.get("sheets_to_parse", [])

        for sheet_name in excel_workbook.sheet_names():

            if sheets_to_parse and sheet_name not in sheets_to_parse:
                continue

            sheet = excel_workbook.sheet_by_name(sheet_name)
            sheet_data = [sheet.row_values(i) for i in range(sheet.nrows)]

            header_row = kwargs.get('header_row', 0)
            header_landmark = kwargs.get('header_landmark', None)
            if header_landmark is not None:
                landmark_not_found = True
                for i, row_i in enumerate(sheet_data):
                    try:
                        if row_i[0].strip() == header_landmark:
                            header_row = i
                            landmark_not_found = False
                            break
                    except AttributeError:
                        pass
                if landmark_not_found:
                    header_row = 0

            if kwargs.get("skip_rows", False):
                while sheet_data:
                    if header_row + 1 >= len(sheet_data):
                        break
                    if _count_non_empty_cells(sheet_data[header_row]) < _count_non_empty_cells(
                            sheet_data[header_row + 1]):
                        self.logger.info(f"Popped leading row from sheet %s", sheet_name)
                        sheet_data.pop(header_row)
                    else:
                        break
            if len(sheet_data) < 2:
                continue

            head = kwargs.get("headers", None)
            if head:
                if isinstance(head, bool):
                    head = sheet_data[header_row]
                    sheet_data = sheet_data[header_row + 1:]
                elif len(head) != len(sheet_data[0]):
                    raise ValueError(f"Expected to receive {len(sheet_data[0])} headers, got {len(head)}")

                sheet_data = [dict(zip(head, item)) for item in sheet_data]

            out[sheet.name] = sheet_data

        return out

    def read_excel(self, path: Path, **kwargs) -> Dict[str, List]:
        """
        Reads an Excel file into memory. Makes the assumption that the data is formatted in a
        friendly way (basically like a csv).

        Args:
            path (Path):

        Keyword Args:
            headers (bool or List[str]): Default None. A custom list of column headers, in order.
                                         Alternatively, if headers is True, the first row in the
                                         sheet will be treated as headers.
            sheets_to_parse (List[str]): Default None. The list of sheets you would like to parse.
                                         If None, all sheets will be parsed.
            skip_rows (bool):            Default False. Skips rows at the top of the sheet where
                                         the count of values in the next row is greater than the
                                         current one. Added specifically for UFEDs, which often have
                                         an obnoxious row stating the name of the sheet.
            header_row (int):            Default 0. The row index to be used as the header. If 0,
                                         the first row in the sheet will be treated as the header.
            header_landmark (str):       Default None. A string used to indicate the header row if
                                         found in the first column. Properly formed ufeds have '#'
                                         in the first column of each header row. The 'header_landmark'
                                         kwarg supersedes the 'header_row' kwarg if both are provided.
                                         If 'header_landmark' is not found, reading is attempted with
                                         header_row=0 (This is default behavior if 'header_landmark'
                                         kwarg is not used).
        Returns:
            list(dict)
        """

        def _count_non_empty_cells(row: List[openpyxl.cell.Cell]) -> int:
            """Counts the number of non-empty cells in a given row"""
            return len(list(filter(lambda x: not any((x.value == '',
                                                      x.value is None,
                                                      isinstance(x, openpyxl.cell.read_only.EmptyCell))), row)))

        out = {}
        excel_workbook = load_workbook(path, read_only=True, data_only=True)

        sheets_to_parse = kwargs.get("sheets_to_parse", [])

        for sheet_name in excel_workbook.sheetnames:

            if sheets_to_parse and sheet_name not in sheets_to_parse:
                continue

            sheet_data = list(excel_workbook[sheet_name].iter_rows())

            header_row = kwargs.get('header_row', 0)
            header_landmark = kwargs.get('header_landmark', None)
            if header_landmark is not None:
                landmark_not_found = True
                for i, row_i in enumerate(sheet_data):
                    try:
                        if row_i[0].value.strip() == header_landmark:
                            header_row = i
                            landmark_not_found = False
                            break
                    except AttributeError:
                        pass
                if landmark_not_found:
                    header_row = 0

            if kwargs.get("skip_rows", False):
                while sheet_data:
                    if header_row + 1 >= len(sheet_data):
                        break
                    if _count_non_empty_cells(sheet_data[header_row]) < _count_non_empty_cells(
                            sheet_data[header_row + 1]):
                        self.logger.info(f"Popped leading row from sheet %s", sheet_name)
                        sheet_data.pop(header_row)
                    else:
                        break
            if len(sheet_data) < 2:
                continue

            head = kwargs.get("headers", None)
            if head:
                if isinstance(head, bool):
                    head = [cell.value for cell in sheet_data[header_row]]
                    sheet_data = sheet_data[header_row + 1:]
                elif isinstance(head, list) and len(head) != len(sheet_data[header_row]):
                    raise ValueError(f"Expected to receive {len(sheet_data[header_row])} headers, got "
                                     f"{len(head)}")

            out_data = []
            for row in sheet_data:
                if head:
                    out_data.append(dict(zip(head, [cell.value for cell in row])))
                else:
                    out_data.append([cell.value for cell in row])

            out[excel_workbook[sheet_name].title] = out_data

        return out

    def read_tsv(self, path: Path, **kwargs):
        """
        Reads a TSV (Tab-separated values) file. Really just points to .read_csv but specifies '\t'
        as a delimiter.

        Args:
            path (Path): path to the file to be read

        See .read_csv for the list of relevant keyword arguments.

        Returns:

        """
        return self.read_csv(path, delimiter='\t', **kwargs)

    @staticmethod
    def read_csv(path: Path, **kwargs) -> Generator:
        """
        Helper for loading a 2d file (csv, tsv, etc.).

        Args:
            path (str): the file path (includes file name). Will open a prompt if not given.
        Kwargs:
            delimiter (str): Default ','. whatever you want to delimit between cells in each row on
            headers (list): Default False. Specify True to use the first row as headers, or pass
                            your own list (in order)
            ignore_commented_lines (str): Default '#'. Specify the character(s) used to denote
                                          comment lines, or enter False/None to not ignore
            sample_rows (int): Default None. If provided, only the first N rows will be read.
            drop_columns (list): Default None. Will drop any columns named.
            encoding (str): Default 'utf-8'. The file's encoding
            infer_numbers (bool): Default false. If true, will convert

        Returns:
            If headers are specified (either via True or a provided list): A list of dictionaries
            Otherwise: a list of lists
        """

        def infer_number(string):

            try:
                return int(string)
            except ValueError:
                try:
                    return float(string)
                except ValueError:
                    return string

        if not path.exists():
            raise FileNotFoundError(f"File {path} not found.")

        with open(
                str(path), 'rt', encoding=kwargs.get("encoding", "utf-8"), errors="ignore"
        ) as file:
            read = csv.reader(file, delimiter=kwargs.get("delimiter", ","))

            line_comment = kwargs.get('ignore_commented_lines', '#')
            sample_rows = kwargs.get("sample_rows", 0)
            drop_columns = kwargs.get("drop_columns", [])
            infer_numbers = kwargs.get("infer_numbers", False)

            row_ticker = 0

            first_line = next(read, None)

            if line_comment and first_line[0].startswith(line_comment):
                while first_line[0].startswith(line_comment):
                    first_line = next(read, None)

            headers = kwargs.get("headers", False)
            if headers and isinstance(headers, bool):
                head = [item.strip().replace(u'\ufeff', '') for item in first_line]
            elif headers:
                head = headers
            else:
                head = None
                row_ticker += 1
                yield first_line

            for line in read:
                if (not line_comment) or line[0].startswith(line_comment):
                    continue

                if sample_rows and row_ticker >= sample_rows:
                    break

                if not head:
                    if infer_numbers:
                        yield [infer_number(item.strip()) for item in line]
                    else:
                        yield [item.strip() for item in line]

                    continue

                line_values = [item.strip().replace(u'\ufeff', '') for item in line]

                # If there are fewer values than there are columns, append empty strings
                if len(line_values) < len(head):
                    line_values += [''] * (len(head) - len(line_values))
                elif len(head) < len(line_values):
                    raise KeyError(f"Line {row_ticker} of file {path} has {len(line_values)} "
                                   f"but only {len(head)} headers.")

                row = dict(zip(head, line_values))

                if drop_columns:
                    for column in drop_columns:
                        row.pop(column)

                if infer_numbers:
                    row = {key: infer_number(value) for key, value in row.items()}

                row_ticker += 1
                yield row

    @staticmethod
    def stream(path: Path, **kwargs) -> Union[_FileStreamWriter, _ExcelStreamWriter]:
        """
        Stream data into a file. Recommended if you're writing large amounts of data and want to
        preserve memory.

        Note that it's slightly more efficient to stream "chunks" of data than individual lines.

        Args:
            path (Path): The path of the file you're creating

        Returns:
            _FileStreamWriter
        """
        if re.match(r"\.xls(?:x|m|)", path.suffix):
            return _ExcelStreamWriter(path, False, **kwargs)

        return _FileStreamWriter(path, False, **kwargs)

    @staticmethod
    def write(
            path: Path,
            data: List[Union[List[Any], Dict[Any, Any]]] = None,
            sheet_name: str = None,
            **kwargs
    ) -> Path:
        """
        Write a file, in its entirety.

        Args:
            path (Path): The path to the file to be written
            data (list): (None) The data to be written.
            sheet_name (str): (Excel files only) The name of the sheet to write to

        Returns:
            (_FileWriter) The abstracted object for writing to the file. You can continue to append
            to the file after calling this method by using the _FileWriter.write() method.
        """
        if not data:
            raise ValueError("No data passed.")

        if re.match(r"\.xls(?:x|m|)", path.suffix):
            writer = _ExcelStreamWriter(path, False, **kwargs)
        else:
            writer = _FileStreamWriter(path, False, **kwargs)

        writer.write(data, sheet_name=sheet_name)
        writer.close()

        return path
