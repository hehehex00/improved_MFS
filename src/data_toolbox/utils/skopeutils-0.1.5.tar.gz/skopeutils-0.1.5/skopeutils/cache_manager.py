"""Helpers for creating a 'cache' of files and interacting with them
Supports:
    - JSON caches (recommended)
    - Pickle files
    - 'Generic' files
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import pickle
from typing import Any, Dict, List, Union

from skopeutils.deep_nesting_helpers import create_deeply_nested_dict, merge_overwrite
from skopeutils.logger import SkopeLogger


__all__ = ['JSONCacheFile', 'PickledCacheFile', 'GenericCacheFile', 'CacheManager']


class JSONCacheFile:

    """
    Representation of a JSON cache file. Useful for storing metadata that your code will need to
    refer to at some later point.
    """

    def __init__(self, path: Path):
        self.path: Path = path
        self.data: dict = self.read()

    def __getitem__(self, key: str) -> Any:
        """
        Permits dot-delimited key retrieval from loaded config values.

        Example:
            If the config were equal to:
            {
                "key1": {
                    "key2": "retrieved_value"
                }

            }

            ...You could retrieve "retrieved_value" by passing key "key1.key2"

        Args:
            key (str): The key to look for in dot form, eg. "key1.key2"

        Returns:
            (Any) The configuration value
        """

        def get_recursive(settings: Union[Dict, str], key_parts: List[str]):
            # Found the desired setting
            if len(key_parts) == 0:
                return settings

            # Look for the next part of the path
            top_level = key_parts.pop(0)
            if top_level not in settings:
                raise KeyError()

            return get_recursive(settings[top_level], key_parts)

        # Try to find the key using recursive helper
        try:
            parts = key.split('.')
            return get_recursive(self.data, parts)

        except KeyError as error:
            raise KeyError(f"Key not found: {key}") from error

    def __contains__(self, item: str):
        """
        Return true if a key is set in the config, and false if not
        """
        try:
            _ = self[item]
            return True
        except KeyError:
            return False

    def __setitem__(self, key: str, value: str):
        """
        Sets a deeply nested value. Permits dot-delimited nesting.

        Values are stringified because JSON only supports strings. It's on you to un-stringify as
        needed.

        The file will be written fresh every time you store a new value, so recommend you batch as
        much as possible.

        Example:
            cache['deeply.nested.value'] = "true" would produce...
            {
                "deeply": {
                    "nested": {
                        "value": "true"
                    }
                }
            }

        Args:
            key (str): The key to store
            value:

        Returns:
            self
        """
        parts = key.split('.')
        nested = create_deeply_nested_dict(parts, value)
        self.data = merge_overwrite(self.data, nested)

        self.write(self.data)

        return self

    def read(self):
        """
        Reads a cached json into memory.

        Returns:

        """
        if not self.path.exists():
            json.dump({}, open(str(self.path), 'w+'))
            return {}

        return json.load(open(str(self.path), 'r'))

    def write(self, data: dict):
        """
        Writes to a JSON cache file.

        Args:
            data (): data to be written to cache

        Returns:
            self
        """
        self.data = merge_overwrite(self.data, data)

        json.dump(self.data, open(self.path, 'w+'), indent=2)

        return self

    def clear(self):
        """
        Clears the cache of its contents

        Returns:
            self
        """
        self.data = {}

        with open(str(self.path), 'w') as file:
            file.write('')

        return self

    def delete(self) -> None:
        """
        Deletes the cache file.

        Returns:
            self
        """
        self.data = {}
        os.remove(str(self.path))

    def merge(self, obj: dict) -> JSONCacheFile:
        """
        Merges a JSON structure into the existing JSON cache. Useful for updating a lot of values
        at once without rewriting the file on every update.

        Args:
            obj (dict): The JSON structure to merge in

        Returns:
            self
        """
        self.data = merge_overwrite(
            self.data,
            obj
        )
        self.write(self.data)
        return self


class PickledCacheFile:

    """
    Representation of a pickled cache file. Makes no assumptions about the actual content of the
    file, so support is limited to reading/writing/deleting.
    """

    def __init__(self, path: Path):
        self.path = path
        self.data = None

        if not self.path.exists():
            self.path.touch()
        else:
            self.read()

    def read(self):
        """
        Reads a cached json into memory.

        Returns:

        """
        self.data = pickle.load(open(str(self.path), 'rb'))
        return self.data

    def write(self, data):
        """
        Writes to a JSON cache file.

        Returns:
            self
        """
        pickle.dump(data, open(str(self.path), 'wb'))

        return self

    def delete(self) -> None:
        """
        Deletes the cache file.

        Returns:
            self
        """
        self.data = {}
        os.remove(str(self.path))


class GenericCacheFile:

    """
    Representation of a file stored in the cache. Makes no assumptions about the file, its contents,
    or how to read it, so interaction with it is pretty much left to the developer.
    """

    def __init__(self, path: Path):
        self.path: Path = path
        if not self.path.exists():
            self.path.touch()

        self.data = None

    def delete(self) -> None:
        """
        Deletes the cache file.

        Returns:
            self
        """
        self.data = {}
        os.remove(str(self.path))


class CacheManager(SkopeLogger):

    """
    Creates a cache and handles the associated management methods.

    There are three types of cache files that are supported:
        - JSON cache
             JSON caches should be created when you need to store metadata generated by your code,
             e.g. if you've built a data pipeline and need to store locations of files produced
             by each stage.

             Supported methods: read, write
        - Pickle cache
            Pickle caches should be used relatively sparingly as a method for storing large amounts
            of data.

    Args:
        cache_location (Path): The path where you would like the cache to be stored. The path
                               should include the name of the folder where cache files will be
                               stored.

    """

    def __init__(self, cache_location: Path):
        super().__init__()
        self.cache_home: Path = self._create_cache_home(cache_location.absolute())
        self.cached_files: dict = {}
        self._read_existing_cache()

    def __getitem__(self, item):
        """Allows access to cache file objects via getitem"""
        return self.cached_files[item]

    @staticmethod
    def _create_cache_home(cache_location: Path) -> Path:
        """
        Creates the cache home, if it hasn't already been.

        Returns:
            (str) absolute path to the file
        """

        if not cache_location.exists():
            os.makedirs(str(cache_location))

        if cache_location.is_file():
            raise FileExistsError("The specific cache location {cache_location} already exists and "
                                  "is a file. Cache locations must be directories.")

        return cache_location

    def _read_existing_cache(self) -> CacheManager:
        """
        Reads the filenames in an existing cache and creates representations of them based on their
        filetypes.

        Returns:
            self
        """
        for file in os.listdir(str(self.cache_home)):
            path = Path(self.cache_home, file)

            # I'm choosing not to support dirs because that seems stupid
            if path.is_dir():
                continue

            if '.json' in path.suffixes:
                self.cached_files[file.split('.')[0]] = JSONCacheFile(path)
            elif '.pickle' in path.suffixes:
                self.cached_files[file.split('.')[0]] = PickledCacheFile(path)
            else:
                self.cached_files[file.split('.')[0]] = GenericCacheFile(path)

        return self

    def create(
            self, cache_name: str, cache_type: str
    ) -> Union[GenericCacheFile, JSONCacheFile, PickledCacheFile]:
        """
        Creates a cache file.

        Args:
            cache_name (str): The name of the cache. Do not include the file extension.
            cache_type (str): The type of cache to create. Options: "json", "pickle", "file"

        Returns:
            (Path)
        """
        cache_type = cache_type.lower()

        if cache_type in ('json', 'pickle'):
            cache_file_name = f"{cache_name}.{cache_type}"
        elif cache_type == "file":
            cache_file_name = cache_name
        else:
            raise ValueError(f"Unsupported cache type: {cache_type}")

        cache_types = {
            "json": JSONCacheFile,
            "pickle": PickledCacheFile,
            "file": GenericCacheFile
        }
        cache_obj = cache_types[cache_type](self.cache_home / cache_file_name)

        self.cached_files[cache_name] = cache_obj

        return cache_obj

    def delete_cache(self) -> None:
        """
        Deletes the entire cache and all files inside.

        Returns:

        """
        for file_name, cache_obj in self.cached_files.copy().items():
            cache_obj.delete()
            self.cached_files.pop(file_name)

        self.cache_home.rmdir()
