"""Helper for downloading, decompressing, and extricating files
Extraction supports:
    - gzip
    - tarfiles
    - zip
"""
import cgi
from glob import glob
import gzip
import logging
import os
from pathlib import Path
import tarfile
import threading
from typing import List
from urllib import request
import shutil
import zipfile

from tqdm import tqdm


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _test_connection(url: str) -> bool:
    """
    Private.

    Tests your ability to connect to a given URL, which should respond with a 200 code.

    Args:
        url (str): The url you are attempting to connect to

    Returns:

    """
    try:
        url_response = request.urlopen(url).getcode()
        if url_response not in (200,):
            raise ConnectionError(f"ERROR: {url} received a bad response ({url_response}).")

        return True

    except Exception as exception:
        raise ConnectionError(f"Unable to able to connect to {url} - {exception}") from exception


def _download_silently(url: str, destination_dir: Path) -> Path:
    """
    Silently download a file to the local file system. TQDM is nice but doesn't do multithreading,
    so this function will print out a log instead of a progress bar.

    Args:
        url (str): The full URL to download from. Can include params.
        destination_dir (Path): The destination folder to put the file in

    Returns:
        str: The path+name of the downloaded file
    """
    if not _test_connection(url):
        raise ConnectionError("Bad connection.")

    if not destination_dir.exists():
        os.makedirs(str(destination_dir))

    req = request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})

    with request.urlopen(req) as open_request:
        info = open_request.info()

        # Derive the filename
        if 'Content-Disposition' in info and 'filename' in info["Content-Disposition"]:
            filename = cgi.parse_header(info["Content-Disposition"])[1]["filename"]
        else:
            filename = url.split('/')[-1]

        file_path = Path(destination_dir, filename)
        request.urlretrieve(url, filename=file_path)

    return file_path


def _download_bar(url: str, destination_dir: Path) -> Path:
    """
    Download a file to the local file system while displaying TQDM's progress bar. Because TQDM
    doesn't handle multithreading well, this should only get called by the primary execution
    thread.

    Args:
        url (str): The full URL to download from. Can include params.
        destination_dir (str): The destination folder to put the file in

    Returns:
        str: The path+name of the downloaded file
    """

    class DownloadProgressBar(tqdm):
        """Progress bar hook"""
        def update_to(self, b=1, bsize=1, tsize=None):  # pylint: disable=invalid-name
            """Updates the progress bar"""
            if tsize is not None:
                self.total = tsize

            self.update(b * bsize - self.n)

    if not _test_connection(url):
        raise ConnectionError("Bad connection.")

    if not destination_dir.exists():
        os.makedirs(str(destination_dir))

    req = request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})

    with request.urlopen(req) as open_request:
        info = open_request.info()

        if 'Content-Disposition' in info and 'filename' in info["Content-Disposition"]:
            filename = cgi.parse_header(info["Content-Disposition"])[1]["filename"]
        else:
            filename = url.split('/')[-1]

        file_path = Path(destination_dir, filename)

        with DownloadProgressBar(
                unit='B', unit_scale=True, miniters=1, desc=f"Downloading {filename}"
        ) as progress_bar:
            request.urlretrieve(url, filename=str(file_path), reporthook=progress_bar.update_to)

    return file_path


def _extract_gzip(path: Path) -> Path:
    """
    Extracts a gzipped file to the same location.

    Args:
        path (Path): The path to the gzipped file

    Returns:
        (Path) The path to the extract file/dir
    """
    logger.info("Gunzipping %s", path)
    # gzip doesn't provide a direct way to gunzip - have to dump contents into a new file
    contents = gzip.GzipFile(path, 'rb').read()

    # Create new file without the gz/gzip extension
    new_file_name = '.'.join(str(path).split('.')[:-1])
    with open(new_file_name, 'wb') as new_file:
        new_file.write(contents)
        new_file.close()

    # Remove the gzip file
    os.remove(str(path))

    return path.parent / new_file_name


def _extract_zip(path: Path) -> Path:
    """
    Extracts a zipped file to the same location.

    Args:
        path (Path): The path of the zipped file

    Returns:
        (Path) The path to the extracted file/dir
    """
    logger.info("Unzipping %s", path)
    with zipfile.ZipFile(path) as zip_file:
        zip_file.extractall('.'.join(str(path).split('.')[:-1]))

    os.remove(str(path))
    download_file_name = str(path.name).rstrip('.zip')
    return path.parent / download_file_name


def _extract_tarfile(path: Path) -> Path:
    """
    Extracts a tarfile to the same location.

    Args:
        path (Path): The path to the tarfile

    Returns:
        (Path) The path to the extracted file/dir
    """
    logger.info("Untarring %s", path)
    with tarfile.open(path) as tar:
        tar.extractall(path.parent)

    return path.parent / os.path.commonprefix(tar.getnames())


def _extricate_files(parent_dir: Path, file_to_extricate: Path) -> List[Path]:
    """
    Extricates one or more files from a dir, moving those files to the same location as the dir.
    Deletes the dir and all of its remaining files afterwards.

    Args:
        parent_dir (Path): The parent dir that files should be extricated from
        file_to_extricate (Path): The location (absolute, or relative to the parent_dir argument)
                                  of the file(s) to be extricated. Supports globbing.

    Returns:

    """
    extricated = []

    # If the path isn't absolute, need to make it relative to the parent dir
    if file_to_extricate.is_absolute():
        abs_path = file_to_extricate
    else:
        abs_path = parent_dir / file_to_extricate

    for file in glob(str(abs_path)):
        shutil.copy(file, str(parent_dir.parent / Path(file).name))
        extricated.append(parent_dir.parent / Path(file).name)

    shutil.rmtree(str(parent_dir))
    return extricated


def download_file(  # pylint: disable=too-many-branches
        url: str, path: Path, **kwargs
) -> List[Path]:
    """
    Helper for downloading common file types over http/https.



    If the file is compressed and the extension is recognized, will automatically extract it for
    you (unless you specify not to using the auto_extract kwarg).

    Args:
        url (str): The url of the file for download
        path (Path): The directory that the file should be downloaded to

    Keyword Args:
        auto_extract (bool): (Default True) If True, will automatically extract the downloaded file
                             if the file extension is recognized.

        extricate_files (list): If your downloaded file decompresses to a dir, you can use this
                                kwarg to identify specific sub-files that you care about. These
                                files will be moved to the same folder level as specified by the
                                "path" argument, and the downloaded file and the remaining
                                sub-files will be deleted. Supports globbing.

        overwrite (bool): (Default False) If True, will allow the downloaded file to overwrite
                          anything that already exists with the same name in the directory.

        rename (dict): Renames files. Renaming occurs after all other kwargs are satisfied (e.g.
                       you can rename a file specified by the extricate_files kwarg) Expects the
                       following format (file names should include extensions):
                       { original_file_name : new_file_name }

    Returns:
        List(Path) A list of absolute paths to all "rooted" files.

        Examples:
            - If you've downloaded a single .csv file, it will return the Path to that file
            - If you've downloaded and decompressed a .zip file, it will return the Path to
              the root folder of the decompressed zip
            - If you've downloaded and decompressed a .zip file, but ALSO extricated 5 files from
              that .zip file, it will return the Paths of those 5 files you extricated.
    """

    renames = kwargs.get("rename", {})

    if path.exists() and path.is_file() and kwargs.get("overwrite", False):
        raise FileExistsError("The path specified ({path}) already exists. If you'd like to "
                              "automatically overwrite it, use the overwrite kwarg.")

    # Keep track of absolute paths of the files to be returned
    file_paths = set()

    if path.is_file():
        raise ValueError(f"Path must be a directory (you provided {path}). If you are trying to "
                         "control the name of your downloaded file, please use the rename kwarg.")

    # If parent dirs don't exist, just make them
    if not path.parent.exists():
        os.makedirs(str(path.parent))

    # Call the actual download code - if not in the main thread, don't use TQDM's progress bar.
    # Note that we download to ./tmp, because if some other process is listening we don't want it
    # going crazy on a half-downloaded file
    if threading.current_thread() is threading.main_thread():
        downloaded_file = _download_bar(url, path / "tmp")
    else:
        downloaded_file = _download_silently(url, path / "tmp")

    file_paths.add(downloaded_file)

    if kwargs.get("auto_extract", True):
        file_paths.remove(downloaded_file)

        if downloaded_file.suffix in ['.gz', '.gzip']:
            downloaded_file = _extract_gzip(downloaded_file)

        elif downloaded_file.suffix in ['.zip']:
            downloaded_file = _extract_zip(downloaded_file)

        elif downloaded_file.suffix in ['.tar.gz', '.tgz']:
            downloaded_file = _extract_tarfile(downloaded_file)

        file_paths.add(downloaded_file)

    # We just downloaded to ./tmp - if something already exists where the file should get moved to,
    # it has to be deleted. Note that if the overwrite kwarg is False and this block still executes,
    # it means you're really bad at multithreading
    if (path / downloaded_file.name).exists():
        if (path / downloaded_file.name).is_dir():
            shutil.rmtree(path / downloaded_file.name)
        else:
            os.remove(str(path / downloaded_file.name))

    # Move out of tmp folder, then delete the tmp folder
    final_loc = Path(shutil.move(str(downloaded_file), str(path / downloaded_file.name)))
    shutil.rmtree(path / "tmp")
    file_paths.remove(downloaded_file)
    file_paths.add(final_loc)

    extricate = kwargs.get("extricate_files", [])
    if extricate:
        file_paths.remove(final_loc)

    for file in extricate:
        file_paths.update(_extricate_files(final_loc, file))

    for orig_name, new_name in renames.items():
        if not (path / orig_name).exists():
            raise FileNotFoundError(f"Cannot rename {orig_name} - file does not exist.")

        shutil.move(path / orig_name, path / new_name)
        file_paths.remove(path / orig_name)
        file_paths.add(path / new_name)

    return list(file_paths)
