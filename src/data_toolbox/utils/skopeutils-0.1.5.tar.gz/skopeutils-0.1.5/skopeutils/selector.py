"""Helpers for extracting and validating selectors.
Provides a common namespace for regular expressions"""
import re
from typing import Union, List


class Selector:

    """
    Provides a convenient namespace for regular expressions, as well as helper methods for
    extracting selectors from text and validating the results.

    Note on validation: This module's validation logic is only meant *roughly* show that a
    given selector conforms to its corresponding ruleset (e.g. that a Facebook ID only contains
    numbers and is only so long). It does not indicate whether the selector is actually a valid
    account.

    Example Usages:
        # Passing the account type as a parameter
        example = Selectors.extract("example facebook id 1234567890", "facebook")

        # Hard-coding which account to extract
        example2 = Selectors.extract_facebook("example facebook id 1234567890")

    """

    RECOGNIZED_ACCOUNTS = (
        "email",
        "facebook",
        "facebook messenger",
        "ipv4",
        "mac",
        "phone",
        "telegram",
        "twitter",
        "whatsapp",
        "viber",
    )

    PHONE_BASED_IDENTIFIERS = (
        "phone",
        "whatsapp",
        "viber"
    )

    PHONE_REGEX = r"(?:^|[^\d\w])" \
                  r"((?:\(?(?:(?:\+|00)\s?[1-9]\d{0,2}|0)\)?\s?)?" \
                  r"(?:\(?[1-9]\d{1,3}\)?\s?)" \
                  r"(?:\d{3,4})[\s\-]{0,3}" \
                  r"(?:\d{3,4}))" \
                  r"(?:$|[^\d])"

    EMAIL_REGEX = r"[a-z0-9!#$%&'*+/=?^_'{|}`-]+(?:\.[a-z0-9!#$%&'*+/=?^_'{|}`-]+)*" \
                  r"@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"

    FACEBOOK_REGEX = r"(?:^|[\s(])([1-9]\d{5,})(?:$|[\s)])"

    IPV4_REGEX = r"(?:^|[\s(])" \
                 r"((?:(?:25[0-5]|2[0-4]\d|[1-9]\d{0,1}|0)\.){3}" \
                 r"(?:25[0-5]|2[0-4]\d|[1-9]\d{0,1}|0))(?:$|[\s)])"

    MAC_ADDRESS_REGEX = r"(?:^|[\s(])((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})(?:$|[\s)])"

    TELEGRAM_REGEX = r"(?:^|[\s(])([1-9]\d{5,12})(?:$|[\s)])"

    TWITTER_REGEX = r"(?!\s\w)@\w{4,15}(?!\w)"

    def __init__(self):
        pass

    def extract(self, text: Union[str, List[str]], account_type: str) -> list:
        """
        Helper for extracting a selector dynamically. Just takes the account type as a string and
        routes to the appropriate extraction method.

        Args:
            text (str or list): The string to extract account IDs from. If a list of strings is
                                provided, will iterate over the strings and flatten results into
                                a 1-d list.
            account_type (str): The account type.
                                Options:
                                    - "email"
                                    - "facebook"
                                    - "facebook messenger"
                                    - "ipv4"
                                    - "mac"
                                    - "phone"
                                    - "telegram"
                                    - "twitter"
                                    - "whatsapp"
                                    - "viber"

        Returns:
            (list) A list of matching substrings
        """
        if isinstance(text, list):
            return [selector for block in text for selector in self.extract(block, account_type)]

        if not text:
            return []

        func = getattr(self, f"_extract_{account_type.replace(' ', '_')}")

        return func(text)

    def validate(self, selector: str, account_type: str) -> bool:
        """
        Helper for validating a selector. Takes the account type as a string and routes to the
        appropriate validation method.

        Args:
            selector (str): The (potential) account ID that needs to be validated.
            account_type (str): The account type, e.g. "facebook", "telegram"

        Returns:

        """
        func = getattr(self, f"_validate_{account_type}")

        return func(selector)

    def _extract_email(self, text: str) -> list:
        """Extracts email addresses from a string"""
        if not text:
            return []

        return re.findall(self.EMAIL_REGEX, text)

    def _validate_email(self, selector: str) -> bool:
        """Returns True if a selector conforms to email validation rules"""
        return bool(re.match("^" + self.EMAIL_REGEX + "$", selector))

    def _extract_facebook(self, text: str) -> list:
        """Extracts facebook ids from a string"""
        if not text:
            return []

        return re.findall(self.FACEBOOK_REGEX, text)

    def _validate_facebook(self, selector: str) -> bool:
        """Returns True if a selector conforms to Facebook validation rules"""
        return bool(re.match("^" + self.FACEBOOK_REGEX + "$", selector))

    def _extract_facebook_messenger(self, text: str) -> list:  # pragma: no cover
        """Extracts facebook ids from a string"""
        return self._extract_facebook(text)

    def _validate_facebook_messenger(self, selector: str) -> bool:  # pragma: no cover
        """Returns True if a selector conforms to Facebook validation rules"""
        return self._validate_facebook(selector)

    def _extract_ipv4(self, text: str) -> list:
        """Extracts ipv4 addresses from a string"""
        if not text:
            return []

        return re.findall(self.IPV4_REGEX, text)

    def _validate_ipv4(self, selector: str) -> bool:
        """Returns True if a selector conforms to IPv4 validation rules"""
        return bool(re.match("^" + self.IPV4_REGEX + "$", selector))

    def _extract_mac(self, text: str) -> list:
        """Extracts mac addresses from a string"""
        if not text:
            return []

        return re.findall(self.MAC_ADDRESS_REGEX, text)

    def _validate_mac(self, selector: str) -> bool:
        """Returns True if a selector conforms to MAC Address validation rules"""
        return bool(re.match("^" + self.MAC_ADDRESS_REGEX + "$", selector))

    def _extract_phone(self, text: str) -> list:
        """Extracts phone numbers from a string"""
        if not text:
            return []

        return re.findall(self.PHONE_REGEX, text)

    def _validate_phone(self, selector: str) -> bool:
        """Returns True if a selector conforms to phone number validation rules"""
        return bool(re.match("^" + self.PHONE_REGEX + "$", selector))

    def _extract_telegram(self, text: str) -> list:
        """Extracts telegram ids from a string"""
        if not text:
            return []

        return re.findall(self.TELEGRAM_REGEX, text)

    def _validate_telegram(self, selector: str) -> bool:
        """Returns True if a selector conforms to Telegram validation rules"""
        return bool(re.match("^" + self.TELEGRAM_REGEX + "$", selector))

    def _extract_twitter(self, text: str) -> list:
        """Extracts twitter ids from a string"""
        if not text:
            return []

        return re.findall(self.TWITTER_REGEX, text)

    def _validate_twitter(self, selector: str) -> bool:
        """Returns True if a selector conforms to Twitter validation rules"""
        return bool(re.match("^" + self.TWITTER_REGEX + "$", selector))

    def _extract_viber(self, text: str) -> list:  # pragma: no cover
        """Extracts viber ids from a string"""
        return self._extract_phone(text)

    def _validate_viber(self, selector: str) -> bool:  # pragma: no cover
        """Returns True if a selector conforms to Viber validation rules"""
        return self._validate_phone(selector)

    def _extract_whatsapp(self, text: str) -> list:  # pragma: no cover
        """Extracts whatsapp ids from a string"""
        return self._extract_phone(text)

    def _validate_whatsapp(self, selector: str) -> bool:  # pragma: no cover
        """Returns True if a selector conforms to Whatsapp validation rules"""
        return self._validate_phone(selector)
